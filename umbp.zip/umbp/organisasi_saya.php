<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/anggota.php';
wajib_login(['calon']);
$uid = (int)$_SESSION['user']['id'];
$idc = (int)$db->query("SELECT COALESCE(id_calon,0) FROM pengguna WHERE id_pengguna = $uid")->fetch_row()[0];
if (!$idc) { header('Location: daftar_data.php'); exit; }
$p = $db->query("SELECT status FROM pendaftaran WHERE id_calon = $idc ORDER BY id_pendaftaran DESC LIMIT 1")->fetch_assoc();
if (!$p) { header('Location: daftar_data.php'); exit; }
$lulus = $p['status'] === 'lulus';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!$lulus) throw new RuntimeException('Organisasi bisa dipilih setelah kamu dinyatakan lulus.');
        $nim = nim_calon($db, $idc);
        if (!$nim) throw new RuntimeException('Akunmu belum tercatat sebagai mahasiswa (belum punya NIM). Hubungi panitia.');
        $aksi = $_POST['aksi'] ?? '';

        if ($aksi === 'pilih_org') {
            $pilih = array_unique(array_map('intval', (array)($_POST['org'] ?? [])));
            if (!$pilih) throw new RuntimeException('Centang minimal satu organisasi.');
            $jml = 0;
            $db->begin_transaction();
            try {
                $s = $db->prepare("INSERT IGNORE INTO pendaftaran_organisasi (id_calon, id_org, alasan, tgl_daftar, status)
                                   SELECT ?, id_org, '-', CURDATE(), 'diterima' FROM organisasi WHERE id_org = ? AND status_aktif = 1");
                foreach ($pilih as $oid) {
                    $s->bind_param('ii', $idc, $oid); $s->execute();
                    if ($s->affected_rows > 0) { tambah_keanggotaan($db, $nim, $oid); $jml++; }
                }
                if ($jml < 1) throw new RuntimeException('Organisasi tidak tersedia atau sudah kamu ikuti.');
                $db->commit();
            } catch (Throwable $e) { $db->rollback(); throw $e; }
            flash('ok', 'Berhasil bergabung ke ' . $jml . ' organisasi.');

        } elseif ($aksi === 'keluar_org') {
            $oid = (int)($_POST['id_org'] ?? 0);
            $db->begin_transaction();
            try {
                $s = $db->prepare('DELETE FROM pendaftaran_organisasi WHERE id_calon = ? AND id_org = ?');
                $s->bind_param('ii', $idc, $oid); $s->execute();
                hapus_keanggotaan($db, $nim, $oid);
                $db->commit();
            } catch (Throwable $e) { $db->rollback(); throw $e; }
            flash('ok', 'Kamu keluar dari organisasi tersebut.');
        }
    } catch (RuntimeException $e) { flash('err', $e->getMessage()); }
    catch (mysqli_sql_exception $e) { flash('err', galat_sql($e)); }
    header('Location: organisasi_saya.php'); exit;
}

// Samakan data lama yang belum masuk keanggotaan
if ($lulus) { try { sinkron_keanggotaan($db); } catch (Throwable $e) { /* abaikan, tidak mengganggu tampilan */ } }

$ikut = $db->query("SELECT o.id_org, o.nama_org, o.singkatan, k.nama_kategori
    FROM pendaftaran_organisasi po
    JOIN organisasi o ON o.id_org = po.id_org
    JOIN kategori_organisasi k ON k.id_kategori = o.id_kategori
    WHERE po.id_calon = $idc ORDER BY o.nama_org")->fetch_all(MYSQLI_ASSOC);
$tersedia = $db->query("SELECT o.id_org, o.nama_org, o.singkatan, o.deskripsi, k.nama_kategori
    FROM organisasi o
    JOIN kategori_organisasi k ON k.id_kategori = o.id_kategori
    WHERE o.status_aktif = 1
      AND o.id_org NOT IN (SELECT id_org FROM pendaftaran_organisasi WHERE id_calon = $idc)
    ORDER BY o.nama_org")->fetch_all(MYSQLI_ASSOC);

$judul = 'Organisasi';
require 'partials/atas.php';
?>
<style>
.pilih-org{display:flex;align-items:flex-start;gap:10px;padding:10px 0;border-top:1px solid #eee;cursor:pointer}
.pilih-org input{width:auto;margin:4px 0 0}
.pilih-org.kunci{opacity:.55;cursor:not-allowed}
.org-ikut{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 0;border-top:1px solid #eee}
.info-kunci{background:#fff3cd;color:#8a6100;padding:10px 14px;border-radius:10px;font-size:13px;margin-bottom:8px}
button:disabled{opacity:.5;cursor:not-allowed}
</style>

<div class="card">
<h2>Organisasi Mahasiswa Baru</h2>
<?php tampil_flash(); ?>
<?php if (!$lulus): ?>
  <div class="info-kunci">🔒 Organisasi di bawah ini baru bisa kamu pilih setelah dinyatakan <b>lulus</b> seleksi. Sementara ini kamu bisa melihat-lihat dulu. Status kamu sekarang: <?= lencana($p['status']) ?></div>
<?php else: ?>
  <p class="kecil">Selamat, kamu sudah lulus! Pilih organisasi yang ingin kamu ikuti.</p>
<?php endif; ?>
</div>

<?php if ($lulus && $ikut): ?>
<div class="card">
<h3>Organisasi yang Kamu Ikuti</h3>
<?php foreach ($ikut as $o): ?>
<div class="org-ikut">
  <div><b><?= h($o['nama_org']) ?></b><?= $o['singkatan'] ? ' <small>(' . h($o['singkatan']) . ')</small>' : '' ?>
    <small> | <?= h($o['nama_kategori']) ?></small></div>
  <form method="post" onsubmit="return confirm('Keluar dari <?= h(addslashes($o['nama_org'])) ?>?')">
    <input type="hidden" name="aksi" value="keluar_org"><input type="hidden" name="id_org" value="<?= (int)$o['id_org'] ?>">
    <button class="btn-hapus" style="width:auto;margin:0">Keluar</button>
  </form>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<div class="card">
<h3>Daftar Organisasi</h3>
<?php if ($tersedia): ?>
<form method="post">
  <input type="hidden" name="aksi" value="pilih_org">
  <?php foreach ($tersedia as $o): ?>
  <label class="pilih-org <?= $lulus ? '' : 'kunci' ?>">
    <input type="checkbox" name="org[]" value="<?= (int)$o['id_org'] ?>" <?= $lulus ? '' : 'disabled' ?>>
    <span><b><?= h($o['nama_org']) ?></b><?= $o['singkatan'] ? ' <small>(' . h($o['singkatan']) . ')</small>' : '' ?>
      <small> | <?= h($o['nama_kategori']) ?></small>
      <?php if ($o['deskripsi']): ?><br><small><?= h($o['deskripsi']) ?></small><?php endif; ?></span>
  </label>
  <?php endforeach; ?>
  <button style="width:auto;margin-top:10px" <?= $lulus ? '' : 'disabled' ?>>Gabung</button>
</form>
<?php elseif ($ikut): ?>
<p class="kecil">Kamu sudah mengikuti semua organisasi yang tersedia.</p>
<?php else: ?>
<p class="kecil">Belum ada organisasi aktif.</p>
<?php endif; ?>
</div>
<?php require 'partials/bawah.php'; ?>