<?php
require 'config/koneksi.php'; require 'config/bantu.php';
wajib_login(['admin', 'kemahasiswaan']);

$prodiList = $db->query('SELECT id_prodi, nama_prodi, jenjang FROM program_studi ORDER BY nama_prodi, jenjang')->fetch_all(MYSQLI_ASSOC);
$prodi = (int)($_GET['prodi'] ?? 0);
if (!$prodi && $prodiList) $prodi = (int)$prodiList[0]['id_prodi'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!$prodi) throw new RuntimeException('Pilih prodi dulu.');
        $aksi = $_POST['aksi'] ?? '';
        if ($aksi === 'sks') {
            $u = $db->prepare('UPDATE mata_kuliah SET sks = ? WHERE id_matkul = ? AND id_prodi = ?');
            $n = 0;
            foreach ((array)($_POST['sks'] ?? []) as $idm => $v) {
                $v = (int)$v; $idm = (int)$idm;
                if ($v < 1 || $v > 8) throw new RuntimeException('SKS harus 1 sampai 8.');
                $u->bind_param('iii', $v, $idm, $prodi); $u->execute(); $n++;
            }
            flash('ok', 'SKS disimpan (' . $n . ' mata kuliah).');
        } elseif ($aksi === 'tambah') {
            $kode = trim($_POST['kode_mk'] ?? ''); $nama = trim($_POST['nama_mk'] ?? '');
            $smk = (int)($_POST['semester_ke'] ?? 0); $sks = (int)($_POST['sks_baru'] ?? 0);
            if ($kode === '' || $nama === '') throw new RuntimeException('Kode dan nama mata kuliah wajib diisi.');
            if ($smk < 1 || $smk > 8) throw new RuntimeException('Semester harus 1 sampai 8.');
            if ($sks < 1 || $sks > 8) throw new RuntimeException('SKS harus 1 sampai 8.');
            $s = $db->prepare('INSERT INTO mata_kuliah (kode_mk, nama_mk, id_prodi, semester_ke, sks) VALUES (?,?,?,?,?)');
            $s->bind_param('ssiii', $kode, $nama, $prodi, $smk, $sks); $s->execute();
            flash('ok', 'Mata kuliah ditambahkan.');
        } elseif ($aksi === 'hapus') {
            $idm = (int)($_POST['id'] ?? 0);
            $pakai = (int)$db->query("SELECT COUNT(*) FROM nilai_matkul WHERE id_matkul = $idm")->fetch_row()[0];
            if ($pakai > 0) throw new RuntimeException('Mata kuliah ini sudah dipakai untuk nilai mahasiswa, tidak bisa dihapus.');
            $s = $db->prepare('DELETE FROM mata_kuliah WHERE id_matkul = ? AND id_prodi = ?');
            $s->bind_param('ii', $idm, $prodi); $s->execute();
            flash('ok', 'Mata kuliah dihapus.');
        }
    } catch (RuntimeException $e) { flash('err', $e->getMessage()); }
    catch (mysqli_sql_exception $e) {
        flash('err', $e->getCode() == 1451 ? 'Mata kuliah ini sudah dipakai di absensi, tidak bisa dihapus.' : galat_sql($e));
    }
    header('Location: matakuliah.php?prodi=' . $prodi); exit;
}

$mk = [];
if ($prodi) {
    $q = $db->prepare('SELECT id_matkul, kode_mk, nama_mk, semester_ke, sks FROM mata_kuliah WHERE id_prodi = ? ORDER BY semester_ke, kode_mk');
    $q->bind_param('i', $prodi); $q->execute();
    foreach ($q->get_result() as $r) { $mk[(int)$r['semester_ke']][] = $r; }
    $q->close();
}

$judul = 'Mata Kuliah';
require 'partials/atas.php';
?>
<div class="card">
<h2>Mata Kuliah per Program Studi</h2>
<?php tampil_flash(); ?>
<form method="get" class="inline">
  <div><label>Program studi</label><select name="prodi" onchange="this.form.submit()">
    <?php foreach ($prodiList as $p): ?><option value="<?= (int)$p['id_prodi'] ?>" <?= $prodi == $p['id_prodi'] ? 'selected' : '' ?>><?= h($p['nama_prodi']) ?> (<?= h($p['jenjang']) ?>)</option><?php endforeach; ?>
  </select></div>
</form>
<p class="kecil">Mata kuliah ini dipakai untuk input nilai per semester. IPS dan IPK dihitung dari nilai dan SKS, jadi sesuaikan SKS tiap mata kuliah. Skripsi, magang, KKP, dan PKL tidak dimasukkan.</p>
</div>

<?php if (!$mk): ?>
<div class="card"><p class="kecil">Belum ada mata kuliah untuk prodi ini. Jalankan SQL pengisian mata kuliah, atau tambahkan manual di bawah.</p></div>
<?php else: ?>
<form id="fh" method="post"><input type="hidden" name="aksi" value="hapus"></form>
<form method="post">
<input type="hidden" name="aksi" value="sks">
<?php foreach ($mk as $smk => $list): ?>
<div class="card">
<h3>Semester <?= (int)$smk ?></h3>
<div class="scroll"><table>
<tr><th>Kode</th><th>Mata kuliah</th><th>SKS</th><th>Aksi</th></tr>
<?php foreach ($list as $k): ?>
<tr>
  <td><?= h($k['kode_mk']) ?></td>
  <td><?= h($k['nama_mk']) ?></td>
  <td><input type="number" min="1" max="8" name="sks[<?= (int)$k['id_matkul'] ?>]" value="<?= (int)$k['sks'] ?>" style="width:70px"></td>
  <td><button type="submit" form="fh" name="id" value="<?= (int)$k['id_matkul'] ?>" class="btn-hapus" onclick="return confirm('Hapus mata kuliah ini?')">Hapus</button></td>
</tr>
<?php endforeach; ?>
</table></div></div>
<?php endforeach; ?>
<div class="card"><button style="width:auto">Simpan semua SKS</button></div>
</form>
<?php endif; ?>

<div class="card">
<h3>Tambah Mata Kuliah</h3>
<form method="post" class="inline">
  <input type="hidden" name="aksi" value="tambah">
  <div><label>Kode</label><input name="kode_mk" required maxlength="20"></div>
  <div><label>Nama mata kuliah</label><input name="nama_mk" required maxlength="150"></div>
  <div><label>Semester ke-</label><input type="number" name="semester_ke" min="1" max="8" required></div>
  <div><label>SKS</label><input type="number" name="sks_baru" min="1" max="8" value="3" required></div>
  <button>Tambah</button>
</form>
</div>
<?php require 'partials/bawah.php'; ?>