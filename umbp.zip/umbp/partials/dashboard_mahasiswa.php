<?php
// Dashboard mahasiswa: profil singkat, absensi per mata kuliah, riwayat akademik, riwayat tagihan, perkiraan lulus.
// Dipanggil dari portal.php. Variabel yang dipakai: $db, $idc, $nimSaya.
require_once __DIR__ . '/../config/akademik.php';

if (!function_exists('bar_hadir')) {
    function bar_hadir(float $p): string {
        $w = number_format(max(0, min(100, $p)), 1, '.', '');
        return '<span style="display:inline-block;vertical-align:middle;width:110px;height:8px;background:#eee;border-radius:6px;overflow:hidden">'
             . '<span style="display:block;width:' . $w . '%;height:8px;background:#8b0d0d"></span></span> '
             . number_format($p, 1, ',', '.') . '%';
    }
}

// ----- Profil -----
$sM = $db->prepare('SELECT m.nim, m.nama, m.angkatan, m.status_akademik, m.tgl_lulus,
        p.nama_prodi, p.jenjang, c.email, c.no_hp, c.asal_sekolah
    FROM mahasiswa m
    JOIN program_studi p ON p.id_prodi = m.id_prodi
    JOIN calon_mahasiswa c ON c.id_calon = m.id_calon
    WHERE m.nim = ?');
$sM->bind_param('s', $nimSaya); $sM->execute();
$mh = $sM->get_result()->fetch_assoc(); $sM->close();
if (!$mh) return;
$angkatanM = $mh['angkatan'] !== null ? (int)$mh['angkatan'] : null;

// ----- Semester yang dipilih (default: semester terbaru) -----
$semAll = $db->query('SELECT id_semester, tahun_akademik, jenis FROM semester ORDER BY id_semester DESC')->fetch_all(MYSQLI_ASSOC);
$semPilihM = (int)($_GET['sem'] ?? 0);
$semRowM = null;
foreach ($semAll as $sx) { if ((int)$sx['id_semester'] === $semPilihM) $semRowM = $sx; }
if (!$semRowM && $semAll) { $semRowM = $semAll[0]; $semPilihM = (int)$semRowM['id_semester']; }

$skSekarang = $semAll ? semester_ke($angkatanM, (string)$semAll[0]['tahun_akademik'], (string)$semAll[0]['jenis']) : null;
$skDipilih = $semRowM ? semester_ke($angkatanM, (string)$semRowM['tahun_akademik'], (string)$semRowM['jenis']) : null;

// ----- Lama studi dan perkiraan lulus (paling cepat) -----
$lamaStudi = ['S1' => 4, 'D3' => 3][$mh['jenjang']] ?? 4;
$perkiraanLulus = $angkatanM !== null ? $angkatanM + $lamaStudi : null;

// ----- Absensi per mata kuliah pada semester terpilih -----
$absensi = [];
$rekap = null;
if ($semRowM) {
    $skCari = $skDipilih ?? 0;   // 0 = hanya mata kuliah yang sudah punya absensi
    $q = $db->prepare("SELECT m.kode_mk, m.nama_mk, COUNT(a.id_matkul) AS tercatat,
            COALESCE(SUM(a.status_hadir = 'hadir'), 0) AS hadir,
            COALESCE(SUM(a.status_hadir = 'izin'), 0) AS izin,
            COALESCE(SUM(a.status_hadir = 'sakit'), 0) AS sakit,
            COALESCE(SUM(a.status_hadir = 'alpa'), 0) AS alpa
        FROM mata_kuliah m
        LEFT JOIN absensi a ON a.id_matkul = m.id_matkul AND a.nim = ? AND a.id_semester = ?
        WHERE m.id_prodi = (SELECT id_prodi FROM mahasiswa WHERE nim = ?)
          AND (m.semester_ke = ? OR a.id_matkul IS NOT NULL)
        GROUP BY m.id_matkul, m.kode_mk, m.nama_mk
        ORDER BY m.kode_mk");
    $q->bind_param('sisi', $nimSaya, $semPilihM, $nimSaya, $skCari); $q->execute();
    $absensi = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();

    $q = $db->prepare('SELECT total_pertemuan, total_hadir, persen_hadir FROM rekap_kehadiran WHERE nim = ? AND id_semester = ?');
    $q->bind_param('si', $nimSaya, $semPilihM); $q->execute();
    $rekap = $q->get_result()->fetch_assoc(); $q->close();
}

// ----- Riwayat akademik -----
$q = $db->prepare('SELECT s.tahun_akademik, s.jenis, n.ips, n.ipk
    FROM nilai_semester n JOIN semester s ON s.id_semester = n.id_semester
    WHERE n.nim = ? ORDER BY n.id_semester');
$q->bind_param('s', $nimSaya); $q->execute();
$riwayat = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
$ipkTerakhir = $riwayat ? end($riwayat)['ipk'] : null;

$nilaiMk = [];
if ($semRowM) {
    $q = $db->prepare('SELECT m.kode_mk, m.nama_mk, m.sks, n.nilai_angka, n.huruf
        FROM nilai_matkul n JOIN mata_kuliah m ON m.id_matkul = n.id_matkul
        WHERE n.nim = ? AND n.id_semester = ? ORDER BY m.kode_mk');
    $q->bind_param('si', $nimSaya, $semPilihM); $q->execute();
    $nilaiMk = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
}

// ----- Riwayat tagihan / pembayaran -----
$q = $db->prepare('SELECT y.jenis_bayar, y.nominal, y.tgl_bayar, y.status
    FROM pembayaran y JOIN pendaftaran x ON x.id_pendaftaran = y.id_pendaftaran
    WHERE x.id_calon = ? ORDER BY y.tgl_bayar DESC');
$q->bind_param('i', $idc); $q->execute();
$tagihan = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
$totalLunas = 0;
foreach ($tagihan as $tg) { if ($tg['status'] === 'lunas') $totalLunas += (int)$tg['nominal']; }
?>
<style>
.kotak-info{background:#eef4ff;color:#1f4a8a;padding:12px 16px;border-radius:10px;font-size:14px;margin-top:12px}
.kotak-lulus{background:#d9f2e0;color:#1b6b34}
.profil-item .kecil{display:block}
.angka-besar{font-size:22px;font-weight:700;color:#8b0d0d}
</style>

<div class="card" id="akademik">
<h3>Profil Mahasiswa</h3>
<div class="grid">
  <div class="profil-item"><span class="kecil">NIM</span><b><?= h($mh['nim']) ?></b></div>
  <div class="profil-item"><span class="kecil">Nama</span><b><?= h($mh['nama']) ?></b></div>
  <div class="profil-item"><span class="kecil">Program studi</span><b><?= h($mh['nama_prodi']) ?> (<?= h($mh['jenjang']) ?>)</b></div>
  <div class="profil-item"><span class="kecil">Angkatan</span><b><?= $angkatanM !== null ? $angkatanM : '-' ?></b></div>
  <div class="profil-item"><span class="kecil">Semester berjalan</span><b><?= $skSekarang !== null ? 'Semester ' . $skSekarang : '-' ?></b></div>
  <div class="profil-item"><span class="kecil">Status</span><?= lencana($mh['status_akademik']) ?></div>
  <div class="profil-item"><span class="kecil">IPK terakhir</span><span class="angka-besar"><?= $ipkTerakhir !== null ? h($ipkTerakhir) : '-' ?></span></div>
  <div class="profil-item"><span class="kecil">Email</span><b><?= h($mh['email']) ?></b></div>
  <div class="profil-item"><span class="kecil">No. HP</span><b><?= h($mh['no_hp']) ?></b></div>
  <div class="profil-item"><span class="kecil">Asal sekolah</span><b><?= h($mh['asal_sekolah']) ?></b></div>
</div>

<?php if ($mh['status_akademik'] === 'lulus'): ?>
<div class="kotak-info kotak-lulus">🎓 Kamu dinyatakan <b>lulus</b><?= $mh['tgl_lulus'] ? ' pada ' . h(tgl_id($mh['tgl_lulus'])) : '' ?>. Selamat!</div>
<?php elseif ($perkiraanLulus !== null): ?>
<div class="kotak-info">🎓 Perkiraan lulus: <b>paling cepat tahun <?= (int)$perkiraanLulus ?></b>
  (masa studi minimal <?= (int)$lamaStudi ?> tahun / <?= (int)$lamaStudi * 2 ?> semester untuk <?= h($mh['jenjang']) ?>, dihitung dari angkatan <?= $angkatanM ?>).</div>
<?php else: ?>
<div class="kotak-info">🎓 Angkatan belum diisi, jadi perkiraan tahun lulus belum bisa dihitung. Hubungi admin.</div>
<?php endif; ?>

<p style="margin-top:14px"><a class="btn" href="profil.php">Edit profil</a></p>
</div>

<div class="card">
<h3>Absensi per Mata Kuliah</h3>
<?php if (!$semAll): ?>
  <p class="kecil">Belum ada data semester.</p>
<?php else: ?>
<form method="get" action="portal.php#akademik" class="inline">
  <div><label>Semester</label><select name="sem" onchange="this.form.submit()">
    <?php foreach ($semAll as $sx): ?><option value="<?= (int)$sx['id_semester'] ?>" <?= $semPilihM === (int)$sx['id_semester'] ? 'selected' : '' ?>><?= h($sx['tahun_akademik']) ?> <?= h($sx['jenis']) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Program studi</label><input value="<?= h($mh['nama_prodi']) ?> (<?= h($mh['jenjang']) ?>)" readonly tabindex="-1"></div>
</form>
<p class="kecil">Setiap mata kuliah memiliki <?= JUMLAH_PERTEMUAN ?> pertemuan per semester.<?= $skDipilih !== null ? ' Pada semester ini kamu berada di semester perkuliahan ke-' . (int)$skDipilih . '.' : '' ?></p>
<div class="scroll"><table>
<tr><th>Kode</th><th>Mata kuliah</th><th>Hadir</th><th>Izin</th><th>Sakit</th><th>Alpa</th><th>Kehadiran</th></tr>
<?php foreach ($absensi as $r): $persenMk = (int)$r['hadir'] / JUMLAH_PERTEMUAN * 100; ?>
<tr>
  <td><?= h($r['kode_mk']) ?></td><td><?= h($r['nama_mk']) ?></td>
  <td><b><?= (int)$r['hadir'] ?>/<?= JUMLAH_PERTEMUAN ?></b></td>
  <td><?= (int)$r['izin'] ?></td><td><?= (int)$r['sakit'] ?></td><td><?= (int)$r['alpa'] ?></td>
  <td><?= bar_hadir($persenMk) ?></td>
</tr>
<?php endforeach; ?>
<?php if (!$absensi): ?><tr><td colspan="7">Belum ada data absensi pada semester ini.</td></tr><?php endif; ?>
</table></div>
<?php if ($rekap): ?>
<p style="margin-top:10px">Total semester ini: <b><?= (int)$rekap['total_hadir'] ?>/<?= (int)$rekap['total_pertemuan'] ?></b> pertemuan hadir
  (<b><?= h($rekap['persen_hadir']) ?>%</b>).</p>
<?php endif; ?>
<?php endif; ?>
</div>

<div class="card">
<h3>Riwayat Akademik</h3>
<div class="scroll"><table>
<tr><th>Semester</th><th>IPS</th><th>IPK</th></tr>
<?php foreach ($riwayat as $r): ?>
<tr><td><?= h($r['tahun_akademik']) ?> <?= h($r['jenis']) ?></td><td><?= h($r['ips']) ?></td><td><b><?= h($r['ipk']) ?></b></td></tr>
<?php endforeach; ?>
<?php if (!$riwayat): ?><tr><td colspan="3">Belum ada nilai.</td></tr><?php endif; ?>
</table></div>

<?php if ($semRowM): ?>
<h3 style="margin-top:18px">Nilai Mata Kuliah: <?= h($semRowM['tahun_akademik']) ?> <?= h($semRowM['jenis']) ?></h3>
<div class="scroll"><table>
<tr><th>Kode</th><th>Mata kuliah</th><th>SKS</th><th>Nilai</th><th>Huruf</th></tr>
<?php foreach ($nilaiMk as $r): ?>
<tr><td><?= h($r['kode_mk']) ?></td><td><?= h($r['nama_mk']) ?></td><td><?= (int)$r['sks'] ?></td><td><?= h($r['nilai_angka']) ?></td><td><b><?= h($r['huruf']) ?></b></td></tr>
<?php endforeach; ?>
<?php if (!$nilaiMk): ?><tr><td colspan="5">Belum ada nilai mata kuliah pada semester ini.</td></tr><?php endif; ?>
</table></div>
<p class="kecil">Semester dipilih lewat menu Semester di kartu Absensi di atas.</p>
<?php endif; ?>
</div>

<div class="card">
<h3>Riwayat Tagihan</h3>
<div class="scroll"><table>
<tr><th>Tanggal</th><th>Jenis</th><th>Nominal</th><th>Status</th></tr>
<?php foreach ($tagihan as $tg): ?>
<tr><td><?= h($tg['tgl_bayar']) ?></td>
<td><?= h(ucwords(strtolower(str_replace('_', ' ', (string)$tg['jenis_bayar'])))) ?></td>
<td>Rp<?= number_format((int)$tg['nominal'], 0, ',', '.') ?></td>
<td><?= lencana($tg['status']) ?></td></tr>
<?php endforeach; ?>
<?php if (!$tagihan): ?><tr><td colspan="4">Belum ada tagihan atau pembayaran.</td></tr><?php endif; ?>
</table></div>
<?php if ($tagihan): ?><p style="margin-top:10px">Total yang sudah lunas: <b>Rp<?= number_format($totalLunas, 0, ',', '.') ?></b></p><?php endif; ?>
</div>