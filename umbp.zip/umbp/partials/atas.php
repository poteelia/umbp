<?php
// Pakai: $judul = '...'; require 'partials/atas.php';
$hal = basename($_SERVER['SCRIPT_NAME']);
$svg = fn($isi) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . $isi . '</svg>';
$ikon = [
  'dashboard'   => $svg('<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>'),
  'pendaftaran' => $svg('<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h8"/>'),
  'jadwal'      => $svg('<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>'),
  'organisasi'  => $svg('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>'),
  'nilai'       => $svg('<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>'),
  'terbaik'     => $svg('<circle cx="12" cy="8" r="6"/><path d="M15.5 13.5 17 22l-5-3-5 3 1.5-8.5"/>'),
  'absensi'     => $svg('<path d="M9 2h6a1 1 0 0 1 1 1v2H8V3a1 1 0 0 1 1-1z"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 14l2 2 4-4"/>'),
  'profil'      => $svg('<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>'),
  'tagihan'     => $svg('<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>'),
  'keluar'      => $svg('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>'),
];
$peranku = $_SESSION['user']['peran'];
$menu = [
  'dashboard.php'       => ['dashboard', 'Dashboard', ['admin', 'panitia', 'kemahasiswaan']],
  'portal.php'          => ['dashboard', 'Dashboard', ['calon']],
  'pendaftaran_saya.php' => ['pendaftaran', 'Pendaftaran', ['calon']],
  'absensi_saya.php'    => ['absensi', 'Absensi', ['calon']],
  'profil.php'          => ['profil', 'Profil Mahasiswa', ['calon']],
  'akademik_saya.php'   => ['nilai', 'Riwayat Akademik', ['calon']],
  'tagihan_saya.php'    => ['tagihan', 'Riwayat Tagihan', ['calon']],
  'organisasi_saya.php' => ['organisasi', 'Organisasi', ['calon']],
  'pendaftaran.php'     => ['pendaftaran', 'Pendaftaran', ['admin', 'panitia']],
  'jadwal_seleksi.php'  => ['jadwal', 'Jadwal Seleksi', ['admin', 'panitia']],
  'tahap_lanjut.php'    => ['jadwal', 'Seleksi Lanjutan', ['admin', 'panitia']],
  'organisasi.php'      => ['organisasi', 'Organisasi', ['admin', 'kemahasiswaan']],
  'organisasi_pendaftar.php' => ['organisasi', 'Anggota Organisasi', ['admin', 'kemahasiswaan']],
  'matakuliah.php'      => ['nilai', 'Mata Kuliah', ['admin', 'kemahasiswaan']],
  'nilai.php'           => ['nilai', 'Nilai dan Absensi', ['admin', 'kemahasiswaan']],
  'terbaik.php'         => ['terbaik', 'Mahasiswa Terbaik', ['admin', 'kemahasiswaan']],
];
// Menu aktif: cocok persis dulu; kalau tidak ada (mis. halaman detail), cocokkan awalan nama file
$aktif = isset($menu[$hal]) ? $hal : '';
if ($aktif === '') {
    foreach ($menu as $f => $m) { if (strpos($hal, basename($f, '.php')) === 0) $aktif = $f; }
}
if ($hal === 'daftar_data.php') $aktif = 'pendaftaran_saya.php';
$pintu = !empty($_SESSION['pintu']);
unset($_SESSION['pintu']);
$kelasBody = trim(($pintu ? 'baru-masuk ' : '') . ($peranku === 'calon' ? 'peran-calon' : ''));
?>
<!DOCTYPE html><html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($judul ?? 'SI Kemahasiswaan UMBP') ?></title>
<link rel="stylesheet" href="style.css">
<style>.peran-calon .main h2{font-size:32px;line-height:1.2}</style></head>
<body class="<?= h($kelasBody) ?>">
<?php if ($pintu): ?>
<div class="pintu"><span>Selamat datang, <?= h($_SESSION['user']['nama']) ?></span><i class="kr"></i><i class="kn"></i></div>
<?php endif; ?>
<div class="app">
<aside class="side">
  <div class="brand">
    <div class="emblem"><?php require __DIR__ . '/logo.php'; ?></div>
    <b>SI Kemahasiswaan</b>
  </div>
  <nav class="menu">
  <?php foreach ($menu as $file => [$k, $nama, $roles]): ?>
    <?php if ($roles && !in_array($peranku, $roles)) continue; ?>
    <a href="<?= $file ?>" class="<?= $aktif === $file ? 'on' : '' ?>"><?= $ikon[$k] ?> <?= $nama ?></a>
  <?php endforeach; ?>
  </nav>
  <div class="bawah-menu">
    <div class="who"><?= h($_SESSION['user']['nama']) ?><br>(<?= h($peranku) ?>)</div>
    <nav class="menu"><a href="logout.php"><?= $ikon['keluar'] ?> Keluar</a></nav>
  </div>
</aside>
<main class="main">