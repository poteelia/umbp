<?php
// Cari logo di folder utama (png, jpg, jpeg, webp); jika tidak ada, pakai lambang SVG sementara
$logo = null;
foreach (['png', 'jpg', 'jpeg', 'webp'] as $ext) {
    if (file_exists(__DIR__ . '/../logo.' . $ext)) { $logo = 'logo.' . $ext; break; }
}
if ($logo): ?>
<img src="<?= $logo ?>" alt="Logo UMBP">
<?php else: ?>
<svg viewBox="0 0 64 64" role="img" aria-label="UMBP">
<path d="M32 4 56 12v18c0 15-10 26-24 30C18 56 8 45 8 30V12z" fill="#8f0b06"/>
<path d="M32 10 50 16v14c0 11-7 19-18 23C21 49 14 41 14 30V16z" fill="none" stroke="#f5b04c" stroke-width="2"/>
<text x="32" y="38" text-anchor="middle" font-family="Segoe UI,Arial" font-size="14" font-weight="800" fill="#fff">UMBP</text>
</svg>
<?php endif; ?>