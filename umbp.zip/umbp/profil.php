<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/mahasiswa.php';
wajib_login(['calon']);
$uid = (int)$_SESSION['user']['id'];
$idc = id_calon_akun($db);
if (!$idc) { header('Location: daftar_data.php'); exit; }

$c = $db->query("SELECT c.nama, c.jenis_kelamin, c.email, c.no_hp, c.asal_sekolah, c.tahun_lulus,
        (SELECT ps.nama_prodi FROM pendaftaran p JOIN program_studi ps ON ps.id_prodi = p.id_prodi
          WHERE p.id_calon = c.id_calon ORDER BY p.id_pendaftaran DESC LIMIT 1) AS prodi_daftar
    FROM calon_mahasiswa c WHERE c.id_calon = $idc")->fetch_assoc();
if (!$c) { header('Location: portal.php'); exit; }

$err = ''; $errPw = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'profil') {
        $nama = trim($_POST['nama'] ?? '');
        $jk = $_POST['jenis_kelamin'] ?? '';
        $hp = trim($_POST['no_hp'] ?? '');
        $asal = trim($_POST['asal_sekolah'] ?? '');
        if ($nama === '' || mb_strlen($nama) > 100) $err = 'Nama wajib diisi (maksimal 100 karakter).';
        elseif (!in_array($jk, ['L', 'P'], true)) $err = 'Jenis kelamin tidak valid.';
        elseif (!preg_match('/^[0-9+\-\s]{8,15}$/', $hp)) $err = 'No. HP tidak valid (8 sampai 15 karakter: angka, + atau -).';
        elseif ($asal === '' || mb_strlen($asal) > 100) $err = 'Asal sekolah wajib diisi (maksimal 100 karakter).';
        else {
            try {
                $db->begin_transaction();
                $s = $db->prepare('UPDATE calon_mahasiswa SET nama = ?, jenis_kelamin = ?, no_hp = ?, asal_sekolah = ? WHERE id_calon = ?');
                $s->bind_param('ssssi', $nama, $jk, $hp, $asal, $idc); $s->execute();
                $s = $db->prepare('UPDATE pengguna SET nama = ? WHERE id_pengguna = ?');
                $s->bind_param('si', $nama, $uid); $s->execute();
                $s = $db->prepare('UPDATE mahasiswa SET nama = ? WHERE id_calon = ?');
                $s->bind_param('si', $nama, $idc); $s->execute();
                $db->commit();
                $_SESSION['user']['nama'] = $nama;
                flash('ok', 'Profil berhasil diperbarui.');
                header('Location: profil.php'); exit;
            } catch (mysqli_sql_exception $e) { $db->rollback(); $err = galat_sql($e); }
        }
        $c['nama'] = $nama; $c['jenis_kelamin'] = $jk; $c['no_hp'] = $hp; $c['asal_sekolah'] = $asal;   // tampilkan isian terakhir

    } elseif ($aksi === 'password') {
        $lama = $_POST['password_lama'] ?? '';
        $baru = $_POST['password_baru'] ?? '';
        $ulang = $_POST['password_ulang'] ?? '';
        $row = $db->query("SELECT password FROM pengguna WHERE id_pengguna = $uid")->fetch_row();
        if (!$row || !password_verify($lama, $row[0])) $errPw = 'Password lama salah.';
        elseif (strlen($baru) < 8) $errPw = 'Password baru minimal 8 karakter.';
        elseif ($baru !== $ulang) $errPw = 'Konfirmasi password baru tidak sama.';
        else {
            $hash = password_hash($baru, PASSWORD_DEFAULT);
            $s = $db->prepare('UPDATE pengguna SET password = ? WHERE id_pengguna = ?');
            $s->bind_param('si', $hash, $uid); $s->execute();
            flash('ok', 'Password berhasil diubah.');
            header('Location: profil.php'); exit;
        }
    }
}

// Data akademik untuk ringkasan (hanya jika sudah punya NIM)
$mh = data_mahasiswa($db, $idc);
$ipkTerakhir = null; $skSekarang = null;
if ($mh) {
    $q = $db->prepare('SELECT ipk FROM nilai_semester WHERE nim = ? ORDER BY id_semester DESC LIMIT 1');
    $nimM = (string)$mh['nim'];
    $q->bind_param('s', $nimM); $q->execute();
    $r = $q->get_result()->fetch_row(); $q->close();
    $ipkTerakhir = $r ? $r[0] : null;
    $semAll = daftar_semester($db);
    if ($semAll) {
        $skSekarang = semester_ke($mh['angkatan'] !== null ? (int)$mh['angkatan'] : null, (string)$semAll[0]['tahun_akademik'], (string)$semAll[0]['jenis']);
    }
}

$judul = 'Profil Mahasiswa';
require 'partials/atas.php';
?>
<style>
input[readonly]{background:#f1ecea;color:#333;cursor:not-allowed;font-weight:600}
.angka-besar{font-size:22px;font-weight:700;color:#8b0d0d}
.kpi .kecil{display:block}
</style>

<div class="card">
<h2>Profil Mahasiswa</h2>
<?php tampil_flash(); ?>
<div class="grid">
  <div class="kpi"><span class="kecil">Nama</span><b><?= h($mh['nama'] ?? $c['nama']) ?></b></div>
  <div class="kpi"><span class="kecil">NIM</span><b><?= $mh ? h($mh['nim']) : 'Belum tercatat' ?></b></div>
  <div class="kpi"><span class="kecil">Program studi</span><b><?= $mh ? h($mh['nama_prodi']) . ' (' . h($mh['jenjang']) . ')' : h($c['prodi_daftar'] ?? '-') ?></b></div>
  <div class="kpi"><span class="kecil">Angkatan</span><b><?= $mh && $mh['angkatan'] !== null ? (int)$mh['angkatan'] : '-' ?></b></div>
  <div class="kpi"><span class="kecil">Semester berjalan</span><b><?= $skSekarang !== null ? 'Semester ' . $skSekarang : '-' ?></b></div>
  <div class="kpi"><span class="kecil">Status</span><?= $mh ? lencana($mh['status_akademik']) : '<span class="badge b-wait">calon</span>' ?></div>
  <div class="kpi"><span class="kecil">IPK terakhir</span><span class="angka-besar"><?= $ipkTerakhir !== null ? h($ipkTerakhir) : '-' ?></span></div>
  <div class="kpi"><span class="kecil">Email</span><b><?= h($c['email']) ?></b></div>
  <div class="kpi"><span class="kecil">No. HP</span><b><?= h($c['no_hp']) ?></b></div>
  <div class="kpi"><span class="kecil">Asal sekolah</span><b><?= h($c['asal_sekolah']) ?></b></div>
  <div class="kpi"><span class="kecil">Tahun lulus sekolah</span><b><?= h($c['tahun_lulus']) ?></b></div>
</div>
<?= $mh ? kotak_lulus($mh) : '' ?>
</div>

<div class="card">
<h3>Edit Profil</h3>
<?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>
<form method="post">
<input type="hidden" name="aksi" value="profil">
<label>Nama lengkap</label><input name="nama" required maxlength="100" value="<?= h($c['nama']) ?>">
<div class="row2">
  <div><label>Jenis kelamin</label><select name="jenis_kelamin">
    <option value="L" <?= $c['jenis_kelamin'] === 'L' ? 'selected' : '' ?>>Laki-laki</option>
    <option value="P" <?= $c['jenis_kelamin'] === 'P' ? 'selected' : '' ?>>Perempuan</option>
  </select></div>
  <div><label>No. HP</label><input name="no_hp" required maxlength="15" value="<?= h($c['no_hp']) ?>"></div>
</div>
<div class="row2">
  <div><label>Email (dipakai untuk login)</label><input value="<?= h($c['email']) ?>" readonly tabindex="-1"></div>
  <div><label>Tahun lulus sekolah</label><input value="<?= h($c['tahun_lulus']) ?>" readonly tabindex="-1"></div>
</div>
<label>Asal sekolah</label><input name="asal_sekolah" required maxlength="100" value="<?= h($c['asal_sekolah']) ?>">
<button>Simpan perubahan</button>
</form>
<p class="kecil">Email dan tahun lulus sekolah tidak bisa diubah sendiri. Hubungi admin bila perlu perubahan.</p>
</div>

<div class="card">
<h3>Ubah Password</h3>
<?php if ($errPw): ?><div class="err"><?= h($errPw) ?></div><?php endif; ?>
<form method="post" autocomplete="off">
<input type="hidden" name="aksi" value="password">
<label>Password lama</label><input type="password" name="password_lama" required>
<div class="row2">
  <div><label>Password baru</label><input type="password" name="password_baru" required minlength="8"></div>
  <div><label>Ulangi password baru</label><input type="password" name="password_ulang" required minlength="8"></div>
</div>
<button>Ubah password</button>
</form>
</div>
<?php require 'partials/bawah.php'; ?>