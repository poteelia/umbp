<?php
require 'config/koneksi.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama  = trim($_POST['nama'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $pw    = $_POST['password'] ?? '';
    if ($nama === '') $err = 'Nama wajib diisi.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Email tidak valid.';
    elseif (strlen($pw) < 8) $err = 'Password minimal 8 karakter.';
    elseif ($pw !== ($_POST['password2'] ?? '')) $err = 'Konfirmasi password tidak sama.';
    else {
        // Cek email di tabel pengguna (hasil dibaca dulu, lalu statement ditutup)
        $a = $db->prepare('SELECT 1 FROM pengguna WHERE username = ?');
        $a->bind_param('s', $email);
        $a->execute();
        $adaAkun = (bool)$a->get_result()->fetch_row();
        $a->close();

        // Cek email di tabel calon_mahasiswa
        $b = $db->prepare('SELECT 1 FROM calon_mahasiswa WHERE email = ?');
        $b->bind_param('s', $email);
        $b->execute();
        $adaCalon = (bool)$b->get_result()->fetch_row();
        $b->close();

        if ($adaAkun || $adaCalon) {
            $err = 'Email sudah terdaftar.';
        } else {
            try {
                $hash = password_hash($pw, PASSWORD_DEFAULT);
                $peran = 'calon';
                $s = $db->prepare('INSERT INTO pengguna (username, password, nama, peran) VALUES (?,?,?,?)');
                $s->bind_param('ssss', $email, $hash, $nama, $peran);
                $s->execute();
                header('Location: login.php?daftar=1'); exit;
            } catch (mysqli_sql_exception $e) {
                $err = ($e->getCode() == 1062) ? 'Email sudah terdaftar.' : 'Gagal membuat akun: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html><html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Buat Akun - SI Kemahasiswaan UMBP</title><link rel="stylesheet" href="style.css"></head>
<body class="login-page"><div class="lcard">
<div class="emblem big"><?php require 'partials/logo.php'; ?></div>
<h1>Buat Akun Pendaftaran</h1>
<p>Gunakan email aktif, email ini menjadi username kamu</p>
<?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>
<form method="post">
<label>Nama lengkap</label><input name="nama" required autofocus value="<?= h($_POST['nama'] ?? '') ?>">
<label>Email</label><input name="email" type="email" required value="<?= h($_POST['email'] ?? '') ?>">
<label>Password</label><input name="password" type="password" required minlength="8">
<label>Ulangi password</label><input name="password2" type="password" required minlength="8">
<button>Buat Akun</button></form>
<p><a href="login.php">Sudah punya akun? Masuk</a></p>
</div></body></html>