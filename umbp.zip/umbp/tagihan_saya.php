<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/mahasiswa.php';
wajib_login(['calon']);
$idc = id_calon_akun($db);
if (!$idc) { header('Location: daftar_data.php'); exit; }

$q = $db->prepare('SELECT y.jenis_bayar, y.nominal, y.tgl_bayar, y.status
    FROM pembayaran y JOIN pendaftaran x ON x.id_pendaftaran = y.id_pendaftaran
    WHERE x.id_calon = ? ORDER BY y.tgl_bayar DESC');
$q->bind_param('i', $idc); $q->execute();
$tagihan = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();

$totalLunas = 0; $totalMenunggu = 0;
foreach ($tagihan as $tg) {
    if ($tg['status'] === 'lunas') $totalLunas += (int)$tg['nominal'];
    else $totalMenunggu += (int)$tg['nominal'];
}

$judul = 'Riwayat Tagihan';
require 'partials/atas.php';
?>
<style>.angka-besar{font-size:24px;font-weight:700;color:#8b0d0d}.kpi .kecil{display:block}</style>

<div class="card">
<h2>Riwayat Tagihan</h2>
<?php tampil_flash(); ?>
<div class="grid">
  <div class="kpi"><span class="kecil">Total lunas</span><span class="angka-besar">Rp<?= number_format($totalLunas, 0, ',', '.') ?></span></div>
  <div class="kpi"><span class="kecil">Belum lunas / menunggu verifikasi</span><span class="angka-besar">Rp<?= number_format($totalMenunggu, 0, ',', '.') ?></span></div>
  <div class="kpi"><span class="kecil">Jumlah transaksi</span><span class="angka-besar"><?= count($tagihan) ?></span></div>
</div>
</div>

<div class="card">
<div class="scroll"><table>
<tr><th>Tanggal</th><th>Jenis</th><th>Nominal</th><th>Status</th></tr>
<?php foreach ($tagihan as $tg): ?>
<tr>
  <td><?= h($tg['tgl_bayar']) ?></td>
  <td><?= h(ucwords(strtolower(str_replace('_', ' ', (string)$tg['jenis_bayar'])))) ?></td>
  <td>Rp<?= number_format((int)$tg['nominal'], 0, ',', '.') ?></td>
  <td><?= lencana($tg['status']) ?></td>
</tr>
<?php endforeach; ?>
<?php if (!$tagihan): ?><tr><td colspan="4">Belum ada tagihan atau pembayaran.</td></tr><?php endif; ?>
</table></div>
</div>
<?php require 'partials/bawah.php'; ?>