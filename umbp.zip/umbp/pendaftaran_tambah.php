<?php
require 'config/koneksi.php'; require 'config/bantu.php';
wajib_login(['admin', 'panitia']);

$prodi = $db->query('SELECT * FROM program_studi ORDER BY id_prodi')->fetch_all(MYSQLI_ASSOC);
$jalur = $db->query('SELECT * FROM jalur_pendaftaran ORDER BY id_jalur')->fetch_all(MYSQLI_ASSOC);
$skema = $db->query('SELECT * FROM skema_pembayaran ORDER BY jenjang, id_skema')->fetch_all(MYSQLI_ASSOC);

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_prodi = (int)$_POST['id_prodi'];
    $id_jalur = (int)$_POST['id_jalur'];
    $kode_ref = trim($_POST['kode_referal']) !== '' ? trim($_POST['kode_referal']) : null;

    $pj = array_values(array_filter($jalur, fn($x) => $x['id_jalur'] == $id_jalur))[0] ?? null;
    $pp = array_values(array_filter($prodi, fn($x) => $x['id_prodi'] == $id_prodi))[0] ?? null;

    // Skema pembayaran hanya untuk jalur Reguler; jalur beasiswa tidak memakai skema
    $id_skema = ($pj && $pj['pakai_gelombang'] && ($_POST['id_skema'] ?? '') !== '') ? (int)$_POST['id_skema'] : null;

    if (!$pj || !$pp) {
        $err = 'Prodi atau jalur tidak valid.';
    } elseif ($id_skema) {
        $sk = array_values(array_filter($skema, fn($x) => $x['id_skema'] == $id_skema))[0] ?? null;
        if (!$sk || $sk['jenjang'] !== $pp['jenjang']) {
            $err = 'Skema pembayaran harus sesuai jenjang prodi (' . $pp['jenjang'] . ').';
        }
    }

    if ($err === '') {
        try {
            $db->begin_transaction();
            $st = $db->prepare('INSERT INTO calon_mahasiswa
                (nama, jenis_kelamin, email, no_hp, asal_sekolah, tahun_lulus) VALUES (?,?,?,?,?,?)');
            $st->bind_param('sssssi', $_POST['nama'], $_POST['jenis_kelamin'], $_POST['email'],
                $_POST['no_hp'], $_POST['asal_sekolah'], $_POST['tahun_lulus']);
            $st->execute();
            $id_calon = $db->insert_id;

            $st = $db->prepare("INSERT INTO pendaftaran
                (id_calon, id_prodi, id_jalur, id_skema, tgl_daftar, kode_referal, status_administrasi)
                VALUES (?,?,?,?,CURDATE(),?, 'menunggu')");
            $st->bind_param('iiiis', $id_calon, $id_prodi, $id_jalur, $id_skema, $kode_ref);
            $st->execute();
            $db->commit();

            flash('ok', 'Pendaftaran tersimpan. Tekan ACC di daftar untuk menetapkan gelombang dan jadwal.');
            header('Location: pendaftaran.php'); exit;
        } catch (mysqli_sql_exception $e) {
            $db->rollback();
            $err = ($e->getCode() == 1062) ? 'Email sudah terdaftar.' : 'Gagal menyimpan: ' . $e->getMessage();
        }
    }
}

$judul = 'Daftar Calon Mahasiswa';
require 'partials/atas.php';
?>
<div class="card">
<h2>Formulir Pendaftaran Mahasiswa Baru</h2>
<?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>
<p class="kecil">Gelombang dan jadwal ujian/wawancara ditetapkan otomatis saat administrasi di-ACC. Skema pembayaran hanya untuk jalur Reguler.</p>
<form method="post">
<label>Nama lengkap</label>
<input name="nama" required value="<?= h($_POST['nama'] ?? '') ?>">
<div class="row2">
  <div><label>Jenis kelamin</label>
  <select name="jenis_kelamin"><option value="L">Laki-laki</option><option value="P">Perempuan</option></select></div>
  <div><label>Tahun lulus</label>
  <input name="tahun_lulus" type="number" min="2000" max="2100" required value="<?= h($_POST['tahun_lulus'] ?? date('Y')) ?>"></div>
</div>
<div class="row2">
  <div><label>Email</label><input name="email" type="email" required value="<?= h($_POST['email'] ?? '') ?>"></div>
  <div><label>No. HP</label><input name="no_hp" required maxlength="15" value="<?= h($_POST['no_hp'] ?? '') ?>"></div>
</div>
<label>Asal sekolah</label>
<input name="asal_sekolah" required value="<?= h($_POST['asal_sekolah'] ?? '') ?>">

<label>Program studi</label>
<select name="id_prodi" required>
<?php foreach ($prodi as $p): ?>
  <option value="<?= $p['id_prodi'] ?>"><?= h($p['nama_prodi']) ?> (<?= h($p['jenjang']) ?>)</option>
<?php endforeach; ?>
</select>

<label>Jalur pendaftaran</label>
<select name="id_jalur" required>
<?php foreach ($jalur as $j): ?>
  <option value="<?= $j['id_jalur'] ?>" data-reguler="<?= $j['pakai_gelombang'] ? 1 : 0 ?>" <?= (string)($_POST['id_jalur'] ?? '') === (string)$j['id_jalur'] ? 'selected' : '' ?>><?= h($j['nama_jalur']) ?></option>
<?php endforeach; ?>
</select>

<div id="blok-reguler">
<label>Skema pembayaran</label>
<select name="id_skema">
<option value="">- belum dipilih -</option>
<?php foreach ($skema as $s): ?>
  <option value="<?= $s['id_skema'] ?>"><?= h($s['jenjang']) ?> - <?= h($s['jenis']) ?> (Rp<?= number_format($s['nominal_cicilan'], 0, ',', '.') ?><?= $s['diskon_persen'] > 0 ? ', diskon ' . (float)$s['diskon_persen'] . '%' : '' ?>)</option>
<?php endforeach; ?>
</select>
</div>

<label>Kode referal (opsional)</label>
<input name="kode_referal" maxlength="20" value="<?= h($_POST['kode_referal'] ?? '') ?>">
<button>Simpan Pendaftaran</button>
</form></div>
<script>
(function () {
  var jalur = document.querySelector('[name=id_jalur]');
  var blok = document.getElementById('blok-reguler');
  function ubah() {
    var reguler = jalur.options[jalur.selectedIndex].dataset.reguler === '1';
    blok.style.display = reguler ? '' : 'none';
    blok.querySelectorAll('select').forEach(function (s) { s.disabled = !reguler; });
  }
  jalur.addEventListener('change', ubah);
  ubah();
})();
</script>
<?php require 'partials/bawah.php'; ?>