<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/upload.php';
if (!defined('BIAYA_PENDAFTARAN')) define('BIAYA_PENDAFTARAN', 300000);   // biaya pendaftaran semua jalur (Rp)
wajib_login(['calon']);
$uid = (int)$_SESSION['user']['id'];
$idc = (int)$db->query("SELECT COALESCE(id_calon,0) FROM pengguna WHERE id_pengguna = $uid")->fetch_row()[0];
if (!$idc) { header('Location: daftar_data.php'); exit; }

$d = $db->query("SELECT p.id_pendaftaran, p.id_jalur, p.status_administrasi, p.status,
    p.hasil_wawancara, p.nilai_wawancara, p.catatan_wawancara,
    c.nama, ps.nama_prodi, j.nama_jalur, j.alur, j.bayar_pendaftaran, j.perlu_lldikti, j.perlu_yayasan, g.nama_gelombang
  FROM pendaftaran p
  JOIN calon_mahasiswa c ON c.id_calon = p.id_calon
  JOIN program_studi ps ON ps.id_prodi = p.id_prodi
  JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
  LEFT JOIN gelombang g ON g.id_gelombang = p.id_gelombang
  WHERE p.id_calon = $idc ORDER BY p.id_pendaftaran DESC LIMIT 1")->fetch_assoc();
if (!$d) {
    $db->query("UPDATE pengguna SET id_calon = NULL WHERE id_pengguna = $uid");
    header('Location: daftar_data.php'); exit;
}
$id = (int)$d['id_pendaftaran'];
$khusus = $d['alur'] === 'khusus';
$lulus = $d['status'] === 'lulus';
$perluBayar = true;   // semua jalur dikenakan biaya pendaftaran (BIAYA_PENDAFTARAN)
$bisaUbah = in_array($d['status_administrasi'], ['belum', 'ditolak'], true);
$JENIS = label_berkas();
$wajib = berkas_jalur($db, (int)$d['id_jalur']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!$bisaUbah) throw new RuntimeException('Administrasi sudah diajukan dan tidak bisa diubah.');
        $aksi = $_POST['aksi'] ?? '';
        if ($aksi === 'berkas') {
            $jenis = $_POST['jenis_berkas'] ?? '';
            if (!isset($JENIS[$jenis])) throw new RuntimeException('Jenis berkas tidak valid.');
            $path = simpan_upload('file', 'berkas');
            $s = $db->prepare('INSERT INTO berkas_pendaftaran (id_pendaftaran, jenis_berkas, file_path) VALUES (?,?,?)');
            $s->bind_param('iss', $id, $jenis, $path); $s->execute();
            flash('ok', 'Berkas diunggah.');
        } elseif ($aksi === 'bayar') {
            // Nominal ditetapkan sistem (isian dari form diabaikan): semua jalur membayar BIAYA_PENDAFTARAN
            $nominal = BIAYA_PENDAFTARAN;
            $tgl = trim($_POST['tgl_bayar'] ?? '');
            if (!valid_tanggal($tgl)) throw new RuntimeException('Tanggal bayar tidak valid.');
            $path = simpan_upload('bukti', 'bayar');
            $s = $db->prepare("INSERT INTO pembayaran (id_pendaftaran, jenis_bayar, nominal, tgl_bayar, bukti_path) VALUES (?, 'PENDAFTARAN', ?, ?, ?)");
            $s->bind_param('iiss', $id, $nominal, $tgl, $path); $s->execute();
            flash('ok', 'Bukti pembayaran diunggah.');
        } elseif ($aksi === 'ajukan') {
            $ada = array_column($db->query("SELECT DISTINCT jenis_berkas FROM berkas_pendaftaran WHERE id_pendaftaran = $id")->fetch_all(MYSQLI_ASSOC), 'jenis_berkas');
            $kurang = [];
            foreach ($wajib as $k => $v) { if (!in_array($k, $ada, true)) $kurang[] = $v; }
            if ($kurang) throw new RuntimeException('Berkas wajib belum lengkap: ' . implode(', ', $kurang) . '.');
            $np = (int)$db->query("SELECT COUNT(*) FROM pembayaran WHERE id_pendaftaran = $id AND jenis_bayar = 'PENDAFTARAN'")->fetch_row()[0];
            if ($np < 1) throw new RuntimeException('Unggah bukti pembayaran pendaftaran dulu (Rp' . number_format(BIAYA_PENDAFTARAN, 0, ',', '.') . ').');
            $db->query("UPDATE pendaftaran SET status_administrasi = 'menunggu' WHERE id_pendaftaran = $id");
            flash('ok', 'Berkas diajukan. Tunggu persetujuan admin.');
        }
    } catch (RuntimeException $e) { flash('err', $e->getMessage()); }
    catch (mysqli_sql_exception $e) { flash('err', galat_sql($e)); }
    header('Location: pendaftaran_saya.php'); exit;
}

$berkas = $db->query("SELECT jenis_berkas, status_verifikasi FROM berkas_pendaftaran WHERE id_pendaftaran = $id")->fetch_all(MYSQLI_ASSOC);
$sudah = array_column($berkas, 'jenis_berkas');
$bayar = $db->query("SELECT nominal, tgl_bayar, status FROM pembayaran WHERE id_pendaftaran = $id")->fetch_all(MYSQLI_ASSOC);

// ===== Apakah semuanya sudah di-ACC admin? =====
// Syarat: administrasi disetujui + semua berkas valid + bukti bayar pendaftaran lunas
$bv = $db->query("SELECT COUNT(*) AS total, COALESCE(SUM(status_verifikasi = 'valid'), 0) AS valid
                  FROM berkas_pendaftaran WHERE id_pendaftaran = $id")->fetch_assoc();
$berkasOk = (int)$bv['total'] > 0 && (int)$bv['valid'] === (int)$bv['total'];
$bayarOk  = (int)$db->query("SELECT COUNT(*) FROM pembayaran
                             WHERE id_pendaftaran = $id AND jenis_bayar = 'PENDAFTARAN' AND status = 'lunas'")->fetch_row()[0] > 0;
$semuaAcc = $d['status_administrasi'] === 'disetujui' && $berkasOk && $bayarOk;

$jadwal = $semuaAcc
  ? $db->query("SELECT jenis, tanggal, jam, lokasi, status FROM jadwal_seleksi WHERE id_pendaftaran = $id ORDER BY tanggal, jam")->fetch_all(MYSQLI_ASSOC) : [];
$lembaga = $khusus
  ? $db->query("SELECT lembaga, tanggal, jam, lokasi, status, catatan FROM keputusan_lembaga WHERE id_pendaftaran = $id ORDER BY id_keputusan")->fetch_all(MYSQLI_ASSOC) : [];
$garis = linimasa($db, $d);

$judul = 'Pendaftaran';
require 'partials/atas.php';
?>
<style>
.garis{list-style:none;padding:0;margin:12px 0;display:flex;flex-wrap:wrap;gap:8px}
.garis li{padding:6px 12px;border-radius:20px;font-size:13px;background:#eee;color:#666}
.garis .selesai{background:#d9f2e0;color:#1b6b34}
.garis .sekarang{background:#fff3cd;color:#8a6100;font-weight:600}
.garis .gagal{background:#f8d7da;color:#842029;font-weight:600}
button:disabled{opacity:.5;cursor:not-allowed}
input[readonly]{background:#f1ecea;color:#333;cursor:not-allowed;font-weight:600}
.jadwal-box{border:2px solid #f5b34a;background:#fff8ec;border-radius:14px;padding:16px 18px}
.jadwal-box .gel{display:inline-block;background:#8b0d0d;color:#fff;font-weight:700;padding:6px 16px;border-radius:20px;margin-bottom:12px}
.jadwal-item{display:flex;flex-wrap:wrap;gap:6px 24px;align-items:baseline;padding:10px 0;border-top:1px solid #f0dcb8}
.jadwal-item .jenis{min-width:110px;font-weight:700;color:#8b0d0d;text-transform:capitalize}
.jadwal-item .tgl{font-size:18px;font-weight:700}
.jadwal-item .kecil{margin:0}
.info-tunggu{background:#eef4ff;color:#1f4a8a;padding:12px 16px;border-radius:10px;font-size:14px}
</style>

<div class="card">
<h2>Halo, <?= h($d['nama']) ?></h2>
<?php tampil_flash(); ?>
<p>Prodi: <b><?= h($d['nama_prodi']) ?></b> | Jalur: <b><?= h($d['nama_jalur']) ?></b></p>
<ul class="garis">
<?php foreach ($garis as [$label, $st]): ?><li class="<?= h($st) ?>"><?= h($label) ?></li><?php endforeach; ?>
</ul>
<p>Status administrasi: <?= lencana($d['status_administrasi']) ?> | Status akhir: <?= lencana($d['status']) ?></p>
<?php if ($d['status_administrasi'] === 'ditolak'): ?><div class="err">Administrasi ditolak. Perbaiki berkas atau pembayaran, lalu ajukan lagi.</div><?php endif; ?>
</div>

<?php if ($lulus): ?>
<div class="card">
<div class="ok">🎉 Selamat, kamu dinyatakan <b>lulus</b>!</div>
<p>Pilih organisasi kemahasiswaan di menu <a href="organisasi_saya.php"><b>Organisasi</b></a>. Absensi, nilai, profil, dan tagihanmu bisa dilihat di menu di sebelah kiri.</p>
</div>
<?php endif; ?>

<?php /* ===== Jadwal seleksi: tampil setelah semuanya di-ACC ===== */ ?>
<?php if ($semuaAcc): ?>
<div class="card">
<h3><?= $khusus ? 'Jadwal Wawancara Kamu' : 'Gelombang dan Jadwal Seleksi Kamu' ?></h3>
<div class="jadwal-box">
  <?php if (!$khusus): ?><div class="gel">📌 <?= h($d['nama_gelombang'] ?? 'Gelombang belum ditentukan') ?></div><?php endif; ?>
  <?php if ($jadwal): ?>
    <?php foreach ($jadwal as $r): ?>
    <div class="jadwal-item">
      <div class="jenis"><?= h($r['jenis']) ?></div>
      <div>
        <div class="tgl"><?= h(tgl_id($r['tanggal'])) ?>, pukul <?= h(substr($r['jam'], 0, 5)) ?> WIB</div>
        <p class="kecil">Lokasi: <?= h($r['lokasi']) ?> | <?= lencana($r['status']) ?></p>
      </div>
    </div>
    <?php endforeach; ?>
    <p class="kecil" style="margin-top:12px">Harap hadir 15 menit lebih awal dan membawa kartu identitas.</p>
  <?php else: ?>
    <p>Jadwal sedang disiapkan oleh panitia. Silakan cek kembali nanti.</p>
  <?php endif; ?>
</div>
</div>
<?php elseif ($d['status_administrasi'] === 'menunggu'): ?>
<div class="card">
<h3>Jadwal Seleksi</h3>
<div class="info-tunggu">⏳ Berkas dan pembayaranmu sedang diperiksa admin. Gelombang, tanggal, dan jam seleksi akan muncul di sini setelah semuanya disetujui.</div>
</div>
<?php elseif ($d['status_administrasi'] === 'disetujui'): ?>
<div class="card">
<h3>Jadwal Seleksi</h3>
<div class="info-tunggu">⏳ Administrasimu sudah disetujui, tetapi masih ada berkas atau pembayaran yang belum dinyatakan valid/lunas oleh admin. Jadwal akan muncul setelah semuanya selesai diverifikasi.</div>
</div>
<?php endif; ?>

<?php if ($khusus && $d['hasil_wawancara'] !== 'belum'): ?>
<div class="card">
<h3>Hasil Wawancara</h3>
<p><?= lencana($d['hasil_wawancara']) ?><?= $d['nilai_wawancara'] !== null ? ' | Nilai: <b>' . (int)$d['nilai_wawancara'] . '</b>' : '' ?></p>
<?php if ($d['catatan_wawancara']): ?><p class="kecil">Catatan: <?= h($d['catatan_wawancara']) ?></p><?php endif; ?>
</div>
<?php endif; ?>

<?php if ($lembaga): ?>
<div class="card">
<h3>Verifikasi LLDIKTI dan Yayasan</h3>
<div class="scroll"><table>
<tr><th>Lembaga</th><th>Hari dan tanggal</th><th>Jam</th><th>Lokasi</th><th>Status</th><th>Catatan</th></tr>
<?php foreach ($lembaga as $r): ?>
<tr><td><?= h(strtoupper($r['lembaga'])) ?></td><td><?= h(tgl_id($r['tanggal'])) ?></td><td><?= h(substr($r['jam'], 0, 5)) ?></td><td><?= h($r['lokasi']) ?></td><td><?= lencana($r['status']) ?></td><td><?= h($r['catatan'] ?? '-') ?></td></tr>
<?php endforeach; ?>
</table></div></div>
<?php endif; ?>

<div class="card">
<h3>Berkas <?= $khusus ? 'Persyaratan Jalur ' . h($d['nama_jalur']) : 'Pendaftaran' ?></h3>
<p class="kecil">Berkas wajib:</p>
<?php foreach ($wajib as $k => $v): $ok = in_array($k, $sudah, true); ?>
<div><?= $ok ? '✔' : '✘' ?> <?= h($v) ?></div>
<?php endforeach; ?>
<?php if ($berkas): ?><p class="kecil" style="margin-top:10px">Yang sudah diunggah:</p><?php endif; ?>
<?php foreach ($berkas as $b): ?><div><?= h($JENIS[$b['jenis_berkas']] ?? $b['jenis_berkas']) ?> <?= lencana($b['status_verifikasi']) ?></div><?php endforeach; ?>
<?php if (!$berkas): ?><p class="kecil">Belum ada berkas.</p><?php endif; ?>
<?php if ($bisaUbah): ?>
<form method="post" enctype="multipart/form-data" class="inline">
  <input type="hidden" name="aksi" value="berkas">
  <div><label>Jenis berkas</label><select name="jenis_berkas">
    <?php foreach ($wajib as $k => $v): ?><option value="<?= h($k) ?>"><?= h($v) ?></option><?php endforeach; ?>
    <option value="LAINNYA">Lainnya</option>
  </select></div>
  <div><label>File (PDF/JPG/PNG, maks 2 MB)</label><input type="file" name="file" required></div>
  <button>Unggah</button>
</form>
<?php endif; ?>
</div>

<div class="card">
<h3>Pembayaran Pendaftaran</h3>
<p>Biaya pendaftaran semua jalur: <b>Rp<?= number_format(BIAYA_PENDAFTARAN, 0, ',', '.') ?></b></p>
<?php foreach ($bayar as $b): ?><div>Rp<?= number_format($b['nominal'], 0, ',', '.') ?> (<?= h($b['tgl_bayar']) ?>) <?= lencana($b['status']) ?></div><?php endforeach; ?>
<?php if (!$bayar): ?><p class="kecil">Belum ada pembayaran.</p><?php endif; ?>
<?php if ($bisaUbah): ?>
<form method="post" enctype="multipart/form-data" class="inline" autocomplete="off">
  <input type="hidden" name="aksi" value="bayar">
  <div><label>Nominal (ditetapkan sistem)</label><input type="text" value="Rp<?= number_format(BIAYA_PENDAFTARAN, 0, ',', '.') ?>" readonly tabindex="-1"></div>
  <div><label>Tanggal bayar</label><input type="date" name="tgl_bayar" value="<?= date('Y-m-d') ?>" required></div>
  <div><label>Bukti bayar</label><input type="file" name="bukti" required></div>
  <button>Unggah</button>
</form>
<?php endif; ?>
</div>

<?php if ($bisaUbah): ?>
<div class="card">
<h3>Ajukan ke Admin</h3>
<p class="kecil">Setelah diajukan, berkas dan pembayaran tidak bisa diubah sampai admin memproses.</p>
<form method="post"><input type="hidden" name="aksi" value="ajukan"><button style="width:auto">Ajukan</button></form>
</div>
<?php endif; ?>
<?php require 'partials/bawah.php'; ?>