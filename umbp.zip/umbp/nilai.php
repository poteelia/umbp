<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/akademik.php';
wajib_login(['admin', 'kemahasiswaan']);

$semester = $db->query('SELECT * FROM semester ORDER BY id_semester')->fetch_all(MYSQLI_ASSOC);
$sem = (int)($_GET['sem'] ?? 0);
if (!$sem && $semester) $sem = (int)end($semester)['id_semester'];
$semRow = null;
foreach ($semester as $s) { if ((int)$s['id_semester'] === $sem) $semRow = $s; }

$prodiList = $db->query('SELECT id_prodi, nama_prodi, jenjang FROM program_studi ORDER BY nama_prodi, jenjang')->fetch_all(MYSQLI_ASSOC);
$prodi = (int)($_GET['prodi'] ?? 0);   // 0 = belum memilih prodi
$nim = trim($_GET['nim'] ?? '');
$smk = (int)($_GET['smk'] ?? 0);       // 0 = otomatis dari angkatan

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nimP = trim($_POST['nim'] ?? '');
    try {
        $aksi = $_POST['aksi'] ?? '';
        if ($aksi !== 'semester' && !$sem) throw new RuntimeException('Buat atau pilih semester dulu.');

        // Input per mahasiswa: prodi harus dipilih dan mahasiswa harus berasal dari prodi itu
        if (in_array($aksi, ['nilai_matkul', 'angkatan', 'absen'], true)) {
            if (!$prodi) throw new RuntimeException('Pilih prodi dulu.');
            $c = $db->prepare('SELECT 1 FROM mahasiswa WHERE nim = ? AND id_prodi = ?');
            $c->bind_param('si', $nimP, $prodi); $c->execute();
            if (!$c->get_result()->fetch_row()) throw new RuntimeException('Mahasiswa tidak termasuk dalam prodi yang dipilih.');
            $c->close();
        }

        if ($aksi === 'semester') {
            if (!preg_match('/^\d{4}\/\d{4}$/', $_POST['tahun'] ?? '')) throw new RuntimeException('Format tahun akademik: 2025/2026.');
            $s = $db->prepare('INSERT INTO semester (tahun_akademik, jenis) VALUES (?,?)');
            $s->bind_param('ss', $_POST['tahun'], $_POST['jenis']);
            $s->execute(); $sem = $db->insert_id; flash('ok', 'Semester ditambahkan.');

        } elseif ($aksi === 'angkatan') {
            $a = (int)($_POST['angkatan'] ?? 0);
            if ($a < 2000 || $a > (int)date('Y') + 1) throw new RuntimeException('Angkatan tidak valid.');
            $s = $db->prepare('UPDATE mahasiswa SET angkatan = ? WHERE nim = ?');
            $s->bind_param('is', $a, $nimP); $s->execute();
            flash('ok', 'Angkatan disimpan.');

        } elseif ($aksi === 'nilai_matkul') {
            $input = (array)($_POST['nilai'] ?? []);
            // hanya mata kuliah milik prodi ini yang sah
            $sah = [];
            $q = $db->prepare('SELECT id_matkul FROM mata_kuliah WHERE id_prodi = ?');
            $q->bind_param('i', $prodi); $q->execute();
            foreach ($q->get_result() as $r) { $sah[(int)$r['id_matkul']] = true; }
            $q->close();

            $db->begin_transaction();
            try {
                $u = $db->prepare('INSERT INTO nilai_matkul (nim, id_matkul, id_semester, nilai_angka, huruf, bobot) VALUES (?,?,?,?,?,?)
                    ON DUPLICATE KEY UPDATE id_semester = VALUES(id_semester), nilai_angka = VALUES(nilai_angka),
                                            huruf = VALUES(huruf), bobot = VALUES(bobot)');
                $n = 0;
                foreach ($input as $idm => $v) {
                    $idm = (int)$idm; $v = trim((string)$v);
                    if ($v === '') continue;   // kosong = tidak diubah
                    if (!isset($sah[$idm])) throw new RuntimeException('Ada mata kuliah yang bukan milik prodi ini.');
                    $v = str_replace(',', '.', $v);
                    if (!is_numeric($v) || (float)$v < 0 || (float)$v > 100) throw new RuntimeException('Nilai harus berupa angka 0 sampai 100.');
                    $angka = round((float)$v, 2);
                    [$huruf, $bobot] = konversi_nilai($angka);
                    $u->bind_param('siidsd', $nimP, $idm, $sem, $angka, $huruf, $bobot);
                    $u->execute(); $n++;
                }
                if ($n < 1) throw new RuntimeException('Isi minimal satu nilai.');
                hitung_ulang_ip($db, $nimP, $sem);
                $db->commit();
            } catch (Throwable $e) { $db->rollback(); throw $e; }
            flash('ok', 'Nilai ' . $n . ' mata kuliah disimpan. IPS dan IPK dihitung otomatis.');

        } elseif ($aksi === 'absen') {
            if (!valid_tanggal($_POST['tanggal'] ?? '')) throw new RuntimeException('Tanggal tidak valid.');
            $idm = (int)($_POST['id_matkul'] ?? 0);
            $c = $db->prepare('SELECT 1 FROM mata_kuliah WHERE id_matkul = ? AND id_prodi = ?');
            $c->bind_param('ii', $idm, $prodi); $c->execute();
            if (!$c->get_result()->fetch_row()) throw new RuntimeException('Mata kuliah bukan milik prodi ini.');
            $c->close();

            // pertemuan ke-berapa (maksimal 18 per mata kuliah per semester)
            $c = $db->prepare('SELECT COUNT(*) FROM absensi WHERE nim = ? AND id_matkul = ? AND id_semester = ?');
            $c->bind_param('sii', $nimP, $idm, $sem); $c->execute();
            $ke = (int)$c->get_result()->fetch_row()[0] + 1; $c->close();
            if ($ke > JUMLAH_PERTEMUAN) throw new RuntimeException('Pertemuan mata kuliah ini sudah penuh (' . JUMLAH_PERTEMUAN . ' pertemuan).');

            $db->begin_transaction();
            try {
                $s = $db->prepare('INSERT INTO absensi (nim, id_matkul, id_semester, tanggal, status_hadir) VALUES (?,?,?,?,?)');
                $s->bind_param('siiss', $nimP, $idm, $sem, $_POST['tanggal'], $_POST['status_hadir']);
                $s->execute();
                hitung_rekap_kehadiran($db, $sem, $nimP);
                $db->commit();
            } catch (Throwable $e) { $db->rollback(); throw $e; }
            flash('ok', 'Absensi dicatat: pertemuan ke-' . $ke . ' dari ' . JUMLAH_PERTEMUAN . '. Rekap kehadiran diperbarui.');

        } elseif ($aksi === 'rekap') {
            hitung_rekap_kehadiran($db, $sem, null);
            flash('ok', 'Rekap kehadiran dihitung ulang dari data absensi.');
        }
    } catch (RuntimeException $e) { flash('err', $e->getMessage()); }
    catch (mysqli_sql_exception $e) { flash('err', galat_sql($e)); }
    header('Location: nilai.php?sem=' . $sem . '&prodi=' . $prodi . '&smk=' . $smk . '&nim=' . urlencode($nimP)); exit;
}

// Mahasiswa: hanya dari prodi yang dipilih
$mhs = [];
if ($prodi) {
    $s = $db->prepare('SELECT nim, nama, angkatan FROM mahasiswa WHERE id_prodi = ? ORDER BY nim');
    $s->bind_param('i', $prodi); $s->execute();
    $mhs = $s->get_result()->fetch_all(MYSQLI_ASSOC);
}
$mhsPilih = null;
foreach ($mhs as $m) { if ((string)$m['nim'] === $nim) $mhsPilih = $m; }

// Semester perkuliahan ke-berapa (otomatis dari angkatan, atau pilihan manual)
$skAuto = null;
if ($mhsPilih && $semRow) {
    $skAuto = semester_ke($mhsPilih['angkatan'] !== null ? (int)$mhsPilih['angkatan'] : null, (string)$semRow['tahun_akademik'], (string)$semRow['jenis']);
}
$maxSk = 0;
if ($prodi) { $maxSk = (int)$db->query("SELECT COALESCE(MAX(semester_ke), 0) FROM mata_kuliah WHERE id_prodi = $prodi")->fetch_row()[0]; }
$skTampil = $smk > 0 ? $smk : (($skAuto !== null && $skAuto <= $maxSk) ? $skAuto : 1);

// Mata kuliah milik prodi pada semester perkuliahan tersebut
$matkul = [];
if ($prodi) {
    $s = $db->prepare('SELECT id_matkul, kode_mk, nama_mk, sks FROM mata_kuliah WHERE id_prodi = ? AND semester_ke = ? ORDER BY kode_mk');
    $s->bind_param('ii', $prodi, $skTampil); $s->execute();
    $matkul = $s->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Nilai yang sudah ada + IPS/IPK semester terpilih
$nilaiAda = []; $ipRow = null;
if ($mhsPilih) {
    $s = $db->prepare('SELECT id_matkul, nilai_angka, huruf FROM nilai_matkul WHERE nim = ?');
    $s->bind_param('s', $nim); $s->execute();
    foreach ($s->get_result() as $r) { $nilaiAda[(int)$r['id_matkul']] = $r; }
    $s->close();
    if ($sem) {
        $s = $db->prepare('SELECT ips, ipk FROM nilai_semester WHERE nim = ? AND id_semester = ?');
        $s->bind_param('si', $nim, $sem); $s->execute();
        $ipRow = $s->get_result()->fetch_assoc();
        $s->close();
    }
}

// Rekap semester: semua prodi kalau belum memilih, atau hanya prodi terpilih
$q = $db->prepare('SELECT m.nim, m.nama, m.angkatan, p.nama_prodi, p.jenjang, n.ips, n.ipk, r.total_pertemuan, r.total_hadir, r.persen_hadir
  FROM mahasiswa m JOIN program_studi p ON p.id_prodi = m.id_prodi
  LEFT JOIN nilai_semester n ON n.nim = m.nim AND n.id_semester = ?
  LEFT JOIN rekap_kehadiran r ON r.nim = m.nim AND r.id_semester = ?
  WHERE (? = 0 OR m.id_prodi = ?)
  ORDER BY p.nama_prodi, m.nim');
$q->bind_param('iiii', $sem, $sem, $prodi, $prodi); $q->execute();
$rows = $q->get_result()->fetch_all(MYSQLI_ASSOC);

$judul = 'Nilai dan Absensi';
require 'partials/atas.php';
function opsi_mhs($mhs) { foreach ($mhs as $m) echo '<option value="' . h($m['nim']) . '">' . h($m['nim']) . ' - ' . h($m['nama']) . '</option>'; }
$aksiUrl = 'nilai.php?sem=' . $sem . '&prodi=' . $prodi . '&smk=' . $smk;
?>
<div class="card">
<h2>Nilai dan Absensi</h2>
<?php tampil_flash(); ?>
<form method="get" class="inline">
  <div><label>Semester</label><select name="sem" onchange="this.form.submit()">
  <?php foreach ($semester as $s): ?><option value="<?= (int)$s['id_semester'] ?>" <?= $sem == $s['id_semester'] ? 'selected' : '' ?>><?= h($s['tahun_akademik']) ?> <?= h($s['jenis']) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Program studi</label><select name="prodi" onchange="this.form.submit()">
    <option value="0">- Pilih prodi -</option>
    <?php foreach ($prodiList as $p): ?><option value="<?= (int)$p['id_prodi'] ?>" <?= $prodi == $p['id_prodi'] ? 'selected' : '' ?>><?= h($p['nama_prodi']) ?> (<?= h($p['jenjang']) ?>)</option><?php endforeach; ?>
  </select></div>
</form>
<form method="post" action="<?= h($aksiUrl) ?>" class="inline">
  <input type="hidden" name="aksi" value="semester">
  <div><label>Semester baru: tahun akademik</label><input name="tahun" placeholder="2025/2026" required></div>
  <div><label>Jenis</label><select name="jenis"><option>ganjil</option><option>genap</option></select></div>
  <button>Tambah semester</button>
</form>
</div>

<?php if (!$prodi): ?>
<div class="card">
  <p class="kecil">Pilih <b>program studi</b> di atas dulu untuk menginput nilai dan absensi. Tabel Rekap Semester di bawah menampilkan semua prodi.</p>
</div>
<?php else: ?>
<div class="card">
<h3>Input Nilai Mata Kuliah</h3>
<?php if ($mhs): ?>
<form method="get" class="inline">
  <input type="hidden" name="sem" value="<?= $sem ?>"><input type="hidden" name="prodi" value="<?= $prodi ?>">
  <div><label>Mahasiswa</label><select name="nim" onchange="this.form.submit()">
    <option value="">- Pilih mahasiswa -</option>
    <?php foreach ($mhs as $m): ?><option value="<?= h($m['nim']) ?>" <?= (string)$m['nim'] === $nim ? 'selected' : '' ?>><?= h($m['nim']) ?> - <?= h($m['nama']) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Semester perkuliahan ke-</label><select name="smk" onchange="this.form.submit()">
    <option value="0" <?= $smk == 0 ? 'selected' : '' ?>>Otomatis (sesuai angkatan)</option>
    <?php for ($i = 1; $i <= max($maxSk, 1); $i++): ?><option value="<?= $i ?>" <?= $smk == $i ? 'selected' : '' ?>>Semester <?= $i ?></option><?php endfor; ?>
  </select></div>
</form>

<?php if ($mhsPilih): ?>
  <form method="post" action="<?= h($aksiUrl) ?>" class="inline">
    <input type="hidden" name="aksi" value="angkatan"><input type="hidden" name="nim" value="<?= h($mhsPilih['nim']) ?>">
    <div><label>Angkatan <?= h($mhsPilih['nama']) ?></label><input name="angkatan" value="<?= h($mhsPilih['angkatan'] ?? '') ?>" placeholder="2025" required></div>
    <button>Simpan angkatan</button>
  </form>
  <p class="kecil">
    Nilai disimpan untuk semester akademik <b><?= $semRow ? h($semRow['tahun_akademik'] . ' ' . $semRow['jenis']) : '-' ?></b>.
    Menampilkan mata kuliah <b>semester <?= (int)$skTampil ?></b><?= $skAuto !== null && $smk == 0 ? ' (otomatis dari angkatan)' : '' ?>.
    <?php if ($mhsPilih['angkatan'] === null): ?>Angkatan belum diisi, jadi semester dipilih manual.<?php endif; ?>
  </p>

  <?php if ($matkul): ?>
  <form method="post" action="<?= h($aksiUrl) ?>">
    <input type="hidden" name="aksi" value="nilai_matkul"><input type="hidden" name="nim" value="<?= h($mhsPilih['nim']) ?>">
    <div class="scroll"><table>
    <tr><th>Kode</th><th>Mata kuliah</th><th>SKS</th><th>Nilai (0-100)</th><th>Huruf</th></tr>
    <?php foreach ($matkul as $k): $ada = $nilaiAda[(int)$k['id_matkul']] ?? null; ?>
    <tr>
      <td><?= h($k['kode_mk']) ?></td><td><?= h($k['nama_mk']) ?></td><td><?= (int)$k['sks'] ?></td>
      <td><input name="nilai[<?= (int)$k['id_matkul'] ?>]" value="<?= h($ada['nilai_angka'] ?? '') ?>" inputmode="decimal" style="width:90px" autocomplete="off"></td>
      <td><?= $ada ? h($ada['huruf']) : '-' ?></td>
    </tr>
    <?php endforeach; ?>
    </table></div>
    <button style="width:auto;margin-top:10px">Simpan nilai</button>
  </form>
  <?php else: ?>
  <p class="kecil">Belum ada mata kuliah semester <?= (int)$skTampil ?> untuk prodi ini. Atur di menu <a href="matakuliah.php?prodi=<?= $prodi ?>">Mata Kuliah</a>.</p>
  <?php endif; ?>

  <p style="margin-top:10px">IPS semester ini: <b><?= $ipRow ? h($ipRow['ips']) : '-' ?></b> | IPK: <b><?= $ipRow ? h($ipRow['ipk']) : '-' ?></b>
  <small class="kecil">(dihitung otomatis dari nilai dan SKS)</small></p>
<?php else: ?>
  <p class="kecil">Pilih mahasiswa untuk mengisi nilai.</p>
<?php endif; ?>
<?php else: ?>
<p class="kecil">Belum ada mahasiswa di prodi ini.</p>
<?php endif; ?>
</div>

<div class="card">
<h3>Absensi dan Rekap Kehadiran</h3>
<?php if ($mhs && $matkul): ?>
<form method="post" action="<?= h($aksiUrl) ?>" class="inline">
  <input type="hidden" name="aksi" value="absen">
  <div><label>Mahasiswa</label><select name="nim"><?php opsi_mhs($mhs); ?></select></div>
  <div><label>Mata kuliah (semester <?= (int)$skTampil ?>)</label><select name="id_matkul">
    <?php foreach ($matkul as $k): ?><option value="<?= (int)$k['id_matkul'] ?>"><?= h($k['kode_mk']) ?> - <?= h($k['nama_mk']) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Tanggal</label><input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required></div>
  <div><label>Status</label><select name="status_hadir"><option>hadir</option><option>izin</option><option>sakit</option><option>alpa</option></select></div>
  <button>Catat</button>
</form>
<?php else: ?>
<p class="kecil">Belum ada mahasiswa atau mata kuliah untuk prodi dan semester perkuliahan ini.</p>
<?php endif; ?>
<form method="post" action="<?= h($aksiUrl) ?>">
  <input type="hidden" name="aksi" value="rekap">
  <button style="width:auto">Hitung ulang rekap kehadiran dari absensi</button>
</form>
<p class="kecil">Satu mata kuliah memiliki <?= JUMLAH_PERTEMUAN ?> pertemuan per semester. Contoh: hadir 1 kali di satu mata kuliah tampil 1/<?= JUMLAH_PERTEMUAN ?>. Rekap diperbarui otomatis setiap absensi dicatat dan dipakai untuk pemilihan mahasiswa terbaik.</p>
</div>
<?php endif; ?>

<div class="card">
<h3>Rekap Semester</h3>
<div class="scroll"><table>
<tr><th>NIM</th><th>Nama</th><th>Angkatan</th><th>Prodi</th><th>IPS</th><th>IPK</th><th>Hadir</th><th>Kehadiran</th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= h($r['nim']) ?></td><td><?= h($r['nama']) ?></td><td><?= h($r['angkatan'] ?? '-') ?></td>
<td><?= h($r['nama_prodi']) ?> (<?= h($r['jenjang']) ?>)</td>
<td><?= h($r['ips'] ?? '-') ?></td><td><?= h($r['ipk'] ?? '-') ?></td>
<td><?= $r['total_pertemuan'] !== null ? (int)$r['total_hadir'] . '/' . (int)$r['total_pertemuan'] : '-' ?></td>
<td><?= $r['persen_hadir'] !== null ? h($r['persen_hadir']) . '%' : '-' ?></td></tr>
<?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="8">Belum ada mahasiswa.</td></tr><?php endif; ?>
</table></div></div>
<?php require 'partials/bawah.php'; ?>