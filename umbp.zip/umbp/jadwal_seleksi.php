<?php
require 'config/koneksi.php'; require 'config/bantu.php';
wajib_login(['admin', 'panitia']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $aksi = $_POST['aksi'] ?? '';
        if ($aksi === 'ubah') {
            $idj = (int)$_POST['id_jadwal'];
            $lokasi = trim($_POST['lokasi']);
            $catatan = trim($_POST['catatan']) !== '' ? trim($_POST['catatan']) : null;
            if (!valid_tanggal($_POST['tanggal'])) throw new RuntimeException('Tanggal tidak valid.');
            if (!valid_jam($_POST['jam'])) throw new RuntimeException('Jam tidak valid (contoh 09:30).');
            if ($lokasi === '') throw new RuntimeException('Lokasi wajib diisi.');
            if (!in_array($_POST['status'], ['dijadwalkan', 'selesai', 'dibatalkan'], true)) throw new RuntimeException('Status tidak valid.');
            $s = $db->prepare('UPDATE jadwal_seleksi SET tanggal = ?, jam = ?, lokasi = ?, catatan = ?, status = ? WHERE id_jadwal = ?');
            $s->bind_param('sssssi', $_POST['tanggal'], $_POST['jam'], $lokasi, $catatan, $_POST['status'], $idj);
            $s->execute();
            flash('ok', 'Jadwal diperbarui.');
        } elseif ($aksi === 'buat') {
            $idp = (int)$_POST['id_pendaftaran'];
            $cek = $db->query("SELECT status_administrasi FROM pendaftaran WHERE id_pendaftaran = $idp")->fetch_assoc();
            if (!$cek || $cek['status_administrasi'] !== 'disetujui') {
                throw new RuntimeException('Jadwal hanya bisa dibuat untuk pendaftar yang administrasinya sudah di-ACC.');
            }
            $dibuat = buat_jadwal_seleksi($db, $idp);
            flash($dibuat ? 'ok' : 'err', $dibuat ? 'Jadwal ujian dan wawancara dibuat.' : 'Jadwal tidak dibuat (sudah ada).');
        }
    } catch (RuntimeException $e) { flash('err', $e->getMessage()); }
    catch (mysqli_sql_exception $e) { flash('err', galat_sql($e)); }
    header('Location: jadwal_seleksi.php'); exit;
}

$rows = $db->query("SELECT js.*, c.nama, j.nama_jalur, ps.nama_prodi
  FROM jadwal_seleksi js
  JOIN pendaftaran p ON p.id_pendaftaran = js.id_pendaftaran
  JOIN calon_mahasiswa c ON c.id_calon = p.id_calon
  JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
  JOIN program_studi ps ON ps.id_prodi = p.id_prodi
  ORDER BY js.tanggal, js.jam, js.jenis")->fetch_all(MYSQLI_ASSOC);

$belum = $db->query("SELECT p.id_pendaftaran, c.nama, j.nama_jalur
  FROM pendaftaran p
  JOIN calon_mahasiswa c ON c.id_calon = p.id_calon
  JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
  LEFT JOIN jadwal_seleksi js ON js.id_pendaftaran = p.id_pendaftaran
  WHERE p.status_administrasi = 'disetujui' AND js.id_jadwal IS NULL
  ORDER BY p.id_pendaftaran")->fetch_all(MYSQLI_ASSOC);

$ub = null;
foreach ($rows as $r) { if (isset($_GET['ubah']) && $r['id_jadwal'] == (int)$_GET['ubah']) $ub = $r; }

$judul = 'Jadwal Seleksi';
require 'partials/atas.php';
?>
<div class="card">
<h2>Jadwal Ujian dan Wawancara</h2>
<?php tampil_flash(); ?>
<p class="kecil">Jadwal dibuat otomatis saat admin menyetujui (ACC) administrasi: ujian 7 hari kerja setelah ACC, wawancara sehari sesudahnya (antrean 30 menit mulai 09:00, maksimal 10 orang per hari). Panitia dapat mengubahnya di sini.</p>
</div>

<?php if ($ub): ?>
<div class="card">
<h3>Ubah jadwal <?= h($ub['jenis']) ?>: <?= h($ub['nama']) ?></h3>
<form method="post" class="inline">
  <input type="hidden" name="aksi" value="ubah">
  <input type="hidden" name="id_jadwal" value="<?= (int)$ub['id_jadwal'] ?>">
  <div><label>Tanggal</label><input type="date" name="tanggal" value="<?= h($ub['tanggal']) ?>" required></div>
  <div><label>Jam</label><input type="time" name="jam" value="<?= h(substr($ub['jam'], 0, 5)) ?>" required></div>
  <div><label>Lokasi</label><input name="lokasi" maxlength="100" value="<?= h($ub['lokasi']) ?>" required></div>
  <div><label>Catatan</label><input name="catatan" maxlength="200" value="<?= h($ub['catatan'] ?? '') ?>"></div>
  <div><label>Status</label><select name="status">
  <?php foreach (['dijadwalkan', 'selesai', 'dibatalkan'] as $x): ?><option <?= $ub['status'] === $x ? 'selected' : '' ?>><?= $x ?></option><?php endforeach; ?>
  </select></div>
  <button>Simpan</button>
  <a class="btn" style="margin:0" href="jadwal_seleksi.php">Batal</a>
</form></div>
<?php endif; ?>

<?php if ($belum): ?>
<div class="card">
<h3>Sudah di-ACC tapi belum dijadwalkan</h3>
<div class="scroll"><table>
<tr><th>Calon</th><th>Jalur</th><th>Aksi</th></tr>
<?php foreach ($belum as $b): ?>
<tr><td><?= h($b['nama']) ?></td><td><?= h($b['nama_jalur']) ?></td>
<td class="aksi"><form method="post"><input type="hidden" name="aksi" value="buat">
<input type="hidden" name="id_pendaftaran" value="<?= (int)$b['id_pendaftaran'] ?>"><button>Buat jadwal</button></form></td></tr>
<?php endforeach; ?>
</table></div></div>
<?php endif; ?>

<div class="card">
<h3>Daftar jadwal</h3>
<div class="scroll"><table>
<tr><th>Hari dan tanggal</th><th>Jam</th><th>Jenis</th><th>Calon</th><th>Prodi</th><th>Lokasi</th><th>Status</th><th>Aksi</th></tr>
<?php foreach ($rows as $r): ?>
<tr>
<td><?= h(tgl_id($r['tanggal'])) ?></td>
<td><?= h(substr($r['jam'], 0, 5)) ?></td>
<td><?= h($r['jenis']) ?></td>
<td><a href="pendaftaran_detail.php?id=<?= (int)$r['id_pendaftaran'] ?>"><?= h($r['nama']) ?></a><br><small><?= h($r['nama_jalur']) ?></small></td>
<td><?= h($r['nama_prodi']) ?></td>
<td><?= h($r['lokasi']) ?></td>
<td><?= lencana($r['status']) ?></td>
<td class="aksi"><a href="jadwal_seleksi.php?ubah=<?= (int)$r['id_jadwal'] ?>">Ubah</a></td>
</tr>
<?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="8">Belum ada jadwal.</td></tr><?php endif; ?>
</table></div></div>
<?php require 'partials/bawah.php'; ?>