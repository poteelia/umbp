<?php
require 'config/koneksi.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $st = $db->prepare('SELECT id_pengguna, username, password, nama, peran FROM pengguna WHERE username = ?');
    $st->bind_param('s', $_POST['username']);
    $st->execute();
    $u = $st->get_result()->fetch_assoc();
    if ($u && password_verify($_POST['password'], $u['password'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => $u['id_pengguna'], 'nama' => $u['nama'], 'peran' => $u['peran']];
        $_SESSION['pintu'] = true;   // memicu animasi masuk di dashboard
        header('Location: ' . ($u['peran'] === 'calon' ? 'portal.php' : 'dashboard.php')); exit;
    }
    $err = 'Username atau password salah.';
}
?>
<!DOCTYPE html><html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - SI Kemahasiswaan UMBP</title><link rel="stylesheet" href="style.css"></head>
<body class="login-page"><div class="lcard">
<div class="emblem big"><?php require 'partials/logo.php'; ?></div>
<h1>Selamat Datang</h1>
<p>Silakan masuk ke akun Anda</p>
<?php if (isset($_GET['daftar'])): ?><div class="ok">Akun dibuat. Silakan masuk.</div><?php endif; ?>
<?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>
<form method="post">
<label>Username</label><input name="username" required autofocus>
<label>Password</label><input name="password" type="password" required>
<button>Masuk ke Akun</button></form>
<p><a href="register.php">Belum punya akun? Daftar di sini</a></p>
</div></body></html>