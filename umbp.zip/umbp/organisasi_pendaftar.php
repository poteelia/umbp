<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/anggota.php';
wajib_login(['admin', 'kemahasiswaan']);

// Samakan data lama yang belum masuk keanggotaan
try { sinkron_keanggotaan($db); } catch (Throwable $e) { /* abaikan */ }

$rows = $db->query("SELECT po.id_daftar, po.tgl_daftar, po.status,
    c.nama, m.nim, ps.nama_prodi, o.nama_org
  FROM pendaftaran_organisasi po
  JOIN calon_mahasiswa c ON c.id_calon = po.id_calon
  JOIN organisasi o ON o.id_org = po.id_org
  LEFT JOIN mahasiswa m ON m.id_calon = po.id_calon
  LEFT JOIN pendaftaran p ON p.id_pendaftaran = (SELECT MAX(id_pendaftaran) FROM pendaftaran WHERE id_calon = po.id_calon)
  LEFT JOIN program_studi ps ON ps.id_prodi = p.id_prodi
  ORDER BY o.nama_org, c.nama")->fetch_all(MYSQLI_ASSOC);

$judul = 'Anggota Organisasi';
require 'partials/atas.php';
?>
<div class="card">
<h2>Anggota Organisasi</h2>
<?php tampil_flash(); ?>
<div class="scroll"><table>
<tr><th>No</th><th>Nama</th><th>NIM</th><th>Prodi</th><th>Organisasi</th><th>Tanggal bergabung</th><th>Status</th></tr>
<?php $no = 1; foreach ($rows as $r): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= h($r['nama']) ?></td>
<td><?= h($r['nim'] ?? '-') ?></td>
<td><?= h($r['nama_prodi'] ?? '-') ?></td>
<td><?= h($r['nama_org']) ?></td>
<td><?= h($r['tgl_daftar']) ?></td>
<td><?= $r['status'] === 'diterima' ? '<span class="badge b-ok">aktif</span>' : lencana($r['status']) ?></td>
</tr>
<?php endforeach; ?>
<?php if ($no === 1): ?><tr><td colspan="7">Belum ada anggota.</td></tr><?php endif; ?>
</table></div></div>
<?php require 'partials/bawah.php'; ?>