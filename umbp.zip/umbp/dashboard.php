<?php
require 'config/koneksi.php';
wajib_login(['admin', 'panitia', 'kemahasiswaan']);
function satu($db, $sql) { return $db->query($sql)->fetch_row()[0]; }
$stat = [
  'Program Studi'      => satu($db, 'SELECT COUNT(*) FROM program_studi'),
  'Pendaftar'          => satu($db, 'SELECT COUNT(*) FROM pendaftaran'),
  'Pendaftar Lulus'    => satu($db, "SELECT COUNT(*) FROM pendaftaran WHERE status = 'lulus'"),
  'Mahasiswa'          => satu($db, 'SELECT COUNT(*) FROM mahasiswa'),
  'Dosen'              => satu($db, 'SELECT COUNT(*) FROM dosen'),
  'Organisasi Aktif'   => satu($db, 'SELECT COUNT(*) FROM organisasi WHERE status_aktif = 1'),
  'Anggota Aktif'      => satu($db, "SELECT COUNT(*) FROM keanggotaan WHERE status = 'aktif'"),
  'Beasiswa Disetujui' => satu($db, "SELECT COUNT(*) FROM penerima_beasiswa WHERE status = 'disetujui'"),
  'Mahasiswa Terbaik'  => satu($db, 'SELECT COUNT(*) FROM mahasiswa_terbaik'),
];
$lunas = satu($db, "SELECT COALESCE(SUM(nominal),0) FROM pembayaran WHERE status = 'lunas'");
$judul = 'Dashboard';
require 'partials/atas.php';
?>
<div class="grid">
<?php foreach ($stat as $label => $n): ?>
<div class="card stat"><b><?= (int)$n ?></b><?= h($label) ?></div>
<?php endforeach; ?>
<div class="card stat"><b style="font-size:22px">Rp<?= number_format((float)$lunas, 0, ',', '.') ?></b>Pembayaran Lunas</div>
</div>
<?php require 'partials/bawah.php'; ?>