<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/mahasiswa.php';
wajib_login(['calon']);
$idc = id_calon_akun($db);
if (!$idc) { header('Location: daftar_data.php'); exit; }
$mh = data_mahasiswa($db, $idc);

$riwayat = []; $grup = []; $totalSks = 0; $ipkTerakhir = null;
if ($mh) {
    $nim = (string)$mh['nim'];
    $q = $db->prepare('SELECT s.tahun_akademik, s.jenis, n.ips, n.ipk
        FROM nilai_semester n JOIN semester s ON s.id_semester = n.id_semester
        WHERE n.nim = ? ORDER BY n.id_semester');
    $q->bind_param('s', $nim); $q->execute();
    $riwayat = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
    $ipkTerakhir = $riwayat ? end($riwayat)['ipk'] : null;

    $q = $db->prepare('SELECT n.id_semester, s.tahun_akademik, s.jenis, m.kode_mk, m.nama_mk, m.sks, n.nilai_angka, n.huruf
        FROM nilai_matkul n
        JOIN mata_kuliah m ON m.id_matkul = n.id_matkul
        JOIN semester s ON s.id_semester = n.id_semester
        WHERE n.nim = ? ORDER BY n.id_semester, m.kode_mk');
    $q->bind_param('s', $nim); $q->execute();
    foreach ($q->get_result() as $r) {
        $k = (int)$r['id_semester'];
        if (!isset($grup[$k])) $grup[$k] = ['label' => $r['tahun_akademik'] . ' ' . $r['jenis'], 'rows' => []];
        $grup[$k]['rows'][] = $r;
        $totalSks += (int)$r['sks'];
    }
    $q->close();
}

$judul = 'Riwayat Akademik';
require 'partials/atas.php';
?>
<style>.angka-besar{font-size:24px;font-weight:700;color:#8b0d0d}.kpi .kecil{display:block}</style>

<div class="card">
<h2>Riwayat Akademik</h2>
<?php tampil_flash(); ?>
<?php if (!$mh): ?>
  <?= pesan_belum_mahasiswa() ?>
<?php else: ?>
  <div class="grid">
    <div class="kpi"><span class="kecil">IPK terakhir</span><span class="angka-besar"><?= $ipkTerakhir !== null ? h($ipkTerakhir) : '-' ?></span></div>
    <div class="kpi"><span class="kecil">Semester yang sudah bernilai</span><span class="angka-besar"><?= count($riwayat) ?></span></div>
    <div class="kpi"><span class="kecil">Total SKS bernilai</span><span class="angka-besar"><?= (int)$totalSks ?></span></div>
    <div class="kpi"><span class="kecil">Program studi</span><b><?= h($mh['nama_prodi']) ?> (<?= h($mh['jenjang']) ?>)</b></div>
  </div>
  <?= kotak_lulus($mh) ?>
<?php endif; ?>
</div>

<?php if ($mh): ?>
<div class="card">
<h3>IPS dan IPK per Semester</h3>
<div class="scroll"><table>
<tr><th>Semester</th><th>IPS</th><th>IPK</th></tr>
<?php foreach ($riwayat as $r): ?>
<tr><td><?= h($r['tahun_akademik']) ?> <?= h($r['jenis']) ?></td><td><?= h($r['ips']) ?></td><td><b><?= h($r['ipk']) ?></b></td></tr>
<?php endforeach; ?>
<?php if (!$riwayat): ?><tr><td colspan="3">Belum ada nilai.</td></tr><?php endif; ?>
</table></div>
</div>

<?php foreach ($grup as $g): ?>
<div class="card">
<h3>Nilai Mata Kuliah: <?= h($g['label']) ?></h3>
<div class="scroll"><table>
<tr><th>Kode</th><th>Mata kuliah</th><th>SKS</th><th>Nilai</th><th>Huruf</th></tr>
<?php foreach ($g['rows'] as $r): ?>
<tr><td><?= h($r['kode_mk']) ?></td><td><?= h($r['nama_mk']) ?></td><td><?= (int)$r['sks'] ?></td><td><?= h($r['nilai_angka']) ?></td><td><b><?= h($r['huruf']) ?></b></td></tr>
<?php endforeach; ?>
</table></div>
</div>
<?php endforeach; ?>
<?php if (!$grup): ?><div class="card"><p class="kecil">Belum ada nilai mata kuliah.</p></div><?php endif; ?>
<?php endif; ?>
<?php require 'partials/bawah.php'; ?>