<?php
require 'config/koneksi.php'; require 'config/bantu.php';
wajib_login(['admin', 'panitia']);

$id = (int)($_GET['id'] ?? 0);
$q = $db->prepare('SELECT p.*, c.nama, c.jenis_kelamin, c.email, c.no_hp, c.asal_sekolah, c.tahun_lulus
  FROM pendaftaran p JOIN calon_mahasiswa c ON c.id_calon = p.id_calon WHERE p.id_pendaftaran = ?');
$q->bind_param('i', $id); $q->execute();
$d = $q->get_result()->fetch_assoc();
if (!$d) { header('Location: pendaftaran.php'); exit; }

$prodi = $db->query('SELECT * FROM program_studi ORDER BY id_prodi')->fetch_all(MYSQLI_ASSOC);
$jalur = $db->query('SELECT * FROM jalur_pendaftaran ORDER BY id_jalur')->fetch_all(MYSQLI_ASSOC);
$skema = $db->query('SELECT * FROM skema_pembayaran ORDER BY jenjang, id_skema')->fetch_all(MYSQLI_ASSOC);

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $id_prodi = (int)$_POST['id_prodi'];
        $id_jalur = (int)$_POST['id_jalur'];
        $kode_ref = trim($_POST['kode_referal']) !== '' ? trim($_POST['kode_referal']) : null;
        $tahun = (int)$_POST['tahun_lulus'];
        $jk = $_POST['jenis_kelamin'];

        $pj = array_values(array_filter($jalur, fn($x) => $x['id_jalur'] == $id_jalur))[0] ?? null;
        $pp = array_values(array_filter($prodi, fn($x) => $x['id_prodi'] == $id_prodi))[0] ?? null;
        if (!$pj || !$pp) throw new RuntimeException('Prodi atau jalur tidak valid.');
        if (!in_array($jk, ['L', 'P'], true)) throw new RuntimeException('Jenis kelamin tidak valid.');
        if ($tahun < 2000 || $tahun > 2100) throw new RuntimeException('Tahun lulus tidak valid.');

        // Skema pembayaran hanya untuk jalur Reguler; jalur beasiswa tidak memakai skema
        $id_skema = ($pj['pakai_gelombang'] && ($_POST['id_skema'] ?? '') !== '') ? (int)$_POST['id_skema'] : null;
        if ($id_skema) {
            $sk = array_values(array_filter($skema, fn($x) => $x['id_skema'] == $id_skema))[0] ?? null;
            if (!$sk || $sk['jenjang'] !== $pp['jenjang']) throw new RuntimeException('Skema pembayaran harus sesuai jenjang prodi (' . $pp['jenjang'] . ').');
        }
        if ($id_jalur != $d['id_jalur']) {
            $idc = (int)$d['id_calon'];
            if ($db->query("SELECT 1 FROM penerima_beasiswa WHERE id_calon = $idc")->fetch_row()) {
                throw new RuntimeException('Jalur tidak bisa diubah karena calon sudah punya data beasiswa. Hapus beasiswanya dulu di halaman Detail.');
            }
        }

        $db->begin_transaction();
        $s = $db->prepare('UPDATE calon_mahasiswa SET nama=?, jenis_kelamin=?, email=?, no_hp=?, asal_sekolah=?, tahun_lulus=? WHERE id_calon=?');
        $s->bind_param('sssssii', $_POST['nama'], $jk, $_POST['email'], $_POST['no_hp'], $_POST['asal_sekolah'], $tahun, $d['id_calon']);
        $s->execute();
        $s = $db->prepare('UPDATE pendaftaran SET id_prodi=?, id_jalur=?, id_skema=?, kode_referal=? WHERE id_pendaftaran=?');
        $s->bind_param('iiisi', $id_prodi, $id_jalur, $id_skema, $kode_ref, $id);
        $s->execute();
        $db->commit();
        flash('ok', 'Data pendaftaran diperbarui.');
        header('Location: pendaftaran.php'); exit;
    } catch (RuntimeException $e) { $err = $e->getMessage(); }
    catch (mysqli_sql_exception $e) {
        $db->rollback();
        $err = (strpos($e->getMessage(), 'email') !== false) ? 'Email sudah dipakai calon lain.' : galat_sql($e);
    }
}

$v = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $d;
$sel = fn($a, $b) => (string)$a === (string)$b ? 'selected' : '';

$judul = 'Edit Pendaftaran';
require 'partials/atas.php';
?>
<a class="btn" href="pendaftaran.php">&larr; Kembali ke daftar</a>
<div class="card">
<h2>Edit Pendaftaran</h2>
<?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>
<form method="post">
<label>Nama lengkap</label>
<input name="nama" required value="<?= h($v['nama']) ?>">
<div class="row2">
  <div><label>Jenis kelamin</label>
  <select name="jenis_kelamin">
    <option value="L" <?= $sel($v['jenis_kelamin'], 'L') ?>>Laki-laki</option>
    <option value="P" <?= $sel($v['jenis_kelamin'], 'P') ?>>Perempuan</option>
  </select></div>
  <div><label>Tahun lulus</label>
  <input name="tahun_lulus" type="number" min="2000" max="2100" required value="<?= h($v['tahun_lulus']) ?>"></div>
</div>
<div class="row2">
  <div><label>Email</label><input name="email" type="email" required value="<?= h($v['email']) ?>"></div>
  <div><label>No. HP</label><input name="no_hp" required maxlength="15" value="<?= h($v['no_hp']) ?>"></div>
</div>
<label>Asal sekolah</label>
<input name="asal_sekolah" required value="<?= h($v['asal_sekolah']) ?>">

<label>Program studi</label>
<select name="id_prodi" required>
<?php foreach ($prodi as $p): ?>
  <option value="<?= $p['id_prodi'] ?>" <?= $sel($v['id_prodi'], $p['id_prodi']) ?>><?= h($p['nama_prodi']) ?> (<?= h($p['jenjang']) ?>)</option>
<?php endforeach; ?>
</select>

<label>Jalur pendaftaran</label>
<select name="id_jalur" required>
<?php foreach ($jalur as $j): ?>
  <option value="<?= $j['id_jalur'] ?>" data-reguler="<?= $j['pakai_gelombang'] ? 1 : 0 ?>" <?= $sel($v['id_jalur'], $j['id_jalur']) ?>><?= h($j['nama_jalur']) ?></option>
<?php endforeach; ?>
</select>

<div id="blok-reguler">
<label>Skema pembayaran</label>
<select name="id_skema">
<option value="">- belum dipilih -</option>
<?php foreach ($skema as $s): ?>
  <option value="<?= $s['id_skema'] ?>" <?= $sel($v['id_skema'] ?? '', $s['id_skema']) ?>><?= h($s['jenjang']) ?> - <?= h($s['jenis']) ?> (Rp<?= number_format($s['nominal_cicilan'], 0, ',', '.') ?><?= $s['diskon_persen'] > 0 ? ', diskon ' . (float)$s['diskon_persen'] . '%' : '' ?>)</option>
<?php endforeach; ?>
</select>
</div>

<label>Kode referal (opsional)</label>
<input name="kode_referal" maxlength="20" value="<?= h($v['kode_referal'] ?? '') ?>">
<button>Simpan Perubahan</button>
</form></div>
<script>
(function () {
  var jalur = document.querySelector('[name=id_jalur]');
  var blok = document.getElementById('blok-reguler');
  function ubah() {
    var reguler = jalur.options[jalur.selectedIndex].dataset.reguler === '1';
    blok.style.display = reguler ? '' : 'none';
    blok.querySelectorAll('select').forEach(function (s) { s.disabled = !reguler; });
  }
  jalur.addEventListener('change', ubah);
  ubah();
})();
</script>
<?php require 'partials/bawah.php'; ?>