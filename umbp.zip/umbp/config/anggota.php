<?php
// Penghubung antara pilihan organisasi calon (pendaftaran_organisasi)
// dan anggota resmi (keanggotaan, berdasarkan NIM mahasiswa).

function nim_calon($db, int $idc) {
    $s = $db->prepare('SELECT nim FROM mahasiswa WHERE id_calon = ? LIMIT 1');
    $s->bind_param('i', $idc); $s->execute();
    $r = $s->get_result()->fetch_row();
    return $r ? $r[0] : null;
}

// Tambah anggota aktif. Kolom wajib lain di tabel keanggotaan (tanggal, jabatan, dll.) diisi otomatis.
function tambah_keanggotaan($db, string $nim, int $idOrg) {
    $c = $db->prepare('SELECT 1 FROM keanggotaan WHERE nim = ? AND id_org = ?');
    $c->bind_param('si', $nim, $idOrg); $c->execute();
    if ($c->get_result()->fetch_row()) {
        $u = $db->prepare("UPDATE keanggotaan SET status = 'aktif' WHERE nim = ? AND id_org = ?");
        $u->bind_param('si', $nim, $idOrg); $u->execute();
        return;
    }
    $kol = ['nim', 'id_org', 'status'];
    $val = [$nim, $idOrg, 'aktif'];
    $tipe = 'sis';

    $r = $db->query("SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'keanggotaan'
          AND IS_NULLABLE = 'NO' AND COLUMN_DEFAULT IS NULL
          AND EXTRA NOT LIKE '%auto_increment%'
          AND COLUMN_NAME NOT IN ('nim', 'id_org', 'status')");
    foreach ($r as $k) {
        $t = strtolower($k['DATA_TYPE']);
        if (in_array($t, ['date', 'datetime', 'timestamp'], true)) {
            $kol[] = $k['COLUMN_NAME']; $val[] = date('Y-m-d'); $tipe .= 's';
        } elseif (in_array($t, ['varchar', 'char', 'text'], true)) {
            $kol[] = $k['COLUMN_NAME']; $val[] = 'Anggota'; $tipe .= 's';
        }
    }
    $nama = '`' . implode('`,`', $kol) . '`';
    $ph = implode(',', array_fill(0, count($kol), '?'));
    $s = $db->prepare("INSERT INTO keanggotaan ($nama) VALUES ($ph)");
    $s->bind_param($tipe, ...$val);
    $s->execute();
}

function hapus_keanggotaan($db, string $nim, int $idOrg) {
    $s = $db->prepare('DELETE FROM keanggotaan WHERE nim = ? AND id_org = ?');
    $s->bind_param('si', $nim, $idOrg); $s->execute();
}

// Samakan data lama: pilihan yang sudah "diterima" tetapi belum masuk keanggotaan
function sinkron_keanggotaan($db) {
    $rows = $db->query("SELECT po.id_org, m.nim
        FROM pendaftaran_organisasi po
        JOIN mahasiswa m ON m.id_calon = po.id_calon
        WHERE po.status = 'diterima'
          AND NOT EXISTS (SELECT 1 FROM keanggotaan k WHERE k.nim = m.nim AND k.id_org = po.id_org)")
        ->fetch_all(MYSQLI_ASSOC);
    foreach ($rows as $r) { tambah_keanggotaan($db, $r['nim'], (int)$r['id_org']); }
}