<?php
// Koneksi database (XAMPP default: user root, password kosong)
session_start();
$db = new mysqli('localhost', 'root', '', 'db_kemahasiswaan_umbp');
if ($db->connect_error) {
    die('Koneksi gagal: ' . $db->connect_error);
}
$db->set_charset('utf8mb4');
// PHP 8.0 tidak melempar exception secara default; aktifkan agar error SQL
// (misalnya email dobel) bisa ditangkap oleh try/catch
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function wajib_login(array $peran = []) {
    if (empty($_SESSION['user'])) { header('Location: login.php'); exit; }
    if ($peran && !in_array($_SESSION['user']['peran'], $peran)) {
        http_response_code(403); die('Akses ditolak.');
    }
}