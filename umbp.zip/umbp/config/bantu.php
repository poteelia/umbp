<?php
const BIAYA_PENDAFTARAN = 300000;   // biaya pendaftaran semua jalur (Rp)

function flash($tipe, $pesan) { $_SESSION['flash'] = [$tipe, $pesan]; }
function tampil_flash() {
    if (empty($_SESSION['flash'])) return;
    [$t, $p] = $_SESSION['flash']; unset($_SESSION['flash']);
    echo '<div class="' . ($t === 'ok' ? 'ok' : 'err') . '">' . h($p) . '</div>';
}
function lencana($s) {
    $ok = ['aktif', 'valid', 'lunas', 'disetujui', 'lulus', 'hadir', 'selesai'];
    $tunggu = ['menunggu', 'diajukan', 'diproses', 'dijadwalkan', 'belum'];
    $k = in_array($s, $ok) ? 'b-ok' : (in_array($s, $tunggu) ? 'b-wait' : 'b-no');
    return '<span class="badge ' . $k . '">' . h($s) . '</span>';
}
function galat_sql(mysqli_sql_exception $e) {
    $c = $e->getCode();
    if ($c == 1062) return 'Data tersebut sudah ada.';
    if ($c == 1452) return 'Data acuan tidak ditemukan (periksa NIM atau pilihan).';
    if ($c == 4025 || $c == 3819) return 'Nilai melanggar aturan data (periksa rentang angka).';
    return 'Gagal menyimpan: ' . $e->getMessage();
}
function valid_tanggal($t) { $d = DateTime::createFromFormat('Y-m-d', $t); return $d && $d->format('Y-m-d') === $t; }
function valid_jam($j) { return (bool)preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $j); }

// Contoh keluaran: Senin, 30 November 2026
function tgl_id($tgl) {
    $hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $bln = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $d = new DateTime($tgl);
    return $hari[(int)$d->format('w')] . ', ' . $d->format('j') . ' ' . $bln[(int)$d->format('n')] . ' ' . $d->format('Y');
}

// Tambah N hari, lalu geser ke hari kerja (Senin sampai Jumat)
function hari_kerja($tgl, $tambah) {
    $d = new DateTime($tgl);
    $d->modify('+' . (int)$tambah . ' day');
    while ((int)$d->format('N') >= 6) { $d->modify('+1 day'); }
    return $d->format('Y-m-d');
}

// ===== Label jenis berkas =====
function label_berkas() {
    return [
        'IJAZAH' => 'Ijazah', 'SKHU' => 'SKHU', 'SKTL' => 'SKTL', 'KK' => 'Kartu Keluarga',
        'FOTO' => 'Pas Foto', 'BUKTI_KIP' => 'Bukti KIP',
        'SKTM' => 'Surat Keterangan Tidak Mampu',
        'SLIP_GAJI' => 'Slip Gaji / Keterangan Penghasilan Orang Tua',
        'SURAT_REKOM' => 'Surat Rekomendasi / Aspirasi',
        'PRESTASI' => 'Sertifikat Prestasi', 'LAINNYA' => 'Lainnya',
    ];
}

// Berkas wajib untuk satu jalur: [kode => label]
function berkas_jalur($db, $idJalur) {
    $idJalur = (int)$idJalur; $L = label_berkas(); $out = [];
    foreach ($db->query("SELECT jenis_berkas FROM jalur_berkas WHERE id_jalur = $idJalur") as $r) {
        $out[$r['jenis_berkas']] = $L[$r['jenis_berkas']] ?? $r['jenis_berkas'];
    }
    return $out;
}

// Data pendaftaran + pengaturan jalurnya
function info_jalur($db, $idp) {
    $idp = (int)$idp;
    return $db->query("SELECT p.*, j.nama_jalur, j.alur, j.bayar_pendaftaran, j.perlu_lldikti, j.perlu_yayasan
        FROM pendaftaran p JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
        WHERE p.id_pendaftaran = $idp")->fetch_assoc();
}

// ===== Jadwal ujian / wawancara =====
// Cari slot wawancara: 30 menit per orang mulai 09:00, maksimal 10 orang per hari
function slot_wawancara($db, $tgl) {
    while (true) {
        $q = $db->prepare("SELECT COUNT(*) FROM jadwal_seleksi WHERE jenis = 'wawancara' AND tanggal = ? AND status <> 'dibatalkan'");
        $q->bind_param('s', $tgl); $q->execute();
        $n = (int)$q->get_result()->fetch_row()[0]; $q->close();
        if ($n < 10) { $m = $n * 30; return [$tgl, sprintf('%02d:%02d', 9 + intdiv($m, 60), $m % 60)]; }
        $tgl = hari_kerja($tgl, 1);
    }
}

/*
 * ===== Gelombang seleksi otomatis =====
 *  - Gelombang diisi berurutan (1 dulu sampai kuota penuh, lalu 2, lalu 3).
 *  - Hanya jalur reguler (pakai_gelombang = 1) yang dihitung kuotanya.
 *  - Tanggal ujian = milik gelombang: ditetapkan oleh pendaftar pertama di gelombang itu,
 *    pendaftar berikutnya di gelombang yang sama memakai tanggal yang sama.
 *  - Gelombang baru dijadwalkan minimal JEDA_ANTAR_GELOMBANG hari setelah ujian gelombang sebelumnya.
 */
const HARI_KERJA_KE_UJIAN     = 7;   // ujian pertama sebuah gelombang: ACC + 7 hari kerja
const JEDA_ANTAR_GELOMBANG    = 14;  // jarak minimal ujian gelombang berikutnya (hari)
const MIN_HARI_SEBELUM_UJIAN  = 3;   // tidak dipakai lagi (gelombang tidak ditutup otomatis)

// Tanggal ujian milik satu gelombang (null bila belum ada pendaftar)
function tanggal_ujian_gelombang($db, $idg) {
    $q = $db->prepare("SELECT MIN(js.tanggal)
        FROM jadwal_seleksi js
        JOIN pendaftaran p ON p.id_pendaftaran = js.id_pendaftaran
        WHERE p.id_gelombang = ? AND js.jenis = 'ujian' AND js.status <> 'dibatalkan'");
    $q->bind_param('i', $idg); $q->execute();
    $t = $q->get_result()->fetch_row()[0]; $q->close();
    return $t ?: null;
}

// Jumlah pendaftar reguler yang sudah menempati gelombang
function terisi_gelombang($db, $idg) {
    $q = $db->prepare("SELECT COUNT(*)
        FROM pendaftaran p
        JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
        WHERE p.id_gelombang = ? AND j.pakai_gelombang = 1 AND p.status <> 'ditolak'");
    $q->bind_param('i', $idg); $q->execute();
    $n = (int)$q->get_result()->fetch_row()[0]; $q->close();
    return $n;
}

// Pilih gelombang: yang paling awal dan kuotanya belum penuh. Panggil di dalam transaksi.
// Gelombang 1 dipenuhi dulu, baru Gelombang 2, lalu Gelombang 3.
// Mengembalikan [id_gelombang, tanggal_ujian, nama_gelombang]
function pilih_gelombang($db) {
    // kunci baris gelombang agar dua admin yang ACC bersamaan tidak melewati kuota
    $gel = $db->query('SELECT id_gelombang, nama_gelombang, kuota FROM gelombang ORDER BY id_gelombang FOR UPDATE')
              ->fetch_all(MYSQLI_ASSOC);
    if (!$gel) throw new RuntimeException('Belum ada data gelombang. Tambahkan gelombang 1, 2, dan 3 dulu.');

    $hariIni       = date('Y-m-d');
    $tglSebelumnya = null;   // tanggal ujian gelombang terakhir yang sudah punya jadwal

    foreach ($gel as $g) {
        $idg = (int)$g['id_gelombang'];
        $tgl = tanggal_ujian_gelombang($db, $idg);

        // masih ada tempat di gelombang ini -> pakai gelombang ini
        if (terisi_gelombang($db, $idg) < (int)$g['kuota']) {
            if ($tgl === null) {
                // gelombang baru dibuka: ujian ACC + 7 hari kerja, tapi tidak boleh terlalu dekat gelombang sebelumnya
                $tgl = hari_kerja($hariIni, HARI_KERJA_KE_UJIAN);
                if ($tglSebelumnya !== null) {
                    $min = hari_kerja($tglSebelumnya, JEDA_ANTAR_GELOMBANG);
                    if ($min > $tgl) $tgl = $min;
                }
            }
            return [$idg, $tgl, $g['nama_gelombang']];
        }
        // gelombang ini penuh -> lanjut ke gelombang berikutnya
        if ($tgl !== null) $tglSebelumnya = $tgl;
    }
    throw new RuntimeException('Semua gelombang sudah penuh. Tambah gelombang baru dulu.');
}

/*
 * Dibuat saat admin ACC administrasi:
 *  - reguler : ujian pada tanggal gelombang (09:00), wawancara 1 hari kerja setelah ujian
 *  - khusus  : hanya wawancara, 3 hari kerja setelah ACC
 * $tglUjian boleh diisi (dari pilih_gelombang); bila kosong dicari dari gelombang pendaftar.
 */
function buat_jadwal_seleksi($db, $idp, $lokasi = 'Kampus UMBP', $tglUjian = null) {
    $idp = (int)$idp;
    $p = info_jalur($db, $idp);
    if (!$p) return false;
    if ($db->query("SELECT 1 FROM jadwal_seleksi WHERE id_pendaftaran = $idp")->fetch_row()) return false;

    $ins = $db->prepare('INSERT INTO jadwal_seleksi (id_pendaftaran, jenis, tanggal, jam, lokasi) VALUES (?,?,?,?,?)');
    $simpan = function ($jenis, $tgl, $jam) use ($ins, $idp, $lokasi) {
        $ins->bind_param('issss', $idp, $jenis, $tgl, $jam, $lokasi);
        $ins->execute();
    };

    if ($p['alur'] === 'reguler') {
        if (!$tglUjian && !empty($p['id_gelombang'])) {
            $tglUjian = tanggal_ujian_gelombang($db, (int)$p['id_gelombang']);
        }
        if (!$tglUjian) $tglUjian = hari_kerja(date('Y-m-d'), HARI_KERJA_KE_UJIAN);

        $simpan('ujian', $tglUjian, '09:00');
        [$tgl, $jam] = slot_wawancara($db, hari_kerja($tglUjian, 1));
    } else {
        [$tgl, $jam] = slot_wawancara($db, hari_kerja(date('Y-m-d'), 3));
    }
    $simpan('wawancara', $tgl, $jam);
    return true;
}

/*
 * ACC administrasi: tentukan gelombang otomatis (jalur reguler), buat jadwal,
 * lalu sahkan berkas dan bukti bayar pendaftaran yang masih menunggu.
 * Mengembalikan ['gelombang' => nama|null, 'ujian' => tanggal|null] untuk pesan ke admin.
 */
function acc_administrasi($db, $idp) {
    $idp = (int)$idp;
    $db->begin_transaction();
    try {
        $r = $db->query("SELECT p.status_administrasi, p.id_gelombang, j.pakai_gelombang
                         FROM pendaftaran p
                         JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
                         WHERE p.id_pendaftaran = $idp FOR UPDATE")->fetch_assoc();
        if (!$r) throw new RuntimeException('Data tidak ditemukan.');
        if ($r['status_administrasi'] === 'disetujui') throw new RuntimeException('Administrasi sudah disetujui.');

        $info = ['gelombang' => null, 'ujian' => null];

        if ((int)$r['pakai_gelombang'] === 1) {
            if ($r['id_gelombang']) {
                // gelombang sudah ditentukan manual: pakai itu
                $pilih = (int)$r['id_gelombang'];
                $tgl   = tanggal_ujian_gelombang($db, $pilih);
                $q = $db->prepare('SELECT nama_gelombang FROM gelombang WHERE id_gelombang = ?');
                $q->bind_param('i', $pilih); $q->execute();
                $nama = $q->get_result()->fetch_row()[0] ?? null; $q->close();
            } else {
                [$pilih, $tgl, $nama] = pilih_gelombang($db);
            }
            $db->query("UPDATE pendaftaran SET id_gelombang = $pilih, status_administrasi = 'disetujui' WHERE id_pendaftaran = $idp");
            buat_jadwal_seleksi($db, $idp, 'Kampus UMBP', $tgl);
            $info = ['gelombang' => $nama, 'ujian' => $tgl ?: hari_kerja(date('Y-m-d'), HARI_KERJA_KE_UJIAN)];
        } else {
            // jalur khusus: tidak memakai gelombang dan tidak menghabiskan kuota
            $db->query("UPDATE pendaftaran SET status_administrasi = 'disetujui' WHERE id_pendaftaran = $idp");
            buat_jadwal_seleksi($db, $idp);
        }

        // Administrasi disetujui: berkas dan bukti bayar pendaftaran yang masih menunggu ikut disahkan
        // (yang sudah ditandai 'ditolak' oleh admin tidak diubah)
        $db->query("UPDATE berkas_pendaftaran SET status_verifikasi = 'valid'
                    WHERE id_pendaftaran = $idp AND status_verifikasi = 'menunggu'");
        $db->query("UPDATE pembayaran SET status = 'lunas'
                    WHERE id_pendaftaran = $idp AND jenis_bayar = 'PENDAFTARAN' AND status = 'menunggu'");

        $db->commit();
        return $info;
    } catch (Throwable $e) { $db->rollback(); throw $e; }
}

// ===== Tahap LLDIKTI dan Yayasan =====
function jadwalkan_lembaga($db, $idp, $lembaga, $tgl, $lokasi) {
    $jam = '09:00';
    $s = $db->prepare('INSERT IGNORE INTO keputusan_lembaga (id_pendaftaran, lembaga, tanggal, jam, lokasi) VALUES (?,?,?,?,?)');
    $s->bind_param('issss', $idp, $lembaga, $tgl, $jam, $lokasi);
    $s->execute();
}

// Menentukan langkah setelah satu tahap lolos
function langkah_berikut($db, $idp, $setelah) {
    $idp = (int)$idp;
    $p = info_jalur($db, $idp);
    if ($setelah === 'wawancara' && $p['perlu_lldikti']) {
        jadwalkan_lembaga($db, $idp, 'lldikti', hari_kerja(date('Y-m-d'), 14), 'Kantor LLDIKTI');
        return;
    }
    if (in_array($setelah, ['wawancara', 'lldikti'], true) && $p['perlu_yayasan']) {
        $hari = $setelah === 'lldikti' ? 7 : 10;
        jadwalkan_lembaga($db, $idp, 'yayasan', hari_kerja(date('Y-m-d'), $hari), 'Sekretariat Yayasan');
        return;
    }
    $db->query("UPDATE pendaftaran SET status = 'lulus' WHERE id_pendaftaran = $idp");   // semua tahap lolos
}

// Panggil di dalam transaksi
function catat_hasil_wawancara($db, $idp, $hasil, $nilai, $catatan) {
    $idp = (int)$idp;
    if (!in_array($hasil, ['lulus', 'tidak_lulus'], true)) throw new RuntimeException('Hasil wawancara tidak valid.');
    if ($nilai !== '' && (!ctype_digit((string)$nilai) || (int)$nilai > 100)) throw new RuntimeException('Nilai harus 0 sampai 100.');
    $nilai = $nilai === '' ? null : (int)$nilai;
    $catatan = $catatan !== '' ? $catatan : null;

    $p = info_jalur($db, $idp);
    if (!$p) throw new RuntimeException('Data tidak ditemukan.');
    if ($p['alur'] !== 'khusus') throw new RuntimeException('Hasil wawancara hanya untuk jalur khusus.');
    if ($p['status_administrasi'] !== 'disetujui') throw new RuntimeException('Administrasi belum disetujui.');
    if ($p['hasil_wawancara'] !== 'belum') throw new RuntimeException('Hasil wawancara sudah diisi.');

    $s = $db->prepare('UPDATE pendaftaran SET hasil_wawancara = ?, nilai_wawancara = ?, catatan_wawancara = ? WHERE id_pendaftaran = ?');
    $s->bind_param('sisi', $hasil, $nilai, $catatan, $idp); $s->execute();
    $db->query("UPDATE jadwal_seleksi SET status = 'selesai' WHERE id_pendaftaran = $idp AND jenis = 'wawancara' AND status = 'dijadwalkan'");

    if ($hasil === 'tidak_lulus') $db->query("UPDATE pendaftaran SET status = 'ditolak' WHERE id_pendaftaran = $idp");
    else langkah_berikut($db, $idp, 'wawancara');
}

// Panggil di dalam transaksi
function catat_putusan_lembaga($db, $idp, $lembaga, $putusan, $catatan) {
    $idp = (int)$idp;
    if (!in_array($lembaga, ['lldikti', 'yayasan'], true)) throw new RuntimeException('Lembaga tidak valid.');
    if (!in_array($putusan, ['disetujui', 'ditolak'], true)) throw new RuntimeException('Putusan tidak valid.');
    $catatan = $catatan !== '' ? $catatan : null;

    $q = $db->prepare('SELECT status FROM keputusan_lembaga WHERE id_pendaftaran = ? AND lembaga = ? FOR UPDATE');
    $q->bind_param('is', $idp, $lembaga); $q->execute();
    $r = $q->get_result()->fetch_assoc(); $q->close();
    if (!$r) throw new RuntimeException('Jadwal ' . strtoupper($lembaga) . ' belum ada.');
    if ($r['status'] !== 'dijadwalkan') throw new RuntimeException('Sudah diputuskan.');

    $s = $db->prepare('UPDATE keputusan_lembaga SET status = ?, catatan = ? WHERE id_pendaftaran = ? AND lembaga = ?');
    $s->bind_param('ssis', $putusan, $catatan, $idp, $lembaga); $s->execute();

    if ($putusan === 'ditolak') $db->query("UPDATE pendaftaran SET status = 'ditolak' WHERE id_pendaftaran = $idp");
    else langkah_berikut($db, $idp, $lembaga);
}

// ===== Linimasa untuk calon =====
// Mengembalikan [[label, 'selesai'|'sekarang'|'gagal'|'nanti'], ...]
function linimasa($db, array $p) {
    $idp = (int)$p['id_pendaftaran'];
    $kep = [];
    foreach ($db->query("SELECT lembaga, status FROM keputusan_lembaga WHERE id_pendaftaran = $idp") as $k) $kep[$k['lembaga']] = $k['status'];
    $adm = $p['status_administrasi'] === 'disetujui';
    $diajukan = in_array($p['status_administrasi'], ['menunggu', 'disetujui'], true);

    if ($p['alur'] === 'reguler') {
        $langkah = [
            ['Lengkapi berkas dan pembayaran', $diajukan],
            ['Verifikasi administrasi', $adm],
            ['Ujian dan wawancara', $p['status'] === 'lulus' || $p['status'] === 'ditolak'],
            ['Pengumuman', $p['status'] === 'lulus'],
        ];
    } else {
        $langkah = [
            ['Lengkapi berkas dan pembayaran', $diajukan],
            ['Verifikasi administrasi', $adm],
            ['Wawancara', $p['hasil_wawancara'] !== 'belum'],
            ['Hasil wawancara', $p['hasil_wawancara'] === 'lulus'],
        ];
        if ($p['perlu_lldikti']) $langkah[] = ['Verifikasi LLDIKTI', ($kep['lldikti'] ?? '') === 'disetujui'];
        if ($p['perlu_yayasan']) $langkah[] = ['Penetapan Yayasan', ($kep['yayasan'] ?? '') === 'disetujui'];
        $langkah[] = ['Pengumuman', $p['status'] === 'lulus'];
    }

    $out = []; $skrg = false;
    foreach ($langkah as [$label, $selesai]) {
        if ($selesai) { $out[] = [$label, 'selesai']; }
        elseif (!$skrg) { $out[] = [$label, $p['status'] === 'ditolak' ? 'gagal' : 'sekarang']; $skrg = true; }
        else { $out[] = [$label, 'nanti']; }
    }
    return $out;
}