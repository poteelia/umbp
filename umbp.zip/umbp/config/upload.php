<?php
// Simpan file unggahan ke folder uploads/. Mengembalikan path relatif atau melempar RuntimeException.
function simpan_upload(string $field, string $prefix): string {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('Pilih file terlebih dahulu.');
    }
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload gagal (kode ' . $f['error'] . '). Ukuran maksimal 2 MB.');
    }
    if ($f['size'] > 2 * 1024 * 1024) {
        throw new RuntimeException('Ukuran file maksimal 2 MB.');
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'], true)) {
        throw new RuntimeException('Format file harus PDF, JPG, atau PNG.');
    }
    $dir = __DIR__ . '/../uploads';
    if (!is_dir($dir)) { mkdir($dir, 0775, true); }
    $nama = $prefix . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $nama)) {
        throw new RuntimeException('Gagal menyimpan file.');
    }
    return 'uploads/' . $nama;
}