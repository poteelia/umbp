<?php
// Pembantu halaman akun calon/mahasiswa: data mahasiswa, pilihan semester, bar kehadiran, perkiraan lulus.
require_once __DIR__ . '/akademik.php';

// id_calon milik akun yang sedang login (0 jika belum mengisi data pendaftaran)
function id_calon_akun($db): int {
    $uid = (int)$_SESSION['user']['id'];
    return (int)$db->query("SELECT COALESCE(id_calon,0) FROM pengguna WHERE id_pengguna = $uid")->fetch_row()[0];
}

// Data mahasiswa beserta prodinya. null jika belum tercatat sebagai mahasiswa (belum punya NIM)
function data_mahasiswa($db, int $idc): ?array {
    $q = $db->prepare('SELECT m.nim, m.nama, m.id_prodi, m.angkatan, m.status_akademik, m.tgl_lulus, p.nama_prodi, p.jenjang
        FROM mahasiswa m JOIN program_studi p ON p.id_prodi = m.id_prodi
        WHERE m.id_calon = ? LIMIT 1');
    $q->bind_param('i', $idc); $q->execute();
    $r = $q->get_result()->fetch_assoc(); $q->close();
    return $r ?: null;
}

function daftar_semester($db): array {
    return $db->query('SELECT id_semester, tahun_akademik, jenis FROM semester ORDER BY id_semester DESC')->fetch_all(MYSQLI_ASSOC);
}

// Semester pilihan dari ?sem=..., default semester terbaru
function semester_terpilih(array $semAll): ?array {
    $id = (int)($_GET['sem'] ?? 0);
    foreach ($semAll as $s) { if ((int)$s['id_semester'] === $id) return $s; }
    return $semAll[0] ?? null;
}

// Masa studi paling cepat (tahun)
function lama_studi(string $jenjang): int {
    return ['S1' => 4, 'D3' => 3][$jenjang] ?? 4;
}

// Batang persentase kehadiran
function bar_hadir(float $p): string {
    $w = number_format(max(0, min(100, $p)), 1, '.', '');
    return '<span style="display:inline-block;vertical-align:middle;width:110px;height:8px;background:#eee;border-radius:6px;overflow:hidden">'
         . '<span style="display:block;width:' . $w . '%;height:8px;background:#8b0d0d"></span></span> '
         . number_format($p, 1, ',', '.') . '%';
}

// Kotak info tahun lulus
function kotak_lulus(array $mh): string {
    $biru  = 'background:#eef4ff;color:#1f4a8a;padding:12px 16px;border-radius:10px;font-size:14px;margin-top:12px';
    $hijau = 'background:#d9f2e0;color:#1b6b34;padding:12px 16px;border-radius:10px;font-size:14px;margin-top:12px';
    if ($mh['status_akademik'] === 'lulus') {
        return '<div style="' . $hijau . '">🎓 Kamu dinyatakan <b>lulus</b>'
             . ($mh['tgl_lulus'] ? ' pada ' . h(tgl_id($mh['tgl_lulus'])) : '') . '. Selamat!</div>';
    }
    if ($mh['angkatan'] === null) {
        return '<div style="' . $biru . '">🎓 Angkatan belum diisi, jadi perkiraan tahun lulus belum bisa dihitung. Hubungi admin.</div>';
    }
    $lama = lama_studi((string)$mh['jenjang']);
    return '<div style="' . $biru . '">🎓 Perkiraan lulus: <b>paling cepat tahun ' . ((int)$mh['angkatan'] + $lama) . '</b> '
         . '(masa studi minimal ' . $lama . ' tahun untuk ' . h($mh['jenjang']) . ', dihitung dari angkatan ' . (int)$mh['angkatan'] . ').</div>';
}

// Pesan untuk akun yang belum punya NIM
function pesan_belum_mahasiswa(): string {
    return '<div class="info-kunci" style="background:#fff3cd;color:#8a6100;padding:12px 16px;border-radius:10px">'
         . '🔒 Halaman ini terisi setelah kamu dinyatakan lulus dan tercatat sebagai mahasiswa (punya NIM). Hubungi panitia bila status kamu sudah lulus tetapi halaman ini masih kosong.</div>';
}