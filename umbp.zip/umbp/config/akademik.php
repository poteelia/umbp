<?php
// Fungsi akademik: konversi nilai, semester ke-, perhitungan IPS/IPK, dan rekap kehadiran.

// Jumlah pertemuan satu mata kuliah dalam satu semester
const JUMLAH_PERTEMUAN = 18;

// Nilai angka (0-100) -> huruf dan bobot skala 4,00. Ubah di sini kalau kampus memakai skala lain.
function konversi_nilai(float $n): array {
    if ($n >= 85) return ['A', 4.00];
    if ($n >= 80) return ['A-', 3.75];
    if ($n >= 75) return ['B+', 3.50];
    if ($n >= 70) return ['B', 3.00];
    if ($n >= 65) return ['B-', 2.75];
    if ($n >= 60) return ['C+', 2.50];
    if ($n >= 55) return ['C', 2.00];
    if ($n >= 40) return ['D', 1.00];
    return ['E', 0.00];
}

// Semester perkuliahan ke-berapa pada semester akademik tertentu (null jika angkatan belum diisi)
function semester_ke(?int $angkatan, string $tahunAkademik, string $jenis): ?int {
    if (!$angkatan || !preg_match('/^(\d{4})\//', $tahunAkademik, $m)) return null;
    $k = ((int)$m[1] - $angkatan) * 2 + (strtolower($jenis) === 'ganjil' ? 1 : 2);
    return $k >= 1 ? $k : null;
}

// Rata-rata berbobot SKS. $kumulatif = true -> IPK (semua semester sampai $idSem), false -> IPS
function rata_bobot($db, string $nim, int $idSem, bool $kumulatif): ?float {
    $op = $kumulatif ? '<=' : '=';
    $q = $db->prepare("SELECT SUM(n.bobot * m.sks) / NULLIF(SUM(m.sks), 0)
        FROM nilai_matkul n JOIN mata_kuliah m ON m.id_matkul = n.id_matkul
        WHERE n.nim = ? AND n.id_semester $op ?");
    $q->bind_param('si', $nim, $idSem); $q->execute();
    $row = $q->get_result()->fetch_row(); $q->close();
    $v = $row[0] ?? null;
    return $v === null ? null : round((float)$v, 2);
}

// Hitung ulang IPS dan IPK mahasiswa mulai dari semester tertentu, lalu simpan ke nilai_semester
function hitung_ulang_ip($db, string $nim, int $semMulai): void {
    $q = $db->prepare('SELECT DISTINCT id_semester FROM nilai_matkul WHERE nim = ? AND id_semester >= ? ORDER BY id_semester');
    $q->bind_param('si', $nim, $semMulai); $q->execute();
    $ids = array_column($q->get_result()->fetch_all(MYSQLI_ASSOC), 'id_semester'); $q->close();

    $u = $db->prepare('INSERT INTO nilai_semester (nim, id_semester, ips, ipk) VALUES (?,?,?,?)
        ON DUPLICATE KEY UPDATE ips = VALUES(ips), ipk = VALUES(ipk)');
    foreach ($ids as $sid) {
        $sid = (int)$sid;
        $ips = rata_bobot($db, $nim, $sid, false);
        $ipk = rata_bobot($db, $nim, $sid, true);
        if ($ips === null || $ipk === null) continue;
        $u->bind_param('sidd', $nim, $sid, $ips, $ipk);
        $u->execute();
    }
}

/*
 * Rekap kehadiran semester. Total pertemuan = 18 x jumlah mata kuliah yang punya absensi,
 * total hadir = jumlah absensi berstatus 'hadir'. $nim = null -> semua mahasiswa pada semester itu.
 */
function hitung_rekap_kehadiran($db, int $idSem, ?string $nim = null): void {
    $sql = "INSERT INTO rekap_kehadiran (nim, id_semester, total_pertemuan, total_hadir)
        SELECT a.nim, a.id_semester, ? * COUNT(DISTINCT a.id_matkul), SUM(a.status_hadir = 'hadir')
        FROM absensi a WHERE a.id_semester = ?" . ($nim !== null ? ' AND a.nim = ?' : '') . "
        GROUP BY a.nim, a.id_semester
        ON DUPLICATE KEY UPDATE total_pertemuan = VALUES(total_pertemuan), total_hadir = VALUES(total_hadir)";
    $s = $db->prepare($sql);
    $p = JUMLAH_PERTEMUAN;
    if ($nim !== null) $s->bind_param('iis', $p, $idSem, $nim);
    else $s->bind_param('ii', $p, $idSem);
    $s->execute();
}