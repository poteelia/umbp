@echo off
cd /d C:\xampp\htdocs\umbp
start http://localhost:8000/login.php
C:\xampp\php\php.exe -S localhost:8000 -t .