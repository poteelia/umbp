<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/upload.php';
wajib_login(['admin', 'panitia']);

function hapus_file($rel) {
    $dir = realpath(__DIR__ . '/uploads');
    $p = $rel ? realpath(__DIR__ . '/' . $rel) : false;
    if ($dir && $p && strpos($p, $dir . DIRECTORY_SEPARATOR) === 0 && is_file($p)) { unlink($p); }
}

$id = (int)($_GET['id'] ?? 0);
$q = $db->prepare('SELECT p.id_pendaftaran, p.id_calon, p.id_jalur, p.tgl_daftar, p.status,
    c.nama, c.email, c.no_hp, c.asal_sekolah,
    ps.nama_prodi, ps.jenjang, j.nama_jalur, j.pakai_gelombang, g.nama_gelombang,
    sp.jenis AS skema, sp.nominal_cicilan, sp.diskon_persen
  FROM pendaftaran p
  JOIN calon_mahasiswa c   ON c.id_calon = p.id_calon
  JOIN program_studi ps    ON ps.id_prodi = p.id_prodi
  JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
  LEFT JOIN gelombang g    ON g.id_gelombang = p.id_gelombang
  LEFT JOIN skema_pembayaran sp ON sp.id_skema = p.id_skema
  WHERE p.id_pendaftaran = ?');
$q->bind_param('i', $id);
$q->execute();
$d = $q->get_result()->fetch_assoc();
if (!$d) { header('Location: pendaftaran.php'); exit; }
$id_calon = (int)$d['id_calon'];

$JENIS_BERKAS = ['IJAZAH' => 'Ijazah', 'SKHU' => 'SKHU', 'SKTL' => 'SKTL', 'KK' => 'Kartu Keluarga',
                 'FOTO' => 'Pas Foto', 'BUKTI_KIP' => 'Bukti KIP', 'LAINNYA' => 'Lainnya'];
$JENIS_BAYAR  = ['PENDAFTARAN' => 'Biaya Pendaftaran', 'UANG_KULIAH' => 'Uang Kuliah'];

function rp($n) { return 'Rp' . number_format((float)$n, 0, ',', '.'); }
function bayar_dari_post($JENIS_BAYAR) {
    $jenis = $_POST['jenis_bayar'] ?? '';
    if (!isset($JENIS_BAYAR[$jenis])) throw new RuntimeException('Jenis pembayaran tidak valid.');
    if ($jenis === 'PENDAFTARAN') {
        // Biaya pendaftaran ditetapkan sistem, isian dari form diabaikan
        $nominal = BIAYA_PENDAFTARAN;
    } else {
        $nominal = (int)preg_replace('/\D/', '', $_POST['nominal'] ?? '');
        if ($nominal <= 0) throw new RuntimeException('Nominal harus lebih dari 0.');
    }
    $tgl = trim($_POST['tgl_bayar'] ?? '');
    if ($tgl !== '' && !valid_tanggal($tgl)) throw new RuntimeException('Tanggal tidak valid.');
    return [$jenis, $nominal, $tgl !== '' ? $tgl : null];
}
function form_hapus($aksi, $namaId, $nilaiId, $pesan) {
    return '<form method="post" onsubmit="return confirm(\'' . $pesan . '\')">'
         . '<input type="hidden" name="aksi" value="' . $aksi . '">'
         . '<input type="hidden" name="' . $namaId . '" value="' . (int)$nilaiId . '">'
         . '<button class="btn-hapus">Hapus</button></form>';
}

// ---------- Proses form ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    try {
        if ($aksi === 'upload_berkas') {
            $jenis = $_POST['jenis_berkas'] ?? '';
            if (!isset($JENIS_BERKAS[$jenis])) throw new RuntimeException('Jenis berkas tidak valid.');
            $path = simpan_upload('file', 'berkas');
            $s = $db->prepare('INSERT INTO berkas_pendaftaran (id_pendaftaran, jenis_berkas, file_path) VALUES (?,?,?)');
            $s->bind_param('iss', $id, $jenis, $path);
            $s->execute();
            flash('ok', 'Berkas berhasil diunggah.');

        } elseif ($aksi === 'verif_berkas') {
            if (!in_array($_POST['status'] ?? '', ['menunggu', 'valid', 'ditolak'], true)) throw new RuntimeException('Status tidak valid.');
            $s = $db->prepare('UPDATE berkas_pendaftaran SET status_verifikasi = ? WHERE id_berkas = ? AND id_pendaftaran = ?');
            $s->bind_param('sii', $_POST['status'], $_POST['id_berkas'], $id);
            $s->execute();
            flash('ok', 'Status berkas diperbarui.');

        } elseif ($aksi === 'hapus_berkas') {
            $idb = (int)$_POST['id_berkas'];
            $o = $db->query("SELECT file_path FROM berkas_pendaftaran WHERE id_berkas = $idb AND id_pendaftaran = $id")->fetch_assoc();
            if (!$o) throw new RuntimeException('Berkas tidak ditemukan.');
            $db->query("DELETE FROM berkas_pendaftaran WHERE id_berkas = $idb AND id_pendaftaran = $id");
            hapus_file($o['file_path']);
            flash('ok', 'Berkas dihapus.');

        } elseif ($aksi === 'tambah_bayar') {
            [$jenis, $nominal, $tgl] = bayar_dari_post($JENIS_BAYAR);
            $bukti = !empty($_FILES['bukti']['name']) ? simpan_upload('bukti', 'bayar') : null;
            $s = $db->prepare('INSERT INTO pembayaran (id_pendaftaran, jenis_bayar, nominal, tgl_bayar, bukti_path) VALUES (?,?,?,?,?)');
            $s->bind_param('isiss', $id, $jenis, $nominal, $tgl, $bukti);
            $s->execute();
            flash('ok', 'Pembayaran dicatat.');

        } elseif ($aksi === 'ubah_bayar') {
            $idb = (int)$_POST['id_bayar'];
            $o = $db->query("SELECT bukti_path FROM pembayaran WHERE id_bayar = $idb AND id_pendaftaran = $id")->fetch_assoc();
            if (!$o) throw new RuntimeException('Data pembayaran tidak ditemukan.');
            [$jenis, $nominal, $tgl] = bayar_dari_post($JENIS_BAYAR);
            $bukti = !empty($_FILES['bukti']['name']) ? simpan_upload('bukti', 'bayar') : null;
            $s = $db->prepare('UPDATE pembayaran SET jenis_bayar = ?, nominal = ?, tgl_bayar = ?, bukti_path = COALESCE(?, bukti_path)
                               WHERE id_bayar = ? AND id_pendaftaran = ?');
            $s->bind_param('sissii', $jenis, $nominal, $tgl, $bukti, $idb, $id);
            $s->execute();
            if ($bukti) hapus_file($o['bukti_path']);
            flash('ok', 'Pembayaran diperbarui.');

        } elseif ($aksi === 'status_bayar') {
            if (!in_array($_POST['status'] ?? '', ['menunggu', 'lunas', 'ditolak'], true)) throw new RuntimeException('Status tidak valid.');
            $s = $db->prepare('UPDATE pembayaran SET status = ? WHERE id_bayar = ? AND id_pendaftaran = ?');
            $s->bind_param('sii', $_POST['status'], $_POST['id_bayar'], $id);
            $s->execute();
            flash('ok', 'Status pembayaran diperbarui.');

        } elseif ($aksi === 'hapus_bayar') {
            $idb = (int)$_POST['id_bayar'];
            $o = $db->query("SELECT bukti_path FROM pembayaran WHERE id_bayar = $idb AND id_pendaftaran = $id")->fetch_assoc();
            if (!$o) throw new RuntimeException('Data pembayaran tidak ditemukan.');
            $db->query("DELETE FROM pembayaran WHERE id_bayar = $idb AND id_pendaftaran = $id");
            hapus_file($o['bukti_path']);
            flash('ok', 'Pembayaran dihapus.');

        } elseif ($aksi === 'tambah_beasiswa') {
            $idb = (int)($_POST['id_beasiswa'] ?? 0);
            $idp = ($_POST['id_potongan'] ?? '') !== '' ? (int)$_POST['id_potongan'] : null;
            $c = $db->prepare('SELECT 1 FROM beasiswa WHERE id_beasiswa = ? AND id_jalur = ?');
            $c->bind_param('ii', $idb, $d['id_jalur']);
            $c->execute();
            if (!$c->get_result()->fetch_row()) throw new RuntimeException('Beasiswa tidak sesuai dengan jalur pendaftaran.');
            if ($idp !== null) {
                $c = $db->prepare('SELECT 1 FROM potongan_uang_kuliah WHERE id_potongan = ? AND id_beasiswa = ?');
                $c->bind_param('ii', $idp, $idb);
                $c->execute();
                if (!$c->get_result()->fetch_row()) throw new RuntimeException('Potongan tidak sesuai dengan beasiswa yang dipilih.');
            }
            $s = $db->prepare('INSERT INTO penerima_beasiswa (id_calon, id_beasiswa, id_potongan) VALUES (?,?,?)');
            $s->bind_param('iii', $id_calon, $idb, $idp);
            $s->execute();
            flash('ok', 'Beasiswa diajukan.');

        } elseif ($aksi === 'status_beasiswa') {
            if (!in_array($_POST['status'] ?? '', ['diajukan', 'disetujui', 'ditolak', 'berakhir'], true)) throw new RuntimeException('Status tidak valid.');
            $s = $db->prepare("UPDATE penerima_beasiswa
                SET status = ?, tgl_ditetapkan = IF(? = 'disetujui', CURDATE(), tgl_ditetapkan)
                WHERE id_penerima = ? AND id_calon = ?");
            $s->bind_param('ssii', $_POST['status'], $_POST['status'], $_POST['id_penerima'], $id_calon);
            $s->execute();
            flash('ok', 'Status beasiswa diperbarui.');

        } elseif ($aksi === 'hapus_beasiswa') {
            $s = $db->prepare('DELETE FROM penerima_beasiswa WHERE id_penerima = ? AND id_calon = ?');
            $s->bind_param('ii', $_POST['id_penerima'], $id_calon);
            $s->execute();
            flash('ok', 'Beasiswa dihapus.');

        } elseif ($aksi === 'buat_jadwal') {
            $dibuat = buat_jadwal_seleksi($db, $id);
            flash($dibuat ? 'ok' : 'err', $dibuat ? 'Jadwal ujian dan wawancara dibuat.' : 'Jadwal tidak dibuat (bukan jalur beasiswa atau sudah ada).');
        }
    } catch (mysqli_sql_exception $e) { flash('err', galat_sql($e)); }
    catch (RuntimeException $e) { flash('err', $e->getMessage()); }
    header('Location: pendaftaran_detail.php?id=' . $id); exit;
}

// ---------- Ambil data ----------
$berkas = $db->query("SELECT * FROM berkas_pendaftaran WHERE id_pendaftaran = $id ORDER BY id_berkas")->fetch_all(MYSQLI_ASSOC);
$bayar  = $db->query("SELECT * FROM pembayaran WHERE id_pendaftaran = $id ORDER BY id_bayar")->fetch_all(MYSQLI_ASSOC);
$lunas  = $db->query("SELECT COALESCE(SUM(nominal),0) t FROM pembayaran WHERE id_pendaftaran = $id AND status = 'lunas'")->fetch_assoc()['t'];
$jadwal = $db->query("SELECT * FROM jadwal_seleksi WHERE id_pendaftaran = $id ORDER BY tanggal, jam")->fetch_all(MYSQLI_ASSOC);

$ub = null;   // pembayaran yang sedang diubah
if (isset($_GET['ubah'])) {
    foreach ($bayar as $p) { if ($p['id_bayar'] == (int)$_GET['ubah']) $ub = $p; }
}
$fv = $ub ?: ['jenis_bayar' => 'PENDAFTARAN', 'nominal' => BIAYA_PENDAFTARAN, 'tgl_bayar' => date('Y-m-d'), 'bukti_path' => null];

$penerima = $db->query("SELECT pb.id_penerima, pb.status, pb.tgl_ditetapkan, b.nama_beasiswa, b.sumber_dana,
    pot.nama_potongan, pot.persen
  FROM penerima_beasiswa pb
  JOIN beasiswa b ON b.id_beasiswa = pb.id_beasiswa
  LEFT JOIN potongan_uang_kuliah pot ON pot.id_potongan = pb.id_potongan
  WHERE pb.id_calon = $id_calon ORDER BY pb.id_penerima")->fetch_all(MYSQLI_ASSOC);

$s = $db->prepare('SELECT id_beasiswa, nama_beasiswa FROM beasiswa WHERE id_jalur = ? ORDER BY id_beasiswa');
$s->bind_param('i', $d['id_jalur']); $s->execute();
$opsiBeasiswa = $s->get_result()->fetch_all(MYSQLI_ASSOC);

$s = $db->prepare('SELECT pot.id_potongan, pot.nama_potongan, pot.persen
  FROM potongan_uang_kuliah pot JOIN beasiswa b ON b.id_beasiswa = pot.id_beasiswa
  WHERE b.id_jalur = ? ORDER BY pot.id_potongan');
$s->bind_param('i', $d['id_jalur']); $s->execute();
$opsiPotongan = $s->get_result()->fetch_all(MYSQLI_ASSOC);

$judul = 'Detail Pendaftaran';
require 'partials/atas.php';
?>
<a class="btn" href="pendaftaran.php">&larr; Kembali ke daftar</a>
<?php tampil_flash(); ?>

<div class="card">
<h2><?= h($d['nama']) ?> <?= lencana($d['status']) ?></h2>
<dl class="kv">
<dt>Email</dt><dd><?= h($d['email']) ?></dd>
<dt>No. HP</dt><dd><?= h($d['no_hp']) ?></dd>
<dt>Asal sekolah</dt><dd><?= h($d['asal_sekolah']) ?></dd>
<dt>Program studi</dt><dd><?= h($d['nama_prodi']) ?> (<?= h($d['jenjang']) ?>)</dd>
<dt>Jalur</dt><dd><?= h($d['nama_jalur']) ?><?= $d['nama_gelombang'] ? ' - ' . h($d['nama_gelombang']) : '' ?></dd>
<dt>Skema pembayaran</dt><dd><?= $d['skema'] ? h($d['skema']) . ' (' . rp($d['nominal_cicilan']) . ($d['diskon_persen'] > 0 ? ', diskon ' . (float)$d['diskon_persen'] . '%' : '') . ')' : '-' ?></dd>
<dt>Total lunas</dt><dd><b><?= rp($lunas) ?></b></dd>
</dl>
<p><a href="pendaftaran_edit.php?id=<?= $id ?>">Edit data pendaftaran</a></p>
</div>

<?php if (!$d['pakai_gelombang']): ?>
<div class="card">
<h3>Jadwal Ujian dan Wawancara</h3>
<?php if ($jadwal): ?>
<div class="scroll"><table>
<tr><th>Jenis</th><th>Hari dan tanggal</th><th>Jam</th><th>Lokasi</th><th>Status</th><th>Aksi</th></tr>
<?php foreach ($jadwal as $j): ?>
<tr><td><?= h($j['jenis']) ?></td><td><?= h(tgl_id($j['tanggal'])) ?></td><td><?= h(substr($j['jam'], 0, 5)) ?></td>
<td><?= h($j['lokasi']) ?></td><td><?= lencana($j['status']) ?></td>
<td class="aksi"><a href="jadwal_seleksi.php?ubah=<?= (int)$j['id_jadwal'] ?>">Ubah</a></td></tr>
<?php endforeach; ?>
</table></div>
<?php else: ?>
<p class="kecil">Belum ada jadwal untuk pendaftar ini.</p>
<form method="post"><input type="hidden" name="aksi" value="buat_jadwal"><button style="width:auto">Buat jadwal otomatis</button></form>
<?php endif; ?>
</div>
<?php endif; ?>

<div class="card">
<h3>Berkas Pendaftaran</h3>
<form method="post" enctype="multipart/form-data" class="inline">
  <input type="hidden" name="aksi" value="upload_berkas">
  <div><label>Jenis berkas</label>
  <select name="jenis_berkas">
  <?php foreach ($JENIS_BERKAS as $k => $v): ?><option value="<?= h($k) ?>"><?= h($v) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>File (PDF/JPG/PNG, maks 2 MB)</label><input type="file" name="file" required></div>
  <button>Unggah</button>
</form>
<div class="scroll"><table>
<tr><th>Jenis</th><th>File</th><th>Status</th><th>Verifikasi</th><th>Aksi</th></tr>
<?php foreach ($berkas as $b): ?>
<tr>
<td><?= h($JENIS_BERKAS[$b['jenis_berkas']] ?? $b['jenis_berkas']) ?></td>
<td><a href="<?= h($b['file_path']) ?>" target="_blank">Lihat file</a></td>
<td><?= lencana($b['status_verifikasi']) ?></td>
<td><form method="post">
  <input type="hidden" name="aksi" value="verif_berkas">
  <input type="hidden" name="id_berkas" value="<?= (int)$b['id_berkas'] ?>">
  <select name="status">
  <?php foreach (['menunggu', 'valid', 'ditolak'] as $x): ?>
    <option <?= $b['status_verifikasi'] === $x ? 'selected' : '' ?>><?= $x ?></option>
  <?php endforeach; ?>
  </select> <button>Simpan</button></form></td>
<td class="aksi"><?= form_hapus('hapus_berkas', 'id_berkas', $b['id_berkas'], 'Hapus berkas ini?') ?></td>
</tr>
<?php endforeach; ?>
<?php if (!$berkas): ?><tr><td colspan="5">Belum ada berkas.</td></tr><?php endif; ?>
</table></div>
<p class="kecil">Untuk mengganti berkas, hapus yang lama lalu unggah yang baru.</p>
</div>

<div class="card">
<h3><?= $ub ? 'Ubah Pembayaran' : 'Pembayaran' ?></h3>
<form method="post" enctype="multipart/form-data" class="inline">
  <input type="hidden" name="aksi" value="<?= $ub ? 'ubah_bayar' : 'tambah_bayar' ?>">
  <?php if ($ub): ?><input type="hidden" name="id_bayar" value="<?= (int)$ub['id_bayar'] ?>"><?php endif; ?>
  <div><label>Jenis</label>
  <select name="jenis_bayar">
  <?php foreach ($JENIS_BAYAR as $k => $v): ?><option value="<?= h($k) ?>" <?= $fv['jenis_bayar'] === $k ? 'selected' : '' ?>><?= h($v) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Nominal (Rp)</label><input id="nominal" name="nominal" inputmode="numeric" placeholder="1500000" required value="<?= h($fv['nominal']) ?>"></div>
  <div><label>Tanggal bayar</label><input name="tgl_bayar" type="date" value="<?= h($fv['tgl_bayar']) ?>"></div>
  <div><label>Bukti <?= $ub ? '(kosongkan jika tidak diganti)' : '(opsional)' ?></label><input type="file" name="bukti"></div>
  <button><?= $ub ? 'Simpan perubahan' : 'Catat' ?></button>
  <?php if ($ub): ?><a class="btn" style="margin:0" href="pendaftaran_detail.php?id=<?= $id ?>">Batal</a><?php endif; ?>
</form>
<script>
(function () {
  var BIAYA = <?= (int)BIAYA_PENDAFTARAN ?>;
  var jenis = document.querySelector('select[name="jenis_bayar"]');
  var nominal = document.getElementById('nominal');
  function kunci() { nominal.value = BIAYA; nominal.readOnly = true; }
  function buka() { nominal.readOnly = false; if (nominal.value == BIAYA) nominal.value = ''; nominal.focus(); }
  jenis.addEventListener('change', function () { if (jenis.value === 'PENDAFTARAN') kunci(); else buka(); });
  if (jenis.value === 'PENDAFTARAN') kunci();
})();
</script>
<div class="scroll"><table>
<tr><th>Jenis</th><th>Nominal</th><th>Tanggal</th><th>Bukti</th><th>Status</th><th>Ubah status</th><th>Aksi</th></tr>
<?php foreach ($bayar as $p): ?>
<tr>
<td><?= h($JENIS_BAYAR[$p['jenis_bayar']] ?? $p['jenis_bayar']) ?></td>
<td><?= rp($p['nominal']) ?></td>
<td><?= h($p['tgl_bayar'] ?? '-') ?></td>
<td><?= $p['bukti_path'] ? '<a href="' . h($p['bukti_path']) . '" target="_blank">Lihat</a>' : '-' ?></td>
<td><?= lencana($p['status']) ?></td>
<td><form method="post">
  <input type="hidden" name="aksi" value="status_bayar">
  <input type="hidden" name="id_bayar" value="<?= (int)$p['id_bayar'] ?>">
  <select name="status">
  <?php foreach (['menunggu', 'lunas', 'ditolak'] as $x): ?>
    <option <?= $p['status'] === $x ? 'selected' : '' ?>><?= $x ?></option>
  <?php endforeach; ?>
  </select> <button>Simpan</button></form></td>
<td class="aksi"><a href="pendaftaran_detail.php?id=<?= $id ?>&ubah=<?= (int)$p['id_bayar'] ?>">Ubah</a>
  <?= form_hapus('hapus_bayar', 'id_bayar', $p['id_bayar'], 'Hapus pembayaran ini?') ?></td>
</tr>
<?php endforeach; ?>
<?php if (!$bayar): ?><tr><td colspan="7">Belum ada pembayaran.</td></tr><?php endif; ?>
</table></div>
</div>

<div class="card">
<h3>Beasiswa</h3>
<?php if ($opsiBeasiswa): ?>
<form method="post" class="inline">
  <input type="hidden" name="aksi" value="tambah_beasiswa">
  <div><label>Beasiswa</label>
  <select name="id_beasiswa">
  <?php foreach ($opsiBeasiswa as $b): ?><option value="<?= (int)$b['id_beasiswa'] ?>"><?= h($b['nama_beasiswa']) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Potongan (khusus Beasiswa Yayasan)</label>
  <select name="id_potongan">
  <option value="">- tidak ada -</option>
  <?php foreach ($opsiPotongan as $p): ?><option value="<?= (int)$p['id_potongan'] ?>"><?= h($p['nama_potongan']) ?> (<?= (float)$p['persen'] ?>%)</option><?php endforeach; ?>
  </select></div>
  <button>Ajukan</button>
</form>
<?php else: ?>
<p class="kecil">Jalur <?= h($d['nama_jalur']) ?> tidak memiliki beasiswa.</p>
<?php endif; ?>
<div class="scroll"><table>
<tr><th>Beasiswa</th><th>Sumber</th><th>Potongan</th><th>Ditetapkan</th><th>Status</th><th>Ubah status</th><th>Aksi</th></tr>
<?php foreach ($penerima as $b): ?>
<tr>
<td><?= h($b['nama_beasiswa']) ?></td>
<td><?= h($b['sumber_dana']) ?></td>
<td><?= $b['nama_potongan'] ? h($b['nama_potongan']) . ' (' . (float)$b['persen'] . '%)' : '-' ?></td>
<td><?= h($b['tgl_ditetapkan'] ?? '-') ?></td>
<td><?= lencana($b['status']) ?></td>
<td><form method="post">
  <input type="hidden" name="aksi" value="status_beasiswa">
  <input type="hidden" name="id_penerima" value="<?= (int)$b['id_penerima'] ?>">
  <select name="status">
  <?php foreach (['diajukan', 'disetujui', 'ditolak', 'berakhir'] as $x): ?>
    <option <?= $b['status'] === $x ? 'selected' : '' ?>><?= $x ?></option>
  <?php endforeach; ?>
  </select> <button>Simpan</button></form></td>
<td class="aksi"><?= form_hapus('hapus_beasiswa', 'id_penerima', $b['id_penerima'], 'Hapus beasiswa ini?') ?></td>
</tr>
<?php endforeach; ?>
<?php if (!$penerima): ?><tr><td colspan="7">Belum ada beasiswa.</td></tr><?php endif; ?>
</table></div>
</div>
<?php require 'partials/bawah.php'; ?>