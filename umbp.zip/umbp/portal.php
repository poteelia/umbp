<?php
// Dashboard mahasiswa: semua menu dalam satu halaman dan saling berkaitan.
// Pendaftaran -> lulus -> punya NIM -> absensi & riwayat akademik. Tagihan dan organisasi ikut status.
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/mahasiswa.php';
wajib_login(['calon']);
$idc = id_calon_akun($db);
if (!$idc) { header('Location: daftar_data.php'); exit; }

// ===== Pendaftaran terbaru =====
$q = $db->prepare('SELECT p.id_pendaftaran, p.id_jalur, p.status_administrasi, p.status, p.hasil_wawancara,
        ps.nama_prodi, ps.jenjang, j.nama_jalur, j.alur, j.perlu_lldikti, j.perlu_yayasan, g.nama_gelombang
    FROM pendaftaran p
    JOIN program_studi ps ON ps.id_prodi = p.id_prodi
    JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
    LEFT JOIN gelombang g ON g.id_gelombang = p.id_gelombang
    WHERE p.id_calon = ? ORDER BY p.id_pendaftaran DESC LIMIT 1');
$q->bind_param('i', $idc); $q->execute();
$d = $q->get_result()->fetch_assoc(); $q->close();
if (!$d) { header('Location: daftar_data.php'); exit; }
$idp = (int)$d['id_pendaftaran'];
$lulusDaftar = $d['status'] === 'lulus';
$garis = linimasa($db, $d);

// ===== Data calon (dipakai profil) =====
$q = $db->prepare('SELECT nama, jenis_kelamin, email, no_hp, asal_sekolah, tahun_lulus FROM calon_mahasiswa WHERE id_calon = ?');
$q->bind_param('i', $idc); $q->execute();
$c = $q->get_result()->fetch_assoc(); $q->close();

// ===== Berkas =====
$wajib = berkas_jalur($db, (int)$d['id_jalur']);
$q = $db->prepare('SELECT jenis_berkas, status_verifikasi FROM berkas_pendaftaran WHERE id_pendaftaran = ?');
$q->bind_param('i', $idp); $q->execute();
$berkas = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
$sudah = array_column($berkas, 'jenis_berkas');
$wajibTerunggah = 0;
foreach ($wajib as $k => $v) { if (in_array($k, $sudah, true)) $wajibTerunggah++; }
$berkasValid = 0;
foreach ($berkas as $b) { if ($b['status_verifikasi'] === 'valid') $berkasValid++; }

// ===== Tagihan / pembayaran (termasuk pembayaran pendaftaran) =====
$q = $db->prepare('SELECT y.jenis_bayar, y.nominal, y.tgl_bayar, y.status
    FROM pembayaran y JOIN pendaftaran x ON x.id_pendaftaran = y.id_pendaftaran
    WHERE x.id_calon = ? ORDER BY y.tgl_bayar DESC');
$q->bind_param('i', $idc); $q->execute();
$tagihan = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
$totalLunas = 0; $totalMenunggu = 0; $bayarDaftarLunas = false;
foreach ($tagihan as $tg) {
    if ($tg['status'] === 'lunas') {
        $totalLunas += (int)$tg['nominal'];
        if (strtoupper((string)$tg['jenis_bayar']) === 'PENDAFTARAN') $bayarDaftarLunas = true;
    } else {
        $totalMenunggu += (int)$tg['nominal'];
    }
}

// ===== Organisasi =====
$q = $db->prepare('SELECT o.nama_org, o.singkatan, k.nama_kategori
    FROM pendaftaran_organisasi po
    JOIN organisasi o ON o.id_org = po.id_org
    JOIN kategori_organisasi k ON k.id_kategori = o.id_kategori
    WHERE po.id_calon = ? ORDER BY o.nama_org');
$q->bind_param('i', $idc); $q->execute();
$orgSaya = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();

// ===== Data mahasiswa (hanya kalau sudah punya NIM) =====
$mh = data_mahasiswa($db, $idc);
$semAll = []; $semRow = null; $skSekarang = null; $skDipilih = null;
$absensi = []; $rekap = null; $riwayat = []; $nilaiMk = []; $ipkTerakhir = null;
if ($mh) {
    $nim = (string)$mh['nim']; $idProdi = (int)$mh['id_prodi'];
    $angkatan = $mh['angkatan'] !== null ? (int)$mh['angkatan'] : null;
    $semAll = daftar_semester($db);
    $semRow = semester_terpilih($semAll);
    if ($semAll) $skSekarang = semester_ke($angkatan, (string)$semAll[0]['tahun_akademik'], (string)$semAll[0]['jenis']);
    if ($semRow) {
        $idSem = (int)$semRow['id_semester'];
        $skDipilih = semester_ke($angkatan, (string)$semRow['tahun_akademik'], (string)$semRow['jenis']);
        $skCari = $skDipilih ?? 0;   // 0 = hanya mata kuliah yang sudah punya absensi

        $q = $db->prepare("SELECT m.kode_mk, m.nama_mk,
                COALESCE(SUM(a.status_hadir = 'hadir'), 0) AS hadir,
                COALESCE(SUM(a.status_hadir = 'izin'), 0) AS izin,
                COALESCE(SUM(a.status_hadir = 'sakit'), 0) AS sakit,
                COALESCE(SUM(a.status_hadir = 'alpa'), 0) AS alpa
            FROM mata_kuliah m
            LEFT JOIN absensi a ON a.id_matkul = m.id_matkul AND a.nim = ? AND a.id_semester = ?
            WHERE m.id_prodi = ? AND (m.semester_ke = ? OR a.id_matkul IS NOT NULL)
            GROUP BY m.id_matkul, m.kode_mk, m.nama_mk
            ORDER BY m.kode_mk");
        $q->bind_param('siii', $nim, $idSem, $idProdi, $skCari); $q->execute();
        $absensi = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();

        $q = $db->prepare('SELECT total_pertemuan, total_hadir, persen_hadir FROM rekap_kehadiran WHERE nim = ? AND id_semester = ?');
        $q->bind_param('si', $nim, $idSem); $q->execute();
        $rekap = $q->get_result()->fetch_assoc(); $q->close();

        $q = $db->prepare('SELECT m.kode_mk, m.nama_mk, m.sks, n.nilai_angka, n.huruf
            FROM nilai_matkul n JOIN mata_kuliah m ON m.id_matkul = n.id_matkul
            WHERE n.nim = ? AND n.id_semester = ? ORDER BY m.kode_mk');
        $q->bind_param('si', $nim, $idSem); $q->execute();
        $nilaiMk = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
    }
    $q = $db->prepare('SELECT s.tahun_akademik, s.jenis, n.ips, n.ipk
        FROM nilai_semester n JOIN semester s ON s.id_semester = n.id_semester
        WHERE n.nim = ? ORDER BY n.id_semester');
    $q->bind_param('s', $nim); $q->execute();
    $riwayat = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
    $ipkTerakhir = $riwayat ? end($riwayat)['ipk'] : null;
}

$kunci = fn(string $t) => '<div class="info-kunci">🔒 ' . $t . '</div>';

$judul = 'Dashboard';
require 'partials/atas.php';
?>
<style>
.garis{list-style:none;padding:0;margin:12px 0;display:flex;flex-wrap:wrap;gap:8px}
.garis li{padding:6px 12px;border-radius:20px;font-size:13px;background:#eee;color:#666}
.garis .selesai{background:#d9f2e0;color:#1b6b34}
.garis .sekarang{background:#fff3cd;color:#8a6100;font-weight:600}
.garis .gagal{background:#f8d7da;color:#842029;font-weight:600}
.info-kunci{background:#fff3cd;color:#8a6100;padding:12px 16px;border-radius:10px;font-size:14px}
.kotak-info{background:#eef4ff;color:#1f4a8a;padding:12px 16px;border-radius:10px;font-size:14px;margin-top:12px}
.profil-item .kecil{display:block}
.angka-besar{font-size:22px;font-weight:700;color:#8b0d0d}
.alur{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:14px}
.alur span.st{padding:7px 14px;border-radius:20px;font-size:13px;background:#eee;color:#666}
.alur span.st.buka{background:#d9f2e0;color:#1b6b34;font-weight:600}
.alur span.st.kini{background:#fff3cd;color:#8a6100;font-weight:600}
.alur i{font-style:normal;color:#aaa}
</style>

<?php /* ===== Ringkasan + alur keterkaitan ===== */ ?>
<div class="card">
<h2>Halo, <?= h($c['nama']) ?></h2>
<?php tampil_flash(); ?>
<p>Prodi: <b><?= h($d['nama_prodi']) ?></b> | Jalur: <b><?= h($d['nama_jalur']) ?></b></p>
<div class="alur">
  <span class="st <?= $lulusDaftar ? 'buka' : 'kini' ?>">1. Pendaftaran: <?= h($d['status']) ?></span><i>→</i>
  <span class="st <?= $mh ? 'buka' : ($lulusDaftar ? 'kini' : '') ?>">2. NIM: <?= $mh ? h($mh['nim']) : 'belum ada' ?></span><i>→</i>
  <span class="st <?= $mh ? 'buka' : '' ?>">3. Absensi &amp; Riwayat Akademik <?= $mh ? 'terbuka' : 'terkunci' ?></span><i>→</i>
  <span class="st <?= $tagihan ? 'buka' : '' ?>">4. Tagihan: <?= count($tagihan) ?> transaksi</span><i>→</i>
  <span class="st <?= $orgSaya ? 'buka' : ($lulusDaftar ? 'kini' : '') ?>">5. Organisasi: <?= count($orgSaya) ?> diikuti</span>
</div>
</div>

<?php /* ===== 1. Pendaftaran ===== */ ?>
<div class="card" id="pendaftaran">
<h3>Pendaftaran</h3>
<ul class="garis">
<?php foreach ($garis as [$label, $st]): ?><li class="<?= h($st) ?>"><?= h($label) ?></li><?php endforeach; ?>
</ul>
<div class="grid">
  <div class="profil-item"><span class="kecil">Status administrasi</span><?= lencana($d['status_administrasi']) ?></div>
  <div class="profil-item"><span class="kecil">Status akhir</span><?= lencana($d['status']) ?></div>
  <div class="profil-item"><span class="kecil">Gelombang</span><b><?= h($d['nama_gelombang'] ?? '-') ?></b></div>
  <div class="profil-item"><span class="kecil">Berkas wajib terunggah</span><b><?= $wajibTerunggah ?>/<?= count($wajib) ?></b></div>
  <div class="profil-item"><span class="kecil">Berkas valid</span><b><?= $berkasValid ?>/<?= count($berkas) ?></b></div>
  <div class="profil-item"><span class="kecil">Bayar pendaftaran</span><?= $bayarDaftarLunas ? lencana('lunas') : lencana('belum') ?></div>
</div>
<?php if ($lulusDaftar): ?>
<div class="kotak-info" style="background:#d9f2e0;color:#1b6b34">🎉 Kamu dinyatakan <b>lulus</b>. Setelah tercatat sebagai mahasiswa (punya NIM), absensi dan riwayat akademik akan terisi.</div>
<?php endif; ?>
<p style="margin-top:12px"><a class="btn" href="pendaftaran_saya.php">Buka Pendaftaran</a></p>
</div>

<?php /* ===== 2. Profil Mahasiswa ===== */ ?>
<div class="card" id="profil">
<h3>Profil Mahasiswa</h3>
<div class="grid">
  <div class="profil-item"><span class="kecil">NIM</span><b><?= $mh ? h($mh['nim']) : '-' ?></b></div>
  <div class="profil-item"><span class="kecil">Nama</span><b><?= h($c['nama']) ?></b></div>
  <div class="profil-item"><span class="kecil">Program studi</span><b><?= h($d['nama_prodi']) ?> (<?= h($d['jenjang']) ?>)</b></div>
  <div class="profil-item"><span class="kecil">Angkatan</span><b><?= $mh && $mh['angkatan'] !== null ? (int)$mh['angkatan'] : '-' ?></b></div>
  <div class="profil-item"><span class="kecil">Semester berjalan</span><b><?= $skSekarang !== null ? 'Semester ' . (int)$skSekarang : '-' ?></b></div>
  <div class="profil-item"><span class="kecil">Status</span><?= $mh ? lencana($mh['status_akademik']) : lencana($d['status']) ?></div>
  <div class="profil-item"><span class="kecil">IPK terakhir</span><span class="angka-besar"><?= $ipkTerakhir !== null ? h($ipkTerakhir) : '-' ?></span></div>
  <div class="profil-item"><span class="kecil">Email</span><b><?= h($c['email']) ?></b></div>
  <div class="profil-item"><span class="kecil">No. HP</span><b><?= h($c['no_hp']) ?></b></div>
  <div class="profil-item"><span class="kecil">Asal sekolah</span><b><?= h($c['asal_sekolah']) ?></b></div>
  <div class="profil-item"><span class="kecil">Tahun lulus sekolah</span><b><?= h($c['tahun_lulus']) ?></b></div>
</div>
<?php if ($mh): echo kotak_lulus($mh); else: ?>
<div class="kotak-info">NIM, angkatan, semester, dan IPK akan terisi setelah kamu dinyatakan lulus dan tercatat sebagai mahasiswa.</div>
<?php endif; ?>
<p style="margin-top:14px"><a class="btn" href="profil.php">Edit profil</a></p>
</div>

<?php /* ===== 3. Absensi ===== */ ?>
<div class="card" id="absensi">
<h3>Absensi per Mata Kuliah</h3>
<?php if (!$mh): ?>
  <?= $kunci('Absensi terisi setelah kamu punya NIM (lulus dan tercatat sebagai mahasiswa).') ?>
<?php elseif (!$semAll): ?>
  <p class="kecil">Belum ada data semester.</p>
<?php else: ?>
<form method="get" action="portal.php#absensi" class="inline">
  <div><label>Semester</label><select name="sem" onchange="this.form.submit()">
    <?php foreach ($semAll as $sx): ?><option value="<?= (int)$sx['id_semester'] ?>" <?= (int)$semRow['id_semester'] === (int)$sx['id_semester'] ? 'selected' : '' ?>><?= h($sx['tahun_akademik']) ?> <?= h($sx['jenis']) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Program studi</label><input value="<?= h($mh['nama_prodi']) ?> (<?= h($mh['jenjang']) ?>)" readonly tabindex="-1"></div>
</form>
<p class="kecil">Setiap mata kuliah memiliki <?= JUMLAH_PERTEMUAN ?> pertemuan per semester.<?= $skDipilih !== null ? ' Pada semester ini kamu berada di semester perkuliahan ke-' . (int)$skDipilih . '.' : '' ?></p>
<div class="scroll"><table>
<tr><th>Kode</th><th>Mata kuliah</th><th>Hadir</th><th>Izin</th><th>Sakit</th><th>Alpa</th><th>Kehadiran</th></tr>
<?php foreach ($absensi as $r): $persenMk = (int)$r['hadir'] / JUMLAH_PERTEMUAN * 100; ?>
<tr>
  <td><?= h($r['kode_mk']) ?></td><td><?= h($r['nama_mk']) ?></td>
  <td><b><?= (int)$r['hadir'] ?>/<?= JUMLAH_PERTEMUAN ?></b></td>
  <td><?= (int)$r['izin'] ?></td><td><?= (int)$r['sakit'] ?></td><td><?= (int)$r['alpa'] ?></td>
  <td><?= bar_hadir($persenMk) ?></td>
</tr>
<?php endforeach; ?>
<?php if (!$absensi): ?><tr><td colspan="7">Belum ada data absensi pada semester ini.</td></tr><?php endif; ?>
</table></div>
<?php if ($rekap): ?>
<p style="margin-top:10px">Total semester ini: <b><?= (int)$rekap['total_hadir'] ?>/<?= (int)$rekap['total_pertemuan'] ?></b> pertemuan hadir (<b><?= h($rekap['persen_hadir']) ?>%</b>).</p>
<?php endif; ?>
<?php endif; ?>
</div>

<?php /* ===== 4. Riwayat Akademik ===== */ ?>
<div class="card" id="akademik">
<h3>Riwayat Akademik</h3>
<?php if (!$mh): ?>
  <?= $kunci('Riwayat akademik (IPS, IPK, dan nilai) terisi setelah kamu punya NIM.') ?>
<?php else: ?>
<div class="scroll"><table>
<tr><th>Semester</th><th>IPS</th><th>IPK</th></tr>
<?php foreach ($riwayat as $r): ?>
<tr><td><?= h($r['tahun_akademik']) ?> <?= h($r['jenis']) ?></td><td><?= h($r['ips']) ?></td><td><b><?= h($r['ipk']) ?></b></td></tr>
<?php endforeach; ?>
<?php if (!$riwayat): ?><tr><td colspan="3">Belum ada nilai.</td></tr><?php endif; ?>
</table></div>
<?php if ($semRow): ?>
<h3 style="margin-top:18px">Nilai Mata Kuliah: <?= h($semRow['tahun_akademik']) ?> <?= h($semRow['jenis']) ?></h3>
<div class="scroll"><table>
<tr><th>Kode</th><th>Mata kuliah</th><th>SKS</th><th>Nilai</th><th>Huruf</th></tr>
<?php foreach ($nilaiMk as $r): ?>
<tr><td><?= h($r['kode_mk']) ?></td><td><?= h($r['nama_mk']) ?></td><td><?= (int)$r['sks'] ?></td><td><?= h($r['nilai_angka']) ?></td><td><b><?= h($r['huruf']) ?></b></td></tr>
<?php endforeach; ?>
<?php if (!$nilaiMk): ?><tr><td colspan="5">Belum ada nilai mata kuliah pada semester ini.</td></tr><?php endif; ?>
</table></div>
<p class="kecil">Semester dipilih lewat menu Semester di kartu Absensi.</p>
<?php endif; ?>
<?php endif; ?>
</div>

<?php /* ===== 5. Riwayat Tagihan ===== */ ?>
<div class="card" id="tagihan">
<h3>Riwayat Tagihan</h3>
<div class="grid">
  <div class="profil-item"><span class="kecil">Total lunas</span><span class="angka-besar">Rp<?= number_format($totalLunas, 0, ',', '.') ?></span></div>
  <div class="profil-item"><span class="kecil">Belum lunas / menunggu verifikasi</span><span class="angka-besar">Rp<?= number_format($totalMenunggu, 0, ',', '.') ?></span></div>
  <div class="profil-item"><span class="kecil">Jumlah transaksi</span><span class="angka-besar"><?= count($tagihan) ?></span></div>
</div>
<div class="scroll"><table>
<tr><th>Tanggal</th><th>Jenis</th><th>Nominal</th><th>Status</th></tr>
<?php foreach ($tagihan as $tg): ?>
<tr><td><?= h($tg['tgl_bayar']) ?></td>
<td><?= h(ucwords(strtolower(str_replace('_', ' ', (string)$tg['jenis_bayar'])))) ?></td>
<td>Rp<?= number_format((int)$tg['nominal'], 0, ',', '.') ?></td>
<td><?= lencana($tg['status']) ?></td></tr>
<?php endforeach; ?>
<?php if (!$tagihan): ?><tr><td colspan="4">Belum ada tagihan atau pembayaran.</td></tr><?php endif; ?>
</table></div>
<p class="kecil" style="margin-top:8px">Pembayaran pendaftaran dari menu Pendaftaran otomatis tercatat di sini.</p>
</div>

<?php /* ===== 6. Organisasi ===== */ ?>
<div class="card" id="organisasi">
<h3>Organisasi</h3>
<?php if ($orgSaya): ?>
<div class="scroll"><table>
<tr><th>Organisasi</th><th>Singkatan</th><th>Kategori</th></tr>
<?php foreach ($orgSaya as $o): ?>
<tr><td><?= h($o['nama_org']) ?></td><td><?= h($o['singkatan']) ?></td><td><?= h($o['nama_kategori']) ?></td></tr>
<?php endforeach; ?>
</table></div>
<?php elseif ($lulusDaftar): ?>
<p class="kecil">Kamu sudah lulus tetapi belum mengikuti organisasi apa pun. Silakan pilih organisasi.</p>
<?php else: ?>
<?= $kunci('Organisasi bisa dipilih setelah kamu dinyatakan lulus.') ?>
<?php endif; ?>
<p style="margin-top:12px"><a class="btn" href="organisasi_saya.php">Kelola organisasi</a></p>
</div>
<?php require 'partials/bawah.php'; ?>