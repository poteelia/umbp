<?php
require 'config/koneksi.php'; require 'config/bantu.php';
wajib_login(['admin', 'panitia']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    try {
        $db->begin_transaction();
        if ($aksi === 'wawancara') {
            catat_hasil_wawancara($db, $id, $_POST['hasil'] ?? '', trim($_POST['nilai'] ?? ''), trim($_POST['catatan'] ?? ''));
            flash('ok', 'Hasil wawancara disimpan.');
        } elseif ($aksi === 'lembaga') {
            catat_putusan_lembaga($db, $id, $_POST['lembaga'] ?? '', $_POST['putusan'] ?? '', trim($_POST['catatan'] ?? ''));
            flash('ok', 'Putusan disimpan.');
        } elseif ($aksi === 'ubah_lembaga') {
            $idk = (int)$_POST['id_keputusan'];
            $lokasi = trim($_POST['lokasi'] ?? '');
            if (!valid_tanggal($_POST['tanggal'] ?? '')) throw new RuntimeException('Tanggal tidak valid.');
            if (!valid_jam($_POST['jam'] ?? '')) throw new RuntimeException('Jam tidak valid (contoh 09:30).');
            if ($lokasi === '') throw new RuntimeException('Lokasi wajib diisi.');
            $s = $db->prepare("UPDATE keputusan_lembaga SET tanggal = ?, jam = ?, lokasi = ? WHERE id_keputusan = ? AND status = 'dijadwalkan'");
            $s->bind_param('sssi', $_POST['tanggal'], $_POST['jam'], $lokasi, $idk); $s->execute();
            flash('ok', 'Jadwal diperbarui.');
        }
        $db->commit();
    } catch (RuntimeException $e) { $db->rollback(); flash('err', $e->getMessage()); }
    catch (mysqli_sql_exception $e) { $db->rollback(); flash('err', galat_sql($e)); }
    header('Location: tahap_lanjut.php'); exit;
}

$rows = $db->query("SELECT p.id_pendaftaran, c.nama, j.nama_jalur, j.perlu_lldikti, j.perlu_yayasan,
    p.status, p.hasil_wawancara, p.nilai_wawancara, p.catatan_wawancara,
    (SELECT CONCAT(w.tanggal, ' ', w.jam) FROM jadwal_seleksi w
       WHERE w.id_pendaftaran = p.id_pendaftaran AND w.jenis = 'wawancara' LIMIT 1) AS jadwal_wawancara
  FROM pendaftaran p
  JOIN calon_mahasiswa c ON c.id_calon = p.id_calon
  JOIN jalur_pendaftaran j ON j.id_jalur = p.id_jalur
  WHERE j.alur = 'khusus' AND p.status_administrasi = 'disetujui'
  ORDER BY p.id_pendaftaran DESC")->fetch_all(MYSQLI_ASSOC);

$lem = [];
foreach ($db->query('SELECT * FROM keputusan_lembaga ORDER BY id_keputusan') as $k) { $lem[$k['id_pendaftaran']][] = $k; }

$judul = 'Seleksi Lanjutan';
require 'partials/atas.php';
?>
<div class="card">
<h2>Seleksi Lanjutan Jalur Khusus</h2>
<?php tampil_flash(); ?>
<p class="kecil">Urutan: wawancara → hasil wawancara → LLDIKTI (jika ada) → Yayasan (jika ada) → lulus. Jadwal LLDIKTI dan Yayasan dibuat otomatis saat tahap sebelumnya lolos dan bisa diubah di sini.</p>
</div>

<?php foreach ($rows as $r): $idp = (int)$r['id_pendaftaran']; ?>
<div class="card">
<h3><?= h($r['nama']) ?> <small>(<?= h($r['nama_jalur']) ?>)</small> <?= lencana($r['status']) ?></h3>

<p><b>1. Wawancara</b>:
<?= $r['jadwal_wawancara'] ? h(tgl_id(substr($r['jadwal_wawancara'], 0, 10))) . ', ' . h(substr($r['jadwal_wawancara'], 11, 5)) : 'belum dijadwalkan' ?>
| Hasil: <?= lencana($r['hasil_wawancara']) ?>
<?= $r['nilai_wawancara'] !== null ? ' | Nilai ' . (int)$r['nilai_wawancara'] : '' ?></p>
<?php if ($r['hasil_wawancara'] === 'belum' && $r['status'] !== 'ditolak'): ?>
<form method="post" class="inline">
  <input type="hidden" name="aksi" value="wawancara"><input type="hidden" name="id" value="<?= $idp ?>">
  <div><label>Hasil</label><select name="hasil"><option value="lulus">Lulus</option><option value="tidak_lulus">Tidak lulus</option></select></div>
  <div><label>Nilai (0-100)</label><input name="nilai" inputmode="numeric"></div>
  <div><label>Catatan</label><input name="catatan" maxlength="255"></div>
  <button>Simpan hasil</button>
</form>
<?php elseif ($r['catatan_wawancara']): ?><p class="kecil">Catatan: <?= h($r['catatan_wawancara']) ?></p><?php endif; ?>

<?php foreach ($lem[$idp] ?? [] as $k): ?>
<hr>
<p><b><?= $k['lembaga'] === 'lldikti' ? '2. LLDIKTI' : (($r['perlu_lldikti'] ? '3' : '2') . '. Yayasan') ?></b>:
<?= h(tgl_id($k['tanggal'])) ?>, <?= h(substr($k['jam'], 0, 5)) ?> di <?= h($k['lokasi']) ?> <?= lencana($k['status']) ?>
<?= $k['catatan'] ? '<br><small>' . h($k['catatan']) . '</small>' : '' ?></p>
<?php if ($k['status'] === 'dijadwalkan'): ?>
<form method="post" class="inline">
  <input type="hidden" name="aksi" value="ubah_lembaga"><input type="hidden" name="id_keputusan" value="<?= (int)$k['id_keputusan'] ?>">
  <div><label>Tanggal</label><input type="date" name="tanggal" value="<?= h($k['tanggal']) ?>" required></div>
  <div><label>Jam</label><input name="jam" value="<?= h(substr($k['jam'], 0, 5)) ?>" required></div>
  <div><label>Lokasi</label><input name="lokasi" value="<?= h($k['lokasi']) ?>" required></div>
  <button>Ubah jadwal</button>
</form>
<form method="post" class="inline">
  <input type="hidden" name="aksi" value="lembaga"><input type="hidden" name="id" value="<?= $idp ?>"><input type="hidden" name="lembaga" value="<?= h($k['lembaga']) ?>">
  <div><label>Putusan</label><select name="putusan"><option value="disetujui">Disetujui</option><option value="ditolak">Ditolak</option></select></div>
  <div><label>Catatan</label><input name="catatan" maxlength="255"></div>
  <button>Simpan putusan</button>
</form>
<?php endif; endforeach; ?>
</div>
<?php endforeach; ?>
<?php if (!$rows): ?><div class="card">Belum ada pendaftar jalur khusus yang administrasinya disetujui.</div><?php endif; ?>
<?php require 'partials/bawah.php'; ?>