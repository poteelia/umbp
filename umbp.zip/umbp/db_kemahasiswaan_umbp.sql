-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2026 at 08:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kemahasiswaan_umbp`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `id_absen` int(11) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `id_matkul` int(11) NOT NULL,
  `id_semester` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `status_hadir` varchar(10) NOT NULL
) ;

--
-- Dumping data for table `absensi`
--

INSERT INTO `absensi` (`id_absen`, `nim`, `id_matkul`, `id_semester`, `tanggal`, `status_hadir`) VALUES
(2, '2601001', 3, 2, '2026-11-25', 'hadir');

-- --------------------------------------------------------

--
-- Table structure for table `beasiswa`
--

CREATE TABLE `beasiswa` (
  `id_beasiswa` int(11) NOT NULL,
  `id_jalur` int(11) NOT NULL,
  `nama_beasiswa` varchar(100) NOT NULL,
  `sumber_dana` varchar(30) NOT NULL,
  `is_kip` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beasiswa`
--

INSERT INTO `beasiswa` (`id_beasiswa`, `id_jalur`, `nama_beasiswa`, `sumber_dana`, `is_kip`) VALUES
(1, 4, 'Bidikmisi/KIP Kuliah', 'LDIKTI', 1),
(2, 3, 'Bidikmisi/KIP Kuliah Aspirasi', 'Aspirasi', 1),
(3, 4, 'Peningkatan Prestasi Akademik (PPA)', 'LDIKTI', 0),
(4, 3, 'Peningkatan Prestasi Akademik (PPA Aspirasi)', 'Aspirasi', 0),
(5, 2, 'Beasiswa Yayasan', 'Yayasan', 0);

-- --------------------------------------------------------

--
-- Table structure for table `berkas_pendaftaran`
--

CREATE TABLE `berkas_pendaftaran` (
  `id_berkas` int(11) NOT NULL,
  `id_pendaftaran` int(11) NOT NULL,
  `jenis_berkas` varchar(30) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `status_verifikasi` varchar(15) NOT NULL DEFAULT 'menunggu'
) ;

--
-- Dumping data for table `berkas_pendaftaran`
--

INSERT INTO `berkas_pendaftaran` (`id_berkas`, `id_pendaftaran`, `jenis_berkas`, `file_path`, `status_verifikasi`) VALUES
(6, 9, 'FOTO', 'uploads/berkas_1e6f98a0eb294e22.jpg', 'valid'),
(7, 9, 'IJAZAH', 'uploads/berkas_b19e8904fb10277c.jpg', 'valid'),
(8, 9, 'KK', 'uploads/berkas_9c5416a21b01f5af.jpg', 'valid'),
(9, 9, 'SKTM', 'uploads/berkas_3b11ccb19c64097a.jpg', 'valid'),
(10, 9, 'SLIP_GAJI', 'uploads/berkas_7395feff748d9fbb.jpg', 'valid'),
(11, 9, 'SURAT_REKOM', 'uploads/berkas_0901d6af10a617aa.jpg', 'valid'),
(12, 10, 'FOTO', 'uploads/berkas_d6688a92e5338fb1.jpg', 'valid'),
(13, 10, 'IJAZAH', 'uploads/berkas_1e96491e888b6f76.jpg', 'valid'),
(14, 10, 'KK', 'uploads/berkas_e476b2de8ddd2044.jpg', 'valid'),
(15, 10, 'SKTM', 'uploads/berkas_b8cb2bac8aff6390.jpg', 'valid'),
(16, 10, 'SLIP_GAJI', 'uploads/berkas_baf6889b36252c3a.jpg', 'valid'),
(17, 10, 'SURAT_REKOM', 'uploads/berkas_d19c7625650718c7.jpg', 'valid');

-- --------------------------------------------------------

--
-- Table structure for table `calon_mahasiswa`
--

CREATE TABLE `calon_mahasiswa` (
  `id_calon` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` char(1) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `asal_sekolah` varchar(100) NOT NULL,
  `tahun_lulus` year(4) NOT NULL
) ;

--
-- Dumping data for table `calon_mahasiswa`
--

INSERT INTO `calon_mahasiswa` (`id_calon`, `nama`, `jenis_kelamin`, `email`, `no_hp`, `asal_sekolah`, `tahun_lulus`) VALUES
(1, 'Mahasiswa Contoh A', 'P', 'a@contoh.test', '081200000001', 'SMA Contoh 1', '2024'),
(2, 'Mahasiswa Contoh B', 'L', 'b@contoh.test', '081200000002', 'SMA Contoh 1', '2024'),
(3, 'Mahasiswa Contoh C', 'P', 'c@contoh.test', '081200000003', 'SMA Contoh 2', '2024'),
(4, 'Mahasiswa Contoh D', 'L', 'd@contoh.test', '081200000004', 'SMA Contoh 2', '2024'),
(5, 'Mahasiswa Contoh E', 'P', 'e@contoh.test', '081200000005', 'SMA Contoh 3', '2024'),
(14, 'AIREN KEIN', 'P', 'airensitepu12@gmail.com', '089767251423', 'sultan iskanadar muda', '2024'),
(15, 'Vera Dina Sari', 'L', 'verasihombing@gmail.com', '082156567567', 'SMAS SUTOMO', '2024'),
(16, 'sofy', 'L', 'sofyindah7@gmail.com', '0831-8748-1328', 'smkn', '2026');

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `id_dosen` int(11) NOT NULL,
  `id_prodi` int(11) DEFAULT NULL,
  `nama` varchar(150) NOT NULL,
  `nidn` varchar(15) DEFAULT NULL,
  `jabatan` varchar(50) NOT NULL DEFAULT 'Dosen',
  `email` varchar(100) DEFAULT NULL,
  `kaprodi_key` int(11) GENERATED ALWAYS AS (case when `jabatan` = 'Ka. Prodi' then `id_prodi` else NULL end) STORED
) ;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`id_dosen`, `id_prodi`, `nama`, `nidn`, `jabatan`, `email`) VALUES
(1, 1, 'Anjar Pinem, M.Kom.', NULL, 'Ka. Prodi', NULL),
(2, 2, 'Bersama Sinuraya, M.Kom.', NULL, 'Ka. Prodi', NULL),
(3, 1, 'Tulus Pramita Sihaloho, M.Kom.', NULL, 'Dosen', NULL),
(4, 1, 'Wanra Tarigan, S.T., M.Kom.', NULL, 'Dosen', NULL),
(5, 1, 'Muhammad Lukman Hakim, M.Kom.', NULL, 'Dosen', NULL),
(6, 1, 'Makmur Hasibuan, M.Kom.', NULL, 'Dosen', NULL),
(7, 1, 'Dede Prabowo Wiguna, S.Pd., M.Si.', NULL, 'Dosen', NULL),
(8, 1, 'Jenheri Rejeki Tarigan, S.Pd., M.Hum.', NULL, 'Dosen', NULL),
(9, 2, 'Sariadin Siallagan, S.T., M.Cs.', NULL, 'Dosen', NULL),
(10, 2, 'Beny Irawan, S.T., M.Kom.', NULL, 'Dosen', NULL),
(11, 2, 'Erwin Daniel Sitanggang, S.Kom., M.Kom.', NULL, 'Dosen', NULL),
(12, 2, 'Lismardiana, S.T., M.Kom.', NULL, 'Dosen', NULL),
(13, 3, 'Erni Dewi Munthe, S.Pd., M.Pd.', NULL, 'Ka. Prodi', NULL),
(14, NULL, 'Dr. Afridayanti Surbakti, S.E., M.Si.', NULL, 'Wakil Rektor II', NULL),
(15, 3, 'Veramika Br. Sembiring, S.E., M.M.', NULL, 'Dosen', NULL),
(16, 3, 'Mohamad Yamin, S.E., M.M.', NULL, 'Dosen', NULL),
(17, 3, 'Lennaria L. Tarigan, S.E., M.M.', NULL, 'Dosen', NULL),
(18, 3, 'Mardaus Purba, S.E., M.M.', NULL, 'Dosen', NULL),
(19, 4, 'Dumariani Silalahi, S.E., M.Si.', NULL, 'Ka. Prodi', NULL),
(20, 4, 'Mery Sulianty H. Sitanggang, S.E., M.M.', NULL, 'Dosen', NULL),
(21, 4, 'Duma Lasmaria Siagian, S.E., M.M.', NULL, 'Dosen', NULL),
(22, 4, 'Veronika Saragih, S.E., M.M.', NULL, 'Dosen', NULL),
(23, 4, 'Berlin Barus, S.E., S.Kom., M.Si.', NULL, 'Dosen', NULL),
(24, 5, 'Pilipus Tarigan, S.T., M.Kom.', NULL, 'Ka. Prodi', NULL),
(25, 5, 'Sakaria Efrata Ginting, M.Kom.', NULL, 'Dosen', NULL),
(26, 5, 'Jimmy Peranginangin, M.Kom.', NULL, 'Dosen', NULL),
(27, 5, 'Ratna Wati Simbolon, M.Kom.', NULL, 'Dosen', NULL),
(28, 6, 'Meri N. M. Br Sipahutar, M.Kom.', NULL, 'Ka. Prodi', NULL),
(29, 6, 'Siti Jamilah Br. Tarigan, S.E., M.Si.', NULL, 'Dosen', NULL),
(30, 6, 'Ita Margaretta Br. Tarigan, S.E., M.Si.', NULL, 'Dosen', NULL),
(31, 7, 'Iswanto Sembiring, S.T., M.Pd.', NULL, 'Ka. Prodi', NULL),
(32, 7, 'Maradu Sihombing, S.T., M.Kom.', NULL, 'Dosen', NULL),
(33, 7, 'Misdem Sembiring, S.T., M.Kom.', NULL, 'Dosen', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gelombang`
--

CREATE TABLE `gelombang` (
  `id_gelombang` int(11) NOT NULL,
  `nama_gelombang` varchar(20) NOT NULL,
  `tgl_buka` date NOT NULL,
  `tgl_tutup` date NOT NULL,
  `kuota` int(11) NOT NULL DEFAULT 300
) ;

--
-- Dumping data for table `gelombang`
--

INSERT INTO `gelombang` (`id_gelombang`, `nama_gelombang`, `tgl_buka`, `tgl_tutup`, `kuota`) VALUES
(1, 'Gelombang I', '2026-02-15', '2026-04-30', 300),
(2, 'Gelombang II', '2026-05-01', '2026-07-30', 300),
(3, 'Gelombang III', '2026-08-01', '2026-09-30', 300);

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_seleksi`
--

CREATE TABLE `jadwal_seleksi` (
  `id_jadwal` int(11) NOT NULL,
  `id_pendaftaran` int(11) NOT NULL,
  `jenis` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `lokasi` varchar(100) NOT NULL,
  `catatan` varchar(200) DEFAULT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'dijadwalkan'
) ;

--
-- Dumping data for table `jadwal_seleksi`
--

INSERT INTO `jadwal_seleksi` (`id_jadwal`, `id_pendaftaran`, `jenis`, `tanggal`, `jam`, `lokasi`, `catatan`, `status`) VALUES
(13, 9, 'wawancara', '2026-11-27', '09:00:00', 'Kampus UMBP', NULL, 'selesai'),
(14, 10, 'wawancara', '2026-11-30', '09:00:00', 'Kampus UMBP', NULL, 'selesai');

-- --------------------------------------------------------

--
-- Table structure for table `jalur_berkas`
--

CREATE TABLE `jalur_berkas` (
  `id_jalur` int(11) NOT NULL,
  `jenis_berkas` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jalur_berkas`
--

INSERT INTO `jalur_berkas` (`id_jalur`, `jenis_berkas`) VALUES
(1, 'FOTO'),
(1, 'IJAZAH'),
(1, 'KK'),
(1, 'SKHU'),
(2, 'BUKTI_KIP'),
(2, 'FOTO'),
(2, 'IJAZAH'),
(2, 'KK'),
(2, 'SKTM'),
(2, 'SLIP_GAJI'),
(3, 'FOTO'),
(3, 'IJAZAH'),
(3, 'KK'),
(3, 'SKTM'),
(3, 'SLIP_GAJI'),
(3, 'SURAT_REKOM'),
(4, 'FOTO'),
(4, 'IJAZAH'),
(4, 'KK'),
(4, 'SKTM'),
(4, 'SLIP_GAJI'),
(4, 'SURAT_REKOM'),
(5, 'FOTO'),
(5, 'IJAZAH'),
(5, 'KK'),
(5, 'PRESTASI');

-- --------------------------------------------------------

--
-- Table structure for table `jalur_pendaftaran`
--

CREATE TABLE `jalur_pendaftaran` (
  `id_jalur` int(11) NOT NULL,
  `nama_jalur` varchar(50) NOT NULL,
  `pakai_gelombang` tinyint(1) NOT NULL DEFAULT 0,
  `alur` enum('reguler','khusus') NOT NULL DEFAULT 'reguler',
  `bayar_pendaftaran` tinyint(1) NOT NULL DEFAULT 1,
  `perlu_lldikti` tinyint(1) NOT NULL DEFAULT 0,
  `perlu_yayasan` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jalur_pendaftaran`
--

INSERT INTO `jalur_pendaftaran` (`id_jalur`, `nama_jalur`, `pakai_gelombang`, `alur`, `bayar_pendaftaran`, `perlu_lldikti`, `perlu_yayasan`) VALUES
(1, 'Reguler (Sistem Gelombang)', 1, 'reguler', 1, 0, 0),
(2, 'Beasiswa Yayasan', 0, 'khusus', 1, 0, 1),
(3, 'Beasiswa Aspirasi', 0, 'khusus', 1, 0, 1),
(4, 'Beasiswa LDIKTI', 0, 'khusus', 1, 0, 1),
(5, 'Prestasi', 0, 'khusus', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `kategori_organisasi`
--

CREATE TABLE `kategori_organisasi` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kategori_organisasi`
--

INSERT INTO `kategori_organisasi` (`id_kategori`, `nama_kategori`) VALUES
(7, 'Akademik'),
(2, 'Keagamaan'),
(3, 'Kedaerahan'),
(1, 'Lembaga Eksekutif'),
(4, 'Minat dan Bakat'),
(5, 'Olahraga'),
(8, 'Seni dan Budaya'),
(6, 'Sosial');

-- --------------------------------------------------------

--
-- Table structure for table `keanggotaan`
--

CREATE TABLE `keanggotaan` (
  `id_anggota` int(11) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `id_org` int(11) NOT NULL,
  `jabatan` varchar(50) NOT NULL DEFAULT 'Anggota',
  `periode` varchar(9) NOT NULL,
  `tgl_masuk` date DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'aktif'
) ;

--
-- Dumping data for table `keanggotaan`
--

INSERT INTO `keanggotaan` (`id_anggota`, `nim`, `id_org`, `jabatan`, `periode`, `tgl_masuk`, `status`) VALUES
(1, '2601001', 4, 'Anggota', 'Anggota', NULL, 'aktif');

-- --------------------------------------------------------

--
-- Table structure for table `kegiatan`
--

CREATE TABLE `kegiatan` (
  `id_kegiatan` int(11) NOT NULL,
  `id_org` int(11) NOT NULL,
  `nama_kegiatan` varchar(150) NOT NULL,
  `tanggal` date NOT NULL,
  `lokasi` varchar(100) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `keputusan_lembaga`
--

CREATE TABLE `keputusan_lembaga` (
  `id_keputusan` int(11) NOT NULL,
  `id_pendaftaran` int(11) NOT NULL,
  `lembaga` enum('lldikti','yayasan') NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL DEFAULT '09:00:00',
  `lokasi` varchar(100) NOT NULL,
  `status` enum('dijadwalkan','disetujui','ditolak') NOT NULL DEFAULT 'dijadwalkan',
  `catatan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `keputusan_lembaga`
--

INSERT INTO `keputusan_lembaga` (`id_keputusan`, `id_pendaftaran`, `lembaga`, `tanggal`, `jam`, `lokasi`, `status`, `catatan`) VALUES
(1, 9, 'yayasan', '2026-12-04', '09:00:00', 'Sekretariat Yayasan', 'disetujui', NULL),
(2, 10, 'yayasan', '2026-12-07', '09:00:00', 'Sekretariat Yayasan', 'disetujui', 'LULUS');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` varchar(10) NOT NULL,
  `id_calon` int(11) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tahun_masuk` year(4) NOT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'aktif',
  `angkatan` smallint(6) DEFAULT NULL,
  `status_akademik` enum('aktif','lulus','nonaktif') NOT NULL DEFAULT 'aktif',
  `tgl_lulus` date DEFAULT NULL
) ;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `id_calon`, `id_prodi`, `nama`, `tahun_masuk`, `status`, `angkatan`, `status_akademik`, `tgl_lulus`) VALUES
('2601001', 14, 1, 'AIREN KEIN', '2026', 'aktif', 2026, 'aktif', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa_terbaik`
--

CREATE TABLE `mahasiswa_terbaik` (
  `id_terbaik` int(11) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `id_semester` int(11) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `peringkat` tinyint(4) NOT NULL,
  `ipk` decimal(3,2) NOT NULL,
  `persen_hadir` decimal(5,2) NOT NULL,
  `tgl_ditetapkan` date NOT NULL
) ;

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa_terbaik_angkatan`
--

CREATE TABLE `mahasiswa_terbaik_angkatan` (
  `id` int(11) NOT NULL,
  `angkatan` smallint(6) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `nim` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `peringkat` tinyint(4) NOT NULL DEFAULT 1,
  `ipk` decimal(3,2) NOT NULL,
  `persen_hadir` decimal(5,2) DEFAULT NULL,
  `tgl_ditetapkan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mata_kuliah`
--

CREATE TABLE `mata_kuliah` (
  `id_matkul` int(11) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `kode_mk` varchar(10) NOT NULL,
  `nama_mk` varchar(100) NOT NULL,
  `sks` tinyint(4) NOT NULL,
  `semester_ke` tinyint(4) DEFAULT NULL
) ;

--
-- Dumping data for table `mata_kuliah`
--

INSERT INTO `mata_kuliah` (`id_matkul`, `id_prodi`, `kode_mk`, `nama_mk`, `sks`, `semester_ke`) VALUES
(1, 1, 'SI-BD1', 'Basis Data', 3, NULL),
(2, 2, 'TI-BD1', 'Basis Data', 3, NULL),
(3, 1, 'SI-1-01', 'Pengantar Akuntansi', 3, 1),
(4, 1, 'SI-1-02', 'Konsep Pemrograman', 3, 1),
(5, 1, 'SI-1-03', 'Matematika Komputer', 3, 1),
(6, 1, 'SI-1-04', 'Pengantar Teknologi Informasi', 3, 1),
(7, 1, 'SI-1-05', 'Internet dan Perancangan Web', 3, 1),
(8, 1, 'SI-1-06', 'Agama', 3, 1),
(9, 1, 'SI-1-07', 'Bahasa Inggris I', 3, 1),
(10, 1, 'SI-2-01', 'Sistem Operasi', 3, 2),
(11, 1, 'SI-2-02', 'Program Aplikasi Akuntansi', 3, 2),
(12, 1, 'SI-2-03', 'Algoritma dan Struktur Data', 3, 2),
(13, 1, 'SI-2-04', 'Basis Data I', 3, 2),
(14, 1, 'SI-2-05', 'Bahasa Inggris II', 3, 2),
(15, 1, 'SI-2-06', 'Pendidikan Pancasila dan Kewarganegaraan', 3, 2),
(16, 1, 'SI-3-01', 'Analisa dan Perancangan Sistem Informasi', 3, 3),
(17, 1, 'SI-3-02', 'Pemrograman Visual I', 3, 3),
(18, 1, 'SI-3-03', 'Pemrograman Web I', 3, 3),
(19, 1, 'SI-3-04', 'Basis Data II', 3, 3),
(20, 1, 'SI-3-05', 'Bahasa Inggris III', 3, 3),
(21, 1, 'SI-3-06', 'Statistika', 3, 3),
(22, 1, 'SI-4-01', 'Sistem Informasi Manajemen', 3, 4),
(23, 1, 'SI-4-02', 'Jaringan Komputer dan Komunikasi Data', 3, 4),
(24, 1, 'SI-4-03', 'Pemrograman Visual II', 3, 4),
(25, 1, 'SI-4-04', 'Pemrograman Web II', 3, 4),
(26, 1, 'SI-4-05', 'Basis Data III', 3, 4),
(27, 1, 'SI-4-06', 'Etika Profesi', 3, 4),
(28, 1, 'SI-5-01', 'Manajemen Proyek Sistem Informasi', 3, 5),
(29, 1, 'SI-5-02', 'Interaksi Manusia dan Komputer', 3, 5),
(30, 1, 'SI-5-03', 'Pemrograman Visual III', 3, 5),
(31, 1, 'SI-5-04', 'Pemrograman Web III', 3, 5),
(32, 1, 'SI-5-05', 'Kewirausahaan dan Manajemen Bisnis', 3, 5),
(33, 1, 'SI-5-06', 'Bahasa Indonesia', 3, 5),
(34, 1, 'SI-5-07', 'Metodologi Penelitian', 3, 5),
(35, 1, 'SI-6-01', 'Kapita Selekta I', 3, 6),
(36, 1, 'SI-6-02', 'Desain dan Penerapan Basisdata', 3, 6),
(37, 1, 'SI-6-03', 'Sistem Informasi Eksekutif', 3, 6),
(38, 1, 'SI-6-04', 'Pemrograman Visual IV', 3, 6),
(39, 1, 'SI-6-05', 'Manajemen Umum', 3, 6),
(40, 1, 'SI-7-01', 'Kapita Selekta II', 3, 7),
(41, 1, 'SI-7-02', 'Desain dan Penerapan Pemrograman', 3, 7),
(42, 1, 'SI-7-03', 'Tata Kelola Teknologi Informasi', 3, 7),
(43, 1, 'SI-7-04', 'Rekayasa Sistem Informasi', 3, 7),
(44, 1, 'SI-7-05', 'e-Bisnis', 3, 7),
(66, 2, 'TI-1-01', 'Fisika Elektronika', 3, 1),
(67, 2, 'TI-1-02', 'Konsep Pemrograman', 3, 1),
(68, 2, 'TI-1-03', 'Matematika Komputer', 3, 1),
(69, 2, 'TI-1-04', 'Pengantar Teknologi Informasi', 3, 1),
(70, 2, 'TI-1-05', 'Internet dan Perancangan Web', 3, 1),
(71, 2, 'TI-1-06', 'Agama', 3, 1),
(72, 2, 'TI-1-07', 'Bahasa Inggris I', 3, 1),
(73, 2, 'TI-2-01', 'Sistem Operasi', 3, 2),
(74, 2, 'TI-2-02', 'Matematika Diskrit', 3, 2),
(75, 2, 'TI-2-03', 'Algoritma dan Struktur Data', 3, 2),
(76, 2, 'TI-2-04', 'Basisdata I', 3, 2),
(77, 2, 'TI-2-05', 'Bahasa Inggris II', 3, 2),
(78, 2, 'TI-2-06', 'Pendidikan Pancasila dan Kewarganegaraan', 3, 2),
(79, 2, 'TI-3-01', 'Analisa dan Perancangan Sistem Informasi', 3, 3),
(80, 2, 'TI-3-02', 'Pemrograman Visual I', 3, 3),
(81, 2, 'TI-3-03', 'Desain dan Analisis Algoritma', 3, 3),
(82, 2, 'TI-3-04', 'Basisdata II', 3, 3),
(83, 2, 'TI-3-05', 'Bahasa Inggris III', 3, 3),
(84, 2, 'TI-3-06', 'Statistika', 3, 3),
(85, 2, 'TI-4-01', 'Sistem Informasi Manajemen', 3, 4),
(86, 2, 'TI-4-02', 'Jaringan Komputer dan Komunikasi Data', 3, 4),
(87, 2, 'TI-4-03', 'Pemrograman Visual II', 3, 4),
(88, 2, 'TI-4-04', 'Pemrograman Web', 3, 4),
(89, 2, 'TI-4-05', 'Kecerdasan Buatan', 3, 4),
(90, 2, 'TI-4-06', 'Etika Profesi', 3, 4),
(91, 2, 'TI-5-01', 'Pemrograman Berorientasi Objek', 3, 5),
(92, 2, 'TI-5-02', 'Interaksi Manusia dan Komputer', 3, 5),
(93, 2, 'TI-5-03', 'Kewirausahaan dan Manajemen Bisnis', 3, 5),
(94, 2, 'TI-5-04', 'Desain dan Penerapan Jaringan Komputer', 3, 5),
(95, 2, 'TI-5-05', 'Sistem Pakar', 3, 5),
(96, 2, 'TI-5-06', 'Bahasa Indonesia', 3, 5),
(97, 2, 'TI-5-07', 'Metodologi Penelitian', 3, 5),
(98, 2, 'TI-6-01', 'Kapita Selekta I', 3, 6),
(99, 2, 'TI-6-02', 'Pemrograman Multimedia', 3, 6),
(100, 2, 'TI-6-03', 'Keamanan Jaringan', 3, 6),
(101, 2, 'TI-6-04', 'Logika Samar', 3, 6),
(102, 2, 'TI-6-05', 'Teori Bahasa dan Automata', 3, 6),
(103, 2, 'TI-7-01', 'Kapita Selekta II', 3, 7),
(104, 2, 'TI-7-02', 'Desain dan Penerapan Sistem Pakar', 3, 7),
(105, 2, 'TI-7-03', 'Tata Kelola Jaringan Komputer', 3, 7),
(106, 2, 'TI-7-04', 'Rekayasa Perangkat Lunak', 3, 7),
(107, 2, 'TI-7-05', 'Teknik Kompilasi', 3, 7),
(108, 2, 'TI-7-06', 'e-Bisnis', 3, 7),
(129, 5, 'RPL-1-01', 'Pendidikan Agama', 3, 1),
(130, 5, 'RPL-1-02', 'Matematika Dasar', 3, 1),
(131, 5, 'RPL-1-03', 'Bahasa Inggris I', 3, 1),
(132, 5, 'RPL-1-04', 'Pengantar Teknologi Informasi', 3, 1),
(133, 5, 'RPL-1-05', 'Algoritma dan Pemrograman', 3, 1),
(134, 5, 'RPL-1-06', 'Pemikiran Desain dan Kreativitas', 3, 1),
(135, 5, 'RPL-1-07', 'Statistika', 3, 1),
(136, 5, 'RPL-1-08', 'Pengantar Rekayasa Perangkat Lunak', 3, 1),
(137, 5, 'RPL-2-01', 'Pancasila dan Kewarganegaraan', 3, 2),
(138, 5, 'RPL-2-02', 'Matematika Diskrit', 3, 2),
(139, 5, 'RPL-2-03', 'Arsitektur dan Organisasi Komputer', 3, 2),
(140, 5, 'RPL-2-04', 'Bahasa Inggris II', 3, 2),
(141, 5, 'RPL-2-05', 'Pemrograman dan Struktur Data', 3, 2),
(142, 5, 'RPL-2-06', 'Basis Data', 3, 2),
(143, 5, 'RPL-2-07', 'Model dan Metode Rekayasa Perangkat Lunak', 3, 2),
(144, 5, 'RPL-3-01', 'Sistem Operasi', 3, 3),
(145, 5, 'RPL-3-02', 'Jaringan Komputer', 3, 3),
(146, 5, 'RPL-3-03', 'Rekayasa Kebutuhan Perangkat Lunak', 3, 3),
(147, 5, 'RPL-3-04', 'Kecakapan Antar Personal', 3, 3),
(148, 5, 'RPL-3-05', 'Desain dan Analisis Algoritma', 3, 3),
(149, 5, 'RPL-3-06', 'Pemrograman Berorientasi Objek I', 3, 3),
(150, 5, 'RPL-3-07', 'Kecerdasan Buatan', 3, 3),
(151, 5, 'RPL-3-08', 'Bahasa Indonesia', 3, 3),
(152, 5, 'RPL-4-01', 'Interaksi Manusia dan Komputer', 3, 4),
(153, 5, 'RPL-4-02', 'Desain dan Arsitektur Perangkat Lunak', 3, 4),
(154, 5, 'RPL-4-03', 'Basis Data Lanjut', 3, 4),
(155, 5, 'RPL-4-04', 'Analisis dan Perancangan Sistem', 3, 4),
(156, 5, 'RPL-4-05', 'Kecerdasan Komputasional', 3, 4),
(157, 5, 'RPL-4-06', 'Technopreneurship', 3, 4),
(158, 5, 'RPL-4-07', 'Keamanan Pengembangan Perangkat Lunak', 3, 4),
(159, 5, 'RPL-5-01', 'Etika Profesi', 3, 5),
(160, 5, 'RPL-5-02', 'Penjaminan Mutu Perangkat Lunak', 3, 5),
(161, 5, 'RPL-5-03', 'Desain dan Pemrograman Web', 3, 5),
(162, 5, 'RPL-5-04', 'Konstruksi dan Pemeliharaan Perangkat Lunak', 3, 5),
(163, 5, 'RPL-5-05', 'Pemrograman Berorientasi Objek II', 3, 5),
(164, 5, 'RPL-5-06', 'Pengujian Perangkat Lunak', 3, 5),
(165, 5, 'RPL-5-07', 'Konsep Verifikasi dan Validasi Perangkat Lunak', 3, 5),
(166, 5, 'RPL-6-01', 'Manajemen Proyek Perangkat Lunak', 3, 6),
(167, 5, 'RPL-6-02', 'Metodologi Penelitian', 3, 6),
(168, 5, 'RPL-6-03', 'Testing dan Implementasi Sistem', 3, 6),
(169, 5, 'RPL-6-04', 'E-Bisnis', 3, 6),
(170, 5, 'RPL-6-05', 'Pemrograman Perangkat Bergerak', 3, 6),
(171, 5, 'RPL-6-06', 'Kapita Selekta I', 3, 6),
(172, 5, 'RPL-6-07', 'Manajemen Proses Bisnis', 3, 6),
(173, 5, 'RPL-7-01', 'Grafika Komputer', 3, 7),
(174, 5, 'RPL-7-02', 'Proyek Pengembangan Perangkat Lunak', 3, 7),
(175, 5, 'RPL-7-03', 'Kapita Selekta II', 3, 7),
(176, 5, 'RPL-7-04', 'Sistem Pendukung Keputusan', 3, 7),
(177, 5, 'RPL-7-05', 'Analisis Data', 3, 7),
(178, 5, 'RPL-7-06', 'Manajemen Risiko dan Kualitas Perangkat Lunak', 3, 7),
(192, 4, 'AK-1-01', 'Pengantar Akuntansi', 3, 1),
(193, 4, 'AK-1-02', 'Perpajakan', 3, 1),
(194, 4, 'AK-1-03', 'Pengantar Ilmu Ekonomi', 3, 1),
(195, 4, 'AK-1-04', 'Pengantar Manajemen', 3, 1),
(196, 4, 'AK-1-05', 'Matematika Ekonomi', 3, 1),
(197, 4, 'AK-1-06', 'Bahasa Inggris I', 3, 1),
(198, 4, 'AK-1-07', 'Pancasila & Kewarganegaraan', 3, 1),
(199, 4, 'AK-1-08', 'Agama', 3, 1),
(200, 4, 'AK-2-01', 'Akuntansi Keuangan Menengah I', 3, 2),
(201, 4, 'AK-2-02', 'Akuntansi Perpajakan', 3, 2),
(202, 4, 'AK-2-03', 'Program Aplikasi Akuntansi I', 3, 2),
(203, 4, 'AK-2-04', 'Akuntansi Biaya I', 3, 2),
(204, 4, 'AK-2-05', 'Manajemen Pemasaran', 3, 2),
(205, 4, 'AK-2-06', 'Ekonomi Mikro', 3, 2),
(206, 4, 'AK-2-07', 'Bahasa Inggris II', 3, 2),
(207, 4, 'AK-3-01', 'Akuntansi Keuangan Menengah II', 3, 3),
(208, 4, 'AK-3-02', 'Akuntansi Biaya II', 3, 3),
(209, 4, 'AK-3-03', 'Akuntansi Anggaran I', 3, 3),
(210, 4, 'AK-3-04', 'Program Aplikasi Akuntansi II', 3, 3),
(211, 4, 'AK-3-05', 'Program Aplikasi Perpajakan', 3, 3),
(212, 4, 'AK-3-06', 'Ekonomi Makro', 3, 3),
(213, 4, 'AK-3-07', 'Bahasa Indonesia', 3, 3),
(214, 4, 'AK-4-01', 'Akuntansi Keuangan Lanjutan I', 3, 4),
(215, 4, 'AK-4-02', 'Akuntansi Pemeriksaan I', 3, 4),
(216, 4, 'AK-4-03', 'Akuntansi Anggaran II', 3, 4),
(217, 4, 'AK-4-04', 'Program Aplikasi Akuntansi III', 3, 4),
(218, 4, 'AK-4-05', 'Sistem Informasi Akuntansi', 3, 4),
(219, 4, 'AK-4-06', 'Statistika', 3, 4),
(220, 4, 'AK-4-07', 'Etika Bisnis & Profesi', 3, 4),
(221, 4, 'AK-5-01', 'Akuntansi Keuangan Lanjutan II', 3, 5),
(222, 4, 'AK-5-02', 'Akuntansi Pemeriksaan II', 3, 5),
(223, 4, 'AK-5-03', 'Teori Akuntansi', 3, 5),
(224, 4, 'AK-5-04', 'Metodologi Penelitian Akuntansi', 3, 5),
(225, 4, 'AK-5-05', 'Akuntansi Manajemen', 3, 5),
(226, 4, 'AK-5-06', 'Sistem Informasi Manajemen', 3, 5),
(227, 4, 'AK-5-07', 'Akuntansi Sektor Publik', 3, 5),
(228, 4, 'AK-6-01', 'Akuntansi Pemeriksaan III', 3, 6),
(229, 4, 'AK-6-02', 'Analisis Laporan Keuangan', 3, 6),
(230, 4, 'AK-6-03', 'Bank dan Lembaga Keuangan', 3, 6),
(231, 4, 'AK-6-04', 'Manajemen Investasi dan Pasar Modal', 3, 6),
(232, 4, 'AK-6-05', 'Akuntansi Internasional', 3, 6),
(233, 4, 'AK-6-06', 'Studi Kelayakan Bisnis', 3, 6),
(234, 4, 'AK-7-01', 'Akuntansi Pemerintahan', 3, 7),
(235, 4, 'AK-7-02', 'Sistem Pengendalian Manajemen', 3, 7),
(236, 4, 'AK-7-03', 'Hukum Bisnis', 3, 7),
(237, 4, 'AK-7-04', 'Anti Korupsi', 3, 7),
(238, 4, 'AK-7-05', 'Kewirausahaan', 3, 7),
(255, 3, 'KW-1-01', 'Agama', 3, 1),
(256, 3, 'KW-1-02', 'Pancasila dan Kewarganegaraan', 3, 1),
(257, 3, 'KW-1-03', 'Pengantar Bisnis dan Kewirausahaan', 3, 1),
(258, 3, 'KW-1-04', 'Pengantar Manajemen', 3, 1),
(259, 3, 'KW-1-05', 'Akuntansi Dasar Ekonomi Bisnis', 3, 1),
(260, 3, 'KW-1-06', 'Pengantar Teknologi Informasi', 3, 1),
(261, 3, 'KW-1-07', 'Pengantar Bahasa Inggris/Inggris Bisnis', 3, 1),
(262, 3, 'KW-2-01', 'Sistem Informasi Manajemen', 3, 2),
(263, 3, 'KW-2-02', 'Perencanaan dan Kelayakan Bisnis', 3, 2),
(264, 3, 'KW-2-03', 'Matematika Bisnis', 3, 2),
(265, 3, 'KW-2-04', 'Manajemen Pemasaran Bisnis', 3, 2),
(266, 3, 'KW-2-05', 'Pengantar Ekonomi dan Perbankan', 3, 2),
(267, 3, 'KW-2-06', 'Bahasa Indonesia: Penulisan Ilmiah', 3, 2),
(268, 3, 'KW-2-07', 'Rekayasa dan Rancangan Produk 1', 3, 2),
(269, 3, 'KW-2-08', 'Etika Bisnis', 3, 2),
(270, 3, 'KW-3-01', 'Rekayasa dan Rancangan Produk 2', 3, 3),
(271, 3, 'KW-3-02', 'Akuntansi Biaya', 3, 3),
(272, 3, 'KW-3-03', 'Manajemen Organisasi dan Sumber Daya Manusia', 3, 3),
(273, 3, 'KW-3-04', 'Analisis Risiko Bisnis Statistik Multivariat', 3, 3),
(274, 3, 'KW-3-05', 'Manajemen Keuangan Bisnis', 3, 3),
(275, 3, 'KW-3-06', 'Statistika Bisnis', 3, 3),
(276, 3, 'KW-3-07', 'Design Thinking Inovasi', 3, 3),
(277, 3, 'KW-4-01', 'Anti Korupsi', 3, 4),
(278, 3, 'KW-4-02', 'Bisnis Berbasis Teknologi', 3, 4),
(279, 3, 'KW-4-03', 'Perpajakan', 3, 4),
(280, 3, 'KW-4-04', 'Studi Kelayakan Bisnis', 3, 4),
(281, 3, 'KW-4-05', 'Akuntansi Manajemen', 3, 4),
(282, 3, 'KW-4-06', 'Manajemen Lingkungan Bisnis', 3, 4),
(283, 3, 'KW-4-07', 'Usaha Kecil dan Mikro', 3, 4),
(284, 3, 'KW-4-08', 'Hukum Bisnis dan Kontrak Bisnis', 3, 4),
(285, 3, 'KW-5-01', 'Analisis Investasi dan Modal', 3, 5),
(286, 3, 'KW-5-02', 'Bisnis Internasional', 3, 5),
(287, 3, 'KW-5-03', 'Kepemimpinan dan Praktik Manajemen', 3, 5),
(288, 3, 'KW-5-04', 'Mentoring Kewirausahaan 1', 3, 5),
(289, 3, 'KW-5-05', 'Manajemen Rantai Nilai (Chain) Manajemen', 3, 5),
(290, 3, 'KW-5-06', 'Metode Penelitian Bisnis', 3, 5),
(291, 3, 'KW-5-07', 'Komunikasi dan Negosiasi Bisnis', 3, 5),
(292, 3, 'KW-6-01', 'Mentoring Kewirausahaan 2', 3, 6),
(293, 3, 'KW-6-02', 'Manajemen Strategi', 3, 6),
(294, 3, 'KW-6-03', 'Seminar Kewirausahaan', 3, 6),
(295, 3, 'KW-6-04', 'Manajemen Pengembangan Produk', 3, 6),
(296, 3, 'KW-6-05', 'E\'Commerce', 3, 6),
(297, 3, 'KW-6-06', 'Perencanaan Proyek Digital', 3, 6),
(298, 3, 'KW-6-07', 'Manajemen Merek', 3, 6),
(299, 3, 'KW-7-01', 'Teknologi dan Analisa Bisnis', 3, 7),
(300, 3, 'KW-7-02', 'Dinamika Bisnis', 3, 7),
(301, 3, 'KW-7-03', 'Seminar Proposal Penelitian', 3, 7),
(302, 3, 'KW-7-04', 'Mentoring Kewirausahaan 3', 3, 7),
(318, 7, 'D3TI-1-01', 'Pancasila dan Kewarganegaraan', 3, 1),
(319, 7, 'D3TI-1-02', 'Bahasa Inggris I', 3, 1),
(320, 7, 'D3TI-1-03', 'Matematika Dasar', 3, 1),
(321, 7, 'D3TI-1-04', 'Pengantar Teknologi Informasi', 3, 1),
(322, 7, 'D3TI-1-05', 'Sistem Digital', 3, 1),
(323, 7, 'D3TI-1-06', 'Algoritma dan Pemrograman', 3, 1),
(324, 7, 'D3TI-1-07', 'Paket Program Aplikasi', 3, 1),
(325, 7, 'D3TI-1-08', 'Bahasa Indonesia', 3, 1),
(326, 7, 'D3TI-1-09', 'Kecakapan Antar Personal', 3, 1),
(327, 7, 'D3TI-2-01', 'Internet dan Perancangan Web', 3, 2),
(328, 7, 'D3TI-2-02', 'Perakitan Komputer', 3, 2),
(329, 7, 'D3TI-2-03', 'Bahasa Inggris II', 3, 2),
(330, 7, 'D3TI-2-04', 'Struktur Data', 3, 2),
(331, 7, 'D3TI-2-05', 'Matematika Diskrit', 3, 2),
(332, 7, 'D3TI-2-06', 'Basis Data I', 3, 2),
(333, 7, 'D3TI-2-07', 'Sistem Operasi', 3, 2),
(334, 7, 'D3TI-3-01', 'Jaringan Komputer I', 3, 3),
(335, 7, 'D3TI-3-02', 'Basis Data II', 3, 3),
(336, 7, 'D3TI-3-03', 'Pemrograman Web I', 3, 3),
(337, 7, 'D3TI-3-04', 'Bahasa Inggris III', 3, 3),
(338, 7, 'D3TI-3-05', 'Statistika', 3, 3),
(339, 7, 'D3TI-3-06', 'Manajemen Sistem Informasi', 3, 3),
(340, 7, 'D3TI-3-07', 'Kewirausahaan', 3, 3),
(341, 7, 'D3TI-4-01', 'Pendidikan Agama', 3, 4),
(342, 7, 'D3TI-4-02', 'Pemrograman Web II', 3, 4),
(343, 7, 'D3TI-4-03', 'Jaringan Komputer II', 3, 4),
(344, 7, 'D3TI-4-04', 'Pemrograman I', 3, 4),
(345, 7, 'D3TI-4-05', 'Multimedia', 3, 4),
(346, 7, 'D3TI-4-06', 'Manajemen Proyek Sistem Informasi', 3, 4),
(347, 7, 'D3TI-4-07', 'Etika Profesi', 3, 4),
(348, 7, 'D3TI-5-01', 'Pemrograman II', 3, 5),
(349, 7, 'D3TI-5-02', 'Aplikasi Web', 3, 5),
(350, 7, 'D3TI-5-03', 'Keamanan Jaringan', 3, 5),
(351, 7, 'D3TI-5-04', 'Kapita Selekta', 3, 5),
(352, 7, 'D3TI-5-05', 'Analisis Sistem Informasi', 3, 5),
(353, 7, 'D3TI-5-06', 'Rekayasa Perangkat Lunak', 3, 5),
(354, 7, 'D3TI-5-07', 'Metode Penelitian/Bahasa Indonesia', 3, 5),
(381, 6, 'D3MI-1-01', 'Pancasila dan Kewarganegaraan', 3, 1),
(382, 6, 'D3MI-1-02', 'Bahasa Inggris I', 3, 1),
(383, 6, 'D3MI-1-03', 'Pengantar Akuntansi', 3, 1),
(384, 6, 'D3MI-1-04', 'Pengantar Teknologi Informasi', 3, 1),
(385, 6, 'D3MI-1-05', 'Algoritma dan Pemrograman', 3, 1),
(386, 6, 'D3MI-1-06', 'Paket Program Aplikasi', 3, 1),
(387, 6, 'D3MI-1-07', 'Matematika Dasar', 3, 1),
(388, 6, 'D3MI-1-08', 'Bahasa Indonesia', 3, 1),
(389, 6, 'D3MI-1-09', 'Kecakapan Antar Personil', 3, 1),
(390, 6, 'D3MI-2-01', 'Pendidikan Agama', 3, 2),
(391, 6, 'D3MI-2-02', 'Pemrograman Visual', 3, 2),
(392, 6, 'D3MI-2-03', 'Program Aplikasi Akuntansi', 3, 2),
(393, 6, 'D3MI-2-04', 'Pengantar Multimedia', 3, 2),
(394, 6, 'D3MI-2-05', 'Bahasa Inggris II', 3, 2),
(395, 6, 'D3MI-2-06', 'Manajemen Umum', 3, 2),
(396, 6, 'D3MI-2-07', 'Matematika Diskrit', 3, 2),
(397, 6, 'D3MI-2-08', 'Sistem Operasi', 3, 2),
(398, 6, 'D3MI-3-01', 'Pemrograman Berorientasi Objek I', 3, 3),
(399, 6, 'D3MI-3-02', 'Jaringan Komputer', 3, 3),
(400, 6, 'D3MI-3-03', 'Basis Data I', 3, 3),
(401, 6, 'D3MI-3-04', 'Internet dan Perancangan Web', 3, 3),
(402, 6, 'D3MI-3-05', 'Bahasa Inggris III', 3, 3),
(403, 6, 'D3MI-3-06', 'Statistik', 3, 3),
(404, 6, 'D3MI-3-07', 'Kewirausahaan', 3, 3),
(405, 6, 'D3MI-4-01', 'Pemrograman Berorientasi Objek II', 3, 4),
(406, 6, 'D3MI-4-02', 'Pemrograman Web I', 3, 4),
(407, 6, 'D3MI-4-03', 'Multimedia', 3, 4),
(408, 6, 'D3MI-4-04', 'Basis Data II', 3, 4),
(409, 6, 'D3MI-4-05', 'Analisis dan Perancangan Sistem Informasi', 3, 4),
(410, 6, 'D3MI-4-06', 'Etika Profesi', 3, 4),
(411, 6, 'D3MI-5-01', 'Pemrograman Web II', 3, 5),
(412, 6, 'D3MI-5-02', 'Basis Data III', 3, 5),
(413, 6, 'D3MI-5-03', 'Animasi', 3, 5),
(414, 6, 'D3MI-5-04', 'Kapita Selekta', 3, 5),
(415, 6, 'D3MI-5-05', 'Manajemen Proyek Sistem Informasi', 3, 5),
(416, 6, 'D3MI-5-06', 'Manajemen Sistem Informasi', 3, 5),
(417, 6, 'D3MI-5-07', 'Metode Penelitian', 3, 5),
(444, 1, 'SKK11', 'Pengantar Akuntansi', 2, 1),
(445, 1, 'SKK12', 'Konsep Pemrograman', 4, 1),
(446, 1, 'SKK13', 'Matematika Komputer', 3, 1),
(447, 1, 'SKK14', 'Pengantar Teknologi Informasi', 2, 1),
(448, 1, 'SKK15', 'Internet dan Perancangan Web', 4, 1),
(449, 1, 'SPK11', 'Agama', 3, 1),
(450, 1, 'SPK12', 'Bahasa Inggris I', 2, 1),
(451, 1, 'SKB21', 'Sistem Operasi', 3, 2),
(452, 1, 'SKK21', 'Program Aplikasi Akuntansi', 4, 2),
(453, 1, 'SKK22', 'Algoritma dan Struktur Data', 4, 2),
(454, 1, 'SKK23', 'Bahasa Inggris II', 3, 2),
(455, 1, 'SPK21', 'Pendidikan Pancasila dan Kewarganegaraan', 3, 2),
(456, 1, 'SKB31', 'Analisa dan Perancangan Sistem Informasi', 3, 3),
(457, 1, 'SKK31', 'Pemrograman Visual I', 4, 3),
(458, 1, 'SKK32', 'Pemrograman Web I', 4, 3),
(459, 1, 'SKK33', 'Basis Data II', 4, 3),
(460, 1, 'SKK34', 'Statistika', 3, 3),
(461, 1, 'SKB41', 'Sistem Informasi Manajemen', 2, 4),
(462, 1, 'SKB42', 'Jaringan Komputer dan Komunikasi Data', 3, 4),
(463, 1, 'SKK41', 'Pemrograman Visual II', 4, 4),
(464, 1, 'SKK42', 'Pemrograman Web II', 4, 4),
(465, 1, 'SKK43', 'Basis Data III', 4, 4),
(466, 1, 'SPB41', 'Etika Profesi', 3, 4),
(467, 1, 'SKB51', 'Manajemen Proyek Sistem Informasi', 3, 5),
(468, 1, 'SKB52', 'Interaksi Manusia dan Komputer', 3, 5),
(469, 1, 'SKK51', 'Pemrograman Visual III', 4, 5),
(470, 1, 'SKK52', 'Pemrograman Web III', 4, 5),
(471, 1, 'SBB51', 'Kewirausahaan dan Manajemen Bisnis', 3, 5),
(472, 1, 'SPK51', 'Bahasa Indonesia', 2, 5),
(473, 1, 'SPB51', 'Metodologi Penelitian', 2, 5),
(474, 1, 'SKB61', 'Kapita Selekta I', 4, 6),
(475, 1, 'SKB62', 'Desain dan Penerapan Basisdata', 4, 6),
(476, 1, 'SKB63', 'Sistem Informasi Eksekutif', 3, 6),
(477, 1, 'SKK61', 'Pemrograman Visual IV', 4, 6),
(478, 1, 'SKK62', 'Manajemen Umum', 2, 6),
(479, 1, 'SKB71', 'Kapita Selekta II', 2, 7),
(480, 1, 'SKB72', 'Desain dan Penerapan Pemrograman', 4, 7),
(481, 1, 'SKK71', 'Tata Kelola Teknologi Informasi', 4, 7),
(482, 1, 'SKK72', 'Rekayasa Sistem Informasi', 4, 7),
(483, 1, 'SKK73', 'e-Bisnis', 4, 7),
(484, 1, 'SBB81', 'Kuliah Kerja Praktek', 2, 8),
(485, 1, 'SKB81', 'Skripsi', 4, 8),
(486, 2, 'TKK11', 'Fisika Elektronika', 3, 1),
(487, 2, 'TKK12', 'Konsep Pemrograman', 4, 1),
(488, 2, 'TKK13', 'Matematika Komputer', 3, 1),
(489, 2, 'TKK14', 'Pengantar Teknologi Informasi', 2, 1),
(490, 2, 'TKK15', 'Internet dan Perancangan Web', 4, 1),
(491, 2, 'TPK11', 'Agama', 3, 1),
(492, 2, 'TPK12', 'Bahasa Inggris I', 2, 1),
(493, 2, 'TKB21', 'Sistem Operasi', 3, 2),
(494, 2, 'TKK21', 'Matematika Diskrit', 3, 2),
(495, 2, 'TKK22', 'Algoritma dan Struktur Data', 4, 2),
(496, 2, 'TKK23', 'Basisdata I', 4, 2),
(497, 2, 'TKK24', 'Bahasa Inggris II', 3, 2),
(498, 2, 'TPK21', 'Pendidikan Pancasila dan Kewarganegaraan', 3, 2),
(499, 2, 'TKB31', 'Analisa dan Peranc. Sistem Informasi', 3, 3),
(500, 2, 'TKK31', 'Pemrograman Visual I', 4, 3),
(501, 2, 'TKK32', 'Desain dan Analisis Algoritma', 3, 3),
(502, 2, 'TKK33', 'Basisdata II', 4, 3),
(503, 2, 'TKK34', 'Bahasa Inggris III', 3, 3),
(504, 2, 'TKK35', 'Statistika', 3, 3),
(505, 2, 'TKB41', 'Sistem Informasi Manajemen', 2, 4),
(506, 2, 'TKB42', 'Jaringan Komputer dan Komunikasi Data', 3, 4),
(507, 2, 'TKK41', 'Pemrograman Visual II', 4, 4),
(508, 2, 'TKK42', 'Pemrograman Web', 4, 4),
(509, 2, 'TKK43', 'Kecerdasan Buatan', 4, 4),
(510, 2, 'TPB41', 'Etika Profesi', 3, 4),
(511, 2, 'TKB51', 'Pemrograman Berorientasi Objek', 4, 5),
(512, 2, 'TKB52', 'Interaksi Manusia dan Komputer', 3, 5),
(513, 2, 'TBB51', 'Kewirausahaan dan Manajemen Bisnis', 3, 5),
(514, 2, 'TKK51', 'Desain dan Penerapan Jaringan Komputer', 4, 5),
(515, 2, 'TKK52', 'Sistem Pakar', 4, 5),
(516, 2, 'TPK51', 'Bahasa Indonesia', 2, 5),
(517, 2, 'TPB51', 'Metodologi Penelitian', 2, 5),
(518, 2, 'TKB61', 'Kapita Selekta I', 4, 6),
(519, 2, 'TKB62', 'Pemrograman Multimedia', 4, 6),
(520, 2, 'TKK61', 'Keamanan Jaringan', 4, 6),
(521, 2, 'TKK62', 'Logika Samar', 3, 6),
(522, 2, 'TKK63', 'Teori Bahasa dan Automata', 3, 6),
(523, 2, 'TKB71', 'Kapita Selekta II', 2, 7),
(524, 2, 'TKB72', 'Desain dan Penerapan Sistem Pakar', 4, 7),
(525, 2, 'TKK71', 'Tata Kelola Jaringan Komputer', 4, 7),
(526, 2, 'TKK72', 'Rekayasa Perangkat Lunak', 3, 7),
(527, 2, 'TKK73', 'Teknik Kompilasi', 3, 7),
(528, 2, 'TKK74', 'e-Bisnis', 4, 7),
(529, 2, 'TBB81', 'Kuliah Kerja Praktek', 2, 8),
(530, 2, 'TKB81', 'Skripsi', 4, 8),
(531, 3, 'RPK11', 'Pendidikan Agama', 3, 1),
(532, 3, 'RKK11', 'Matematika Dasar', 2, 1),
(533, 3, 'RPK12', 'Bahasa Inggris I', 2, 1),
(534, 3, 'RKK12', 'Pengantar Teknologi Informasi', 2, 1),
(535, 3, 'RKK13', 'Algoritma dan Pemrograman', 4, 1),
(536, 3, 'RPB11', 'Pemikiran Desain dan Kreativitas', 4, 1),
(537, 3, 'RKK14', 'Statistika', 2, 1),
(538, 3, 'RKB11', 'Pengantar Rekayasa Perangkat Lunak', 2, 1),
(539, 3, 'RPK21', 'Pancasila dan Kewarganegaraan', 3, 2),
(540, 3, 'RKK21', 'Matematika Diskrit', 2, 2),
(541, 3, 'RKB21', 'Arsitektur dan Organisasi Komputer', 3, 2),
(542, 3, 'RPK22', 'Bahasa Inggris II', 2, 2),
(543, 3, 'RKB22', 'Pemrograman dan Struktur Data', 3, 2),
(544, 3, 'RKB23', 'Basis Data', 4, 2),
(545, 3, 'RKB24', 'Model dan Metode Rekayasa Perangkat Lunak', 3, 2),
(546, 3, 'RKB31', 'Sistem Operasi', 3, 3),
(547, 3, 'RKB32', 'Jaringan Komputer', 3, 3),
(548, 3, 'RKB33', 'Rekayasa Kebutuhan Perangkat Lunak', 3, 3),
(549, 3, 'RPK31', 'Kecakapan Antar Personal', 2, 3),
(550, 3, 'RKB34', 'Desain dan Analisis Algoritma', 3, 3),
(551, 3, 'RKB35', 'Pemrograman Berorientasi Objek I', 4, 3),
(552, 3, 'RKB36', 'Kecerdasan Buatan', 3, 3),
(553, 3, 'RPK32', 'Bahasa Indonesia', 2, 3),
(554, 3, 'RKB41', 'Interaksi Manusia dan Komputer', 2, 4),
(555, 3, 'RKB42', 'Desain dan Arsitektur Perangkat Lunak', 4, 4),
(556, 3, 'RKB43', 'Basis Data Lanjut', 4, 4),
(557, 3, 'RKB44', 'Analisis dan Perancangan Sistem', 3, 4),
(558, 3, 'RKB45', 'Kecerdasan Komputasional', 3, 4),
(559, 3, 'RPB41', 'Technopreneurship', 3, 4),
(560, 3, 'RKB46', 'Keamanan Pengembangan Perangkat Lunak', 2, 4),
(561, 3, 'RPB51', 'Etika Profesi', 3, 5),
(562, 3, 'RKB51', 'Penjaminan Mutu Perangkat Lunak', 2, 5),
(563, 3, 'RKB52', 'Desain dan Pemrograman Web', 4, 5),
(564, 3, 'RKB53', 'Konstruksi dan Pemeliharaan Perangkat Lunak', 3, 5),
(565, 3, 'RKB54', 'Pemrograman Berorientasi Objek II', 4, 5),
(566, 3, 'RKB56', 'Pengujian Perangkat Lunak', 3, 5),
(567, 3, 'RKB57', 'Konsep Verifikasi dan Validasi Perangkat Lunak', 3, 5),
(568, 3, 'RKB61', 'Manajemen Proyek Perangkat Lunak', 3, 6),
(569, 3, 'RKB62', 'Metodologi Penelitian', 2, 6),
(570, 3, 'RKB63', 'Testing dan Implementasi Sistem', 3, 6),
(571, 3, 'RKB64', 'E-Bisnis', 4, 6),
(572, 3, 'RKB65', 'Pemrograman Perangkat Bergerak', 4, 6),
(573, 3, 'RKB66', 'Kapita Selekta I', 2, 6),
(574, 3, 'RKB67', 'Manajemen Proses Bisnis', 2, 6),
(575, 3, 'RKB71', 'Grafika Komputer', 2, 7),
(576, 3, 'RKB72', 'Proyek Pengembangan Perangkat Lunak', 3, 7),
(577, 3, 'RKB73', 'Kapita Selekta II', 2, 7),
(578, 3, 'RKB74', 'Sistem Pendukung Keputusan', 2, 7),
(579, 3, 'RKB75', 'Analisis Data', 2, 7),
(580, 3, 'RKB76', 'Manajemen Risiko dan Kualitas Perangkat Lunak', 2, 7),
(581, 3, 'RBB81', 'Praktik Kerja', 2, 8),
(582, 3, 'RPB81', 'Skripsi', 6, 8),
(583, 4, 'AKK11', 'Pengantar Akuntansi', 4, 1),
(584, 4, 'AKB11', 'Perpajakan', 2, 1),
(585, 4, 'AKK12', 'Pengantar Ilmu Ekonomi', 2, 1),
(586, 4, 'AKK13', 'Pengantar Manajemen', 2, 1),
(587, 4, 'AKK14', 'Matematika Ekonomi', 2, 1),
(588, 4, 'APK11', 'Bahasa Inggris I', 2, 1),
(589, 4, 'APK12', 'Pancasila & Kewarganegaraan', 3, 1),
(590, 4, 'APK13', 'Agama', 3, 1),
(591, 4, 'AKK21', 'Akuntansi Keuangan Menengah I', 4, 2),
(592, 4, 'AKB21', 'Akuntansi Perpajakan', 3, 2),
(593, 4, 'AKK22', 'Program Aplikasi Akuntansi I', 4, 2),
(594, 4, 'AKK23', 'Akuntansi Biaya I', 3, 2),
(595, 4, 'APB21', 'Manajemen Pemasaran', 3, 2),
(596, 4, 'AKK24', 'Ekonomi Mikro', 2, 2),
(597, 4, 'APK21', 'Bahasa Inggris II', 2, 2),
(598, 4, 'AKK31', 'Akuntansi Keuangan Menengah II', 4, 3),
(599, 4, 'AKK32', 'Akuntansi Biaya II', 3, 3),
(600, 4, 'AKK33', 'Akuntansi Anggaran I', 3, 3),
(601, 4, 'AKK34', 'Program Aplikasi Akuntansi II', 3, 3),
(602, 4, 'AKB31', 'Program Aplikasi Perpajakan', 3, 3),
(603, 4, 'AKK35', 'Ekonomi Makro', 3, 3),
(604, 4, 'APK31', 'Bahasa Indonesia', 2, 3),
(605, 4, 'AKK41', 'Akuntansi Keuangan Lanjutan I', 3, 4),
(606, 4, 'AKB41', 'Akuntansi Pemeriksaan I', 3, 4),
(607, 4, 'AKK42', 'Akuntansi Anggaran II', 3, 4),
(608, 4, 'AKK43', 'Program Aplikasi Akuntansi III', 3, 4),
(609, 4, 'AKB42', 'Sistem Informasi Akuntansi', 3, 4),
(610, 4, 'AKK44', 'Statistika', 3, 4),
(611, 4, 'MPK41', 'Etika Bisnis & Profesi', 2, 4),
(612, 4, 'AKK51', 'Akuntansi Keuangan Lanjutan II', 3, 5),
(613, 4, 'AKK52', 'Akuntansi Pemeriksaan II', 2, 5),
(614, 4, 'AKB51', 'Teori Akuntansi', 3, 5),
(615, 4, 'AKK53', 'Metodologi Penelitian Akuntansi', 3, 5),
(616, 4, 'AKK54', 'Akuntansi Manajemen', 3, 5),
(617, 4, 'AKB52', 'Sistem Informasi Manajemen', 3, 5),
(618, 4, 'AKK55', 'Akuntansi Sektor Publik', 3, 5),
(619, 4, 'AKB61', 'Akuntansi Pemeriksaan III', 3, 6),
(620, 4, 'AKB62', 'Analisis Laporan Keuangan', 3, 6),
(621, 4, 'ABB61', 'Bank dan Lembaga Keuangan', 3, 6),
(622, 4, 'APB61', 'Manajemen Investasi dan Pasar Modal', 3, 6),
(623, 4, 'AKB63', 'Akuntansi Internasional', 3, 6),
(624, 4, 'APB62', 'Studi Kelayakan Bisnis', 3, 6),
(625, 4, 'AKK71', 'Akuntansi Pemerintahan', 3, 7),
(626, 4, 'AKB71', 'Sistem Pengendalian Manajemen', 3, 7),
(627, 4, 'AKK72', 'Hukum Bisnis', 3, 7),
(628, 4, 'AKB72', 'Anti Korupsi', 3, 7),
(629, 4, 'AKB73', 'Kewirausahaan', 3, 7),
(630, 4, 'APB81', 'Magang', 3, 8),
(631, 4, 'APB82', 'Skripsi', 6, 8),
(632, 5, 'KBB11', 'Agama', 2, 1),
(633, 5, 'KBB12', 'Pancasila dan Kewarganegaraan', 3, 1),
(634, 5, 'KKK11', 'Pengantar Bisnis dan Kewirausahaan', 3, 1),
(635, 5, 'KKK12', 'Pengantar Manajemen', 3, 1),
(636, 5, 'KKK13', 'Akuntansi Dasar Ekonomi Bisnis', 3, 1),
(637, 5, 'KKK14', 'Pengantar Teknologi Informasi', 3, 1),
(638, 5, 'KKK15', 'Pengantar Bahasa Inggris/Inggris Bisnis', 3, 1),
(639, 5, 'KKB21', 'Sistem Informasi Manajemen', 3, 2),
(640, 5, 'KKB22', 'Perencanaan dan Kelayakan Bisnis', 3, 2),
(641, 5, 'KKK21', 'Matematika Bisnis', 3, 2),
(642, 5, 'KKK22', 'Manajemen Pemasaran Bisnis', 3, 2),
(643, 5, 'KKK23', 'Pengantar Ekonomi dan Perbankan', 3, 2),
(644, 5, 'KPB21', 'Bahasa Indonesia: Penulisan Ilmiah', 2, 2),
(645, 5, 'KPK21', 'Rekayasa dan Rancangan Produk 1', 3, 2),
(646, 5, 'KPK22', 'Etika Bisnis', 2, 2),
(647, 5, 'KKB31', 'Rekayasa dan Rancangan Produk 2', 3, 3),
(648, 5, 'KKB32', 'Akuntansi Biaya', 3, 3),
(649, 5, 'KKK31', 'Manajemen Organisasi dan Sumber Daya Manusia', 3, 3),
(650, 5, 'KKK32', 'Analisis Risiko Bisnis Statistik Multivariat', 3, 3),
(651, 5, 'KKK33', 'Manajemen Keuangan Bisnis', 3, 3),
(652, 5, 'KKK34', 'Statistika Bisnis', 3, 3),
(653, 5, 'KPB31', 'Design Thinking Inovasi', 3, 3),
(654, 5, 'KBB41', 'Anti Korupsi', 2, 4),
(655, 5, 'KKB41', 'Bisnis Berbasis Teknologi', 3, 4),
(656, 5, 'KKB42', 'Perpajakan', 2, 4),
(657, 5, 'KKB43', 'Studi Kelayakan Bisnis', 3, 4),
(658, 5, 'KKB44', 'Akuntansi Manajemen', 3, 4),
(659, 5, 'KKB45', 'Manajemen Lingkungan Bisnis', 3, 4),
(660, 5, 'KKK41', 'Usaha Kecil dan Mikro', 3, 4),
(661, 5, 'KKK42', 'Hukum Bisnis dan Kontrak Bisnis', 2, 4),
(662, 5, 'KBB51', 'Analisis Investasi dan Modal', 3, 5),
(663, 5, 'KKB51', 'Bisnis Internasional', 3, 5),
(664, 5, 'KKB52', 'Kepemimpinan dan Praktik Manajemen', 3, 5),
(665, 5, 'KKK51', 'Mentoring Kewirausahaan 1', 3, 5),
(666, 5, 'KKK52', 'Manajemen Rantai Nilai (Chain) Manajemen', 3, 5),
(667, 5, 'KPB51', 'Metode Penelitian Bisnis', 3, 5),
(668, 5, 'KPB52', 'Komunikasi dan Negosiasi Bisnis', 3, 5),
(669, 5, 'KKB61', 'Mentoring Kewirausahaan 2', 3, 6),
(670, 5, 'KKB62', 'Manajemen Strategi', 3, 6),
(671, 5, 'KKK61', 'Seminar Kewirausahaan', 3, 6),
(672, 5, 'KKB63', 'Manajemen Pengembangan Produk', 3, 6),
(673, 5, 'KKB64', 'E\'Commerce', 3, 6),
(674, 5, 'KKB65', 'Perencanaan Proyek Digital', 3, 6),
(675, 5, 'KKB610', 'Manajemen Merek', 3, 6),
(676, 5, 'KKB71', 'Teknologi dan Analisa Bisnis', 3, 7),
(677, 5, 'KKK71', 'Dinamika Bisnis', 3, 7),
(678, 5, 'KKK72', 'Seminar Proposal Penelitian', 3, 7),
(679, 5, 'KPK71', 'Mentoring Kewirausahaan 3', 3, 7),
(680, 5, 'KPK81', 'Magang', 2, 8),
(681, 5, 'KKB81', 'Skripsi', 4, 8),
(682, 6, 'IBB11', 'Pancasila dan Kewarganegaraan', 2, 1),
(683, 6, 'IKK11', 'Bahasa Inggris I', 2, 1),
(684, 6, 'IKK12', 'Matematika Dasar', 2, 1),
(685, 6, 'IKK13', 'Pengantar Teknologi Informasi', 2, 1),
(686, 6, 'IKK14', 'Sistem Digital', 3, 1),
(687, 6, 'IKK15', 'Algoritma dan Pemrograman', 4, 1),
(688, 6, 'IKK16', 'Paket Program Aplikasi', 3, 1),
(689, 6, 'IPB11', 'Bahasa Indonesia', 2, 1),
(690, 6, 'IPK11', 'Kecakapan Antar Personal', 2, 1),
(691, 6, 'IKB21', 'Internet dan Perancangan Web', 4, 2),
(692, 6, 'IKB22', 'Perakitan Komputer', 3, 2),
(693, 6, 'IKK21', 'Bahasa Inggris II', 2, 2),
(694, 6, 'IKK22', 'Struktur Data', 4, 2),
(695, 6, 'IKK23', 'Matematika Diskrit', 2, 2),
(696, 6, 'IKK24', 'Basis Data I', 4, 2),
(697, 6, 'IKK25', 'Sistem Operasi', 3, 2),
(698, 6, 'IKB31', 'Jaringan Komputer I', 4, 3),
(699, 6, 'IKB32', 'Basis Data II', 4, 3),
(700, 6, 'IKB33', 'Pemrograman Web I', 4, 3),
(701, 6, 'IKK31', 'Bahasa Inggris III', 2, 3),
(702, 6, 'IKK32', 'Statistika', 3, 3),
(703, 6, 'IKK33', 'Manajemen Sistem Informasi', 2, 3),
(704, 6, 'IPB31', 'Kewirausahaan', 2, 3),
(705, 6, 'IBB41', 'Pendidikan Agama', 2, 4),
(706, 6, 'IKB41', 'Pemrograman Web II', 4, 4),
(707, 6, 'IKB42', 'Jaringan Komputer II', 4, 4),
(708, 6, 'IKB43', 'Pemrograman I', 4, 4),
(709, 6, 'IKB44', 'Multimedia', 4, 4),
(710, 6, 'IKK41', 'Manajemen Proyek Sistem Informasi', 2, 4),
(711, 6, 'IPK41', 'Etika Profesi', 2, 4),
(712, 6, 'IKB51', 'Pemrograman II', 4, 5),
(713, 6, 'IKB52', 'Aplikasi Web', 4, 5),
(714, 6, 'IKB53', 'Keamanan Jaringan', 4, 5),
(715, 6, 'IKB54', 'Kapita Selekta', 2, 5),
(716, 6, 'IKK51', 'Analisis Sistem Informasi', 3, 5),
(717, 6, 'IKK52', 'Rekayasa Perangkat Lunak', 3, 5),
(718, 6, 'IPB51', 'Metode Penelitian/Bahasa Indonesia', 2, 5),
(719, 6, 'IBB61', 'Praktek Kerja Lapangan (PKL)', 2, 6),
(720, 6, 'IKB61', 'Tugas Akhir (TA)', 4, 6),
(721, 7, 'MBB11', 'Pancasila dan Kewarganegaraan', 2, 1),
(722, 7, 'MKK11', 'Bahasa Inggris I', 2, 1),
(723, 7, 'MKK12', 'Pengantar Akuntansi', 3, 1),
(724, 7, 'MKK13', 'Pengantar Teknologi Informasi', 2, 1),
(725, 7, 'MKK14', 'Algoritma dan Pemrograman', 4, 1),
(726, 7, 'MKK15', 'Paket Program Aplikasi', 3, 1),
(727, 7, 'MKK16', 'Matematika Dasar', 2, 1),
(728, 7, 'MPB11', 'Bahasa Indonesia', 2, 1),
(729, 7, 'MPK11', 'Kecakapan Antar Personil', 2, 1),
(730, 7, 'MBB21', 'Pendidikan Agama', 2, 2),
(731, 7, 'MKB21', 'Pemrograman Visual', 4, 2),
(732, 7, 'MKB22', 'Program Aplikasi Akuntansi', 4, 2),
(733, 7, 'MKB23', 'Pengantar Multimedia', 3, 2),
(734, 7, 'MKK21', 'Bahasa Inggris II', 2, 2),
(735, 7, 'MKK22', 'Manajemen Umum', 2, 2),
(736, 7, 'MKK23', 'Matematika Diskrit', 2, 2),
(737, 7, 'MKK24', 'Sistem Operasi', 3, 2),
(738, 7, 'MKB31', 'Pemrograman Berorientasi Objek I', 4, 3),
(739, 7, 'MKB32', 'Jaringan Komputer', 3, 3),
(740, 7, 'MKB33', 'Basis Data I', 4, 3),
(741, 7, 'MKB34', 'Internet dan Perancangan Web', 4, 3),
(742, 7, 'MKK31', 'Bahasa Inggris III', 2, 3),
(743, 7, 'MKK32', 'Statistik', 2, 3),
(744, 7, 'MPB31', 'Kewirausahaan', 2, 3),
(745, 7, 'MKB41', 'Pemrograman Berorientasi Objek II', 4, 4),
(746, 7, 'MKB42', 'Pemrograman Web I', 4, 4),
(747, 7, 'MKB43', 'Multimedia', 4, 4),
(748, 7, 'MKB44', 'Basis Data II', 4, 4),
(749, 7, 'MKK41', 'Analisis dan Perancangan Sistem Informasi', 4, 4),
(750, 7, 'MKB51', 'Pemrograman Web II', 4, 5),
(751, 7, 'MKB52', 'Basis Data III', 4, 5),
(752, 7, 'MKB53', 'Animasi', 4, 5),
(753, 7, 'MKB54', 'Kapita Selekta', 2, 5),
(754, 7, 'MKK51', 'Manajemen Proyek Sistem Informasi', 3, 5),
(755, 7, 'MKK52', 'Manajemen Sistem Informasi', 3, 5),
(756, 7, 'MPB51', 'Metode Penelitian', 2, 5),
(757, 7, 'MBB61', 'Praktek Kerja Lapangan (PKL)', 2, 6),
(758, 7, 'MKB61', 'Tugas Akhir', 4, 6);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_matkul`
--

CREATE TABLE `nilai_matkul` (
  `nim` varchar(20) NOT NULL,
  `id_matkul` int(11) NOT NULL,
  `id_semester` int(11) NOT NULL,
  `nilai_angka` decimal(5,2) NOT NULL,
  `huruf` varchar(2) NOT NULL,
  `bobot` decimal(3,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nilai_matkul`
--

INSERT INTO `nilai_matkul` (`nim`, `id_matkul`, `id_semester`, `nilai_angka`, `huruf`, `bobot`) VALUES
('2601001', 3, 2, 90.00, 'A', 4.00);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_semester`
--

CREATE TABLE `nilai_semester` (
  `id_nilai` int(11) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `id_semester` int(11) NOT NULL,
  `ips` decimal(3,2) NOT NULL,
  `ipk` decimal(3,2) NOT NULL
) ;

--
-- Dumping data for table `nilai_semester`
--

INSERT INTO `nilai_semester` (`id_nilai`, `nim`, `id_semester`, `ips`, `ipk`) VALUES
(7, '2601001', 2, 4.00, 4.00);

-- --------------------------------------------------------

--
-- Table structure for table `organisasi`
--

CREATE TABLE `organisasi` (
  `id_org` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_dosen_pembina` int(11) DEFAULT NULL,
  `nama_org` varchar(100) NOT NULL,
  `singkatan` varchar(20) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `status_aktif` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `organisasi`
--

INSERT INTO `organisasi` (`id_org`, `id_kategori`, `id_dosen_pembina`, `nama_org`, `singkatan`, `deskripsi`, `status_aktif`) VALUES
(1, 1, NULL, 'BEM AMIK MBP', 'BEM', 'Badan Eksekutif Mahasiswa', 1),
(2, 3, NULL, 'IMKA Persadanta UMBP', 'IMKA', 'Ikatan Mahasiswa Karo', 1),
(3, 2, NULL, 'IMI', 'IMI', 'Ikatan Mahasiswa Islam', 1),
(4, 2, NULL, 'KMK', 'KMK', 'Kesatuan Mahasiswa Kristen', 1),
(5, 2, NULL, 'HIMKA', 'HIMKA', 'Himpunan Mahasiswa Katolik', 1),
(6, 4, NULL, 'HIMAPA', 'HIMAPA', 'Himpunan Mahasiswa Pencinta Alam', 1),
(7, 4, NULL, 'Programmer Club of Computer', NULL, 'Komunitas pemrograman', 1),
(8, 4, NULL, 'Sanggar Seni AMIK MBP', NULL, 'Kegiatan seni', 1),
(9, 4, NULL, 'Paduan Suara AMIK MBP', NULL, 'Kegiatan musik dan vokal', 1),
(10, 6, NULL, 'GEMAN', 'GEMAN', 'Gerakan Mahasiswa Anti Narkoba', 1),
(11, 5, NULL, 'AMIK MBP FC', 'FC', 'Klub sepak bola', 1),
(12, 5, NULL, 'AMIK MBP VC', 'VC', 'Klub bola voli', 1),
(13, 3, NULL, 'IMABATO', 'IMABATO', 'Ikatan Mahasiswa Batak Toba', 1),
(14, 3, NULL, 'IPMEN', 'IPMEN', 'Ikatan Persaudaraan Mahasiswa Nias', 1),
(15, 7, NULL, 'Badan Eksekutif Mahasiswa', 'BEM', 'Organisasi eksekutif tingkat universitas', 1),
(16, 5, NULL, 'Unit Kegiatan Olahraga', 'UKO', 'Wadah minat dan bakat olahraga', 1),
(17, 8, NULL, 'Unit Kegiatan Seni', 'UKS', 'Wadah minat dan bakat seni', 1),
(18, 2, NULL, 'Unit Kegiatan Kerohanian', 'UKK', 'Wadah kegiatan keagamaan', 1),
(19, 6, NULL, 'Himpunan Mahasiswa Peduli', 'HMP', 'Wadah kegiatan sosial', 1);

-- --------------------------------------------------------

--
-- Table structure for table `parameter_penilaian`
--

CREATE TABLE `parameter_penilaian` (
  `id_param` int(11) NOT NULL,
  `min_ipk` decimal(3,2) NOT NULL,
  `min_kehadiran_rata` decimal(5,2) NOT NULL,
  `kehadiran_target` decimal(5,2) NOT NULL
) ;

--
-- Dumping data for table `parameter_penilaian`
--

INSERT INTO `parameter_penilaian` (`id_param`, `min_ipk`, `min_kehadiran_rata`, `kehadiran_target`) VALUES
(1, 3.50, 90.00, 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_bayar` int(11) NOT NULL,
  `id_pendaftaran` int(11) NOT NULL,
  `jenis_bayar` varchar(20) NOT NULL,
  `nominal` decimal(12,0) NOT NULL,
  `tgl_bayar` date DEFAULT NULL,
  `bukti_path` varchar(255) DEFAULT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'menunggu'
) ;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_bayar`, `id_pendaftaran`, `jenis_bayar`, `nominal`, `tgl_bayar`, `bukti_path`, `status`) VALUES
(5, 9, 'PENDAFTARAN', 300000, '2026-11-24', 'uploads/bayar_b6979a10f8ca2d53.jpg', 'lunas'),
(6, 10, 'PENDAFTARAN', 300000, '2026-11-25', 'uploads/bayar_55afc6a97edd1641.jpg', 'lunas'),
(7, 11, 'PENDAFTARAN', 300000, '2026-11-25', 'uploads/bayar_9da147e7ccfe19c9.jpg', 'menunggu');

-- --------------------------------------------------------

--
-- Table structure for table `pendaftaran`
--

CREATE TABLE `pendaftaran` (
  `id_pendaftaran` int(11) NOT NULL,
  `id_calon` int(11) NOT NULL,
  `id_prodi` int(11) NOT NULL,
  `id_jalur` int(11) NOT NULL,
  `id_gelombang` int(11) DEFAULT NULL,
  `id_skema` int(11) DEFAULT NULL,
  `tgl_daftar` date NOT NULL,
  `kode_referal` varchar(20) DEFAULT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'diproses',
  `status_administrasi` enum('belum','menunggu','disetujui','ditolak') NOT NULL DEFAULT 'belum',
  `hasil_wawancara` enum('belum','lulus','tidak_lulus') NOT NULL DEFAULT 'belum',
  `nilai_wawancara` tinyint(3) UNSIGNED DEFAULT NULL,
  `catatan_wawancara` varchar(255) DEFAULT NULL
) ;

--
-- Dumping data for table `pendaftaran`
--

INSERT INTO `pendaftaran` (`id_pendaftaran`, `id_calon`, `id_prodi`, `id_jalur`, `id_gelombang`, `id_skema`, `tgl_daftar`, `kode_referal`, `status`, `status_administrasi`, `hasil_wawancara`, `nilai_wawancara`, `catatan_wawancara`) VALUES
(9, 14, 1, 3, NULL, NULL, '2026-11-24', NULL, 'lulus', 'disetujui', 'lulus', 90, NULL),
(10, 15, 1, 3, NULL, NULL, '2026-11-25', NULL, 'lulus', 'disetujui', 'lulus', 90, 'CANTIK'),
(11, 16, 1, 2, NULL, NULL, '2026-11-25', NULL, 'diproses', 'belum', 'belum', NULL, NULL);

--
-- Triggers `pendaftaran`
--
DELIMITER $$
CREATE TRIGGER `trg_lulus_jadi_mahasiswa` AFTER UPDATE ON `pendaftaran` FOR EACH ROW BEGIN
  DECLARE v_thn  INT;
  DECLARE v_pref VARCHAR(4);
  DECLARE v_urut INT;
  DECLARE v_nama VARCHAR(100);
  IF NEW.status = 'lulus' AND OLD.status <> 'lulus'
     AND NOT EXISTS (SELECT 1 FROM mahasiswa WHERE id_calon = NEW.id_calon) THEN
    SET v_thn  = YEAR(CURDATE());
    SET v_pref = CONCAT(RIGHT(v_thn, 2), LPAD(NEW.id_prodi, 2, '0'));
    SELECT COALESCE(MAX(CAST(SUBSTRING(nim, 5) AS UNSIGNED)), 0) + 1 INTO v_urut
      FROM mahasiswa WHERE nim LIKE CONCAT(v_pref, '%');
    SELECT nama INTO v_nama FROM calon_mahasiswa WHERE id_calon = NEW.id_calon;
    INSERT INTO mahasiswa (nim, id_calon, id_prodi, nama, angkatan)
    VALUES (CONCAT(v_pref, LPAD(v_urut, 4, '0')), NEW.id_calon, NEW.id_prodi, v_nama, v_thn);
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `pendaftaran_organisasi`
--

CREATE TABLE `pendaftaran_organisasi` (
  `id_daftar` int(11) NOT NULL,
  `id_calon` int(11) NOT NULL,
  `id_org` int(11) NOT NULL,
  `alasan` varchar(255) NOT NULL,
  `tgl_daftar` date NOT NULL,
  `status` enum('menunggu','diterima','ditolak') NOT NULL DEFAULT 'menunggu',
  `catatan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pendaftaran_organisasi`
--

INSERT INTO `pendaftaran_organisasi` (`id_daftar`, `id_calon`, `id_org`, `alasan`, `tgl_daftar`, `status`, `catatan`) VALUES
(2, 14, 4, '-', '2026-11-24', 'diterima', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `penerima_beasiswa`
--

CREATE TABLE `penerima_beasiswa` (
  `id_penerima` int(11) NOT NULL,
  `id_calon` int(11) NOT NULL,
  `id_beasiswa` int(11) NOT NULL,
  `id_potongan` int(11) DEFAULT NULL,
  `nim` varchar(10) DEFAULT NULL,
  `tgl_ditetapkan` date DEFAULT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'diajukan'
) ;

--
-- Dumping data for table `penerima_beasiswa`
--

INSERT INTO `penerima_beasiswa` (`id_penerima`, `id_calon`, `id_beasiswa`, `id_potongan`, `nim`, `tgl_ditetapkan`, `status`) VALUES
(1, 3, 1, NULL, NULL, '2024-08-01', 'disetujui');

-- --------------------------------------------------------

--
-- Table structure for table `pengampu_matkul`
--

CREATE TABLE `pengampu_matkul` (
  `id_pengampu` int(11) NOT NULL,
  `id_dosen` int(11) NOT NULL,
  `id_matkul` int(11) NOT NULL,
  `id_semester` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pengampu_matkul`
--

INSERT INTO `pengampu_matkul` (`id_pengampu`, `id_dosen`, `id_matkul`, `id_semester`) VALUES
(1, 4, 1, 1),
(2, 4, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `peran` varchar(20) NOT NULL,
  `id_calon` int(11) DEFAULT NULL
) ;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `username`, `password`, `nama`, `peran`, `id_calon`) VALUES
(1, 'admin', '$2y$10$udDiPVpbjO.fvPar5kJgc.qyQ0c2RBY7d5QXO1VtMrieD6KWOZZny', 'Administrator', 'admin', NULL),
(2, 'panitia', '$2y$10$udDiPVpbjO.fvPar5kJgc.qyQ0c2RBY7d5QXO1VtMrieD6KWOZZny', 'Panitia Penerimaan', 'panitia', NULL),
(3, 'kemhs', '$2y$10$udDiPVpbjO.fvPar5kJgc.qyQ0c2RBY7d5QXO1VtMrieD6KWOZZny', 'Bagian Kemahasiswaan', 'kemahasiswaan', NULL),
(4, 'natasyagtg@gmail.com', '$2y$10$eEMD6KrNa5gbD1LPDRLg7OByN8Gk.co5Tn7qg40AhTKcZ3iJ2B7D6', 'Natasya Feberina', 'calon', NULL),
(5, 'natashaginting@gmail.com', '$2y$10$G5dtm/v7/RQZ4DnB2.PVmuKwNjZSLaOw7WBbU4VMAJ0KU.wGoWwQe', 'Natasya Feberina Br Ginting', 'calon', NULL),
(6, 'airensitepu12@gmail.com', '$2y$10$oYDp0d3HRMNtSRZT9DyATO2ZlSjFcDMYHuDyUCaCwHa/rgjf8lAGO', 'AIREN KEIN', 'calon', 14),
(7, 'verasihombing@gmail.com', '$2y$10$KnHpq8iWPFbnvfWs/FFnRujbD5mV7K.ArnZf1nvCvOC9q6gnsGEBy', 'Vera Dina Sari', 'calon', 15),
(8, 'sofyindah7@gmail.com', '$2y$10$4IC8wvBJ.9lzwsLvKKie6uNlPWJiN1wf76vJk.x2RWBwJMomihLRe', 'sofy', 'calon', 16),
(9, 'admin@umbp.ac.id', '$2y$10$/zmmr1dSpdEAT.TKoikpAeSL30OPYNamp6Mr.h6MAhQSCQm5cLC1a', 'Administrator', 'admin', NULL),
(10, 'panitia@umbp.ac.id', '$2y$10$iGzj6bCkBrg1I6w.oOUGUOwyQHVzXIQPKINokV3nUPdeoH9n5NBQ2', 'Panitia PMB', 'panitia', NULL),
(11, 'kemahasiswaan@umbp.ac.id', '$2y$10$mYBJasqDc9jlC4ReLcePGufrg35RN4120IHCwblKaVPcs58T.N2yi', 'Bagian Kemahasiswaan', 'kemahasiswaan', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `potongan_uang_kuliah`
--

CREATE TABLE `potongan_uang_kuliah` (
  `id_potongan` int(11) NOT NULL,
  `id_beasiswa` int(11) NOT NULL,
  `nama_potongan` varchar(50) NOT NULL,
  `persen` decimal(5,2) NOT NULL,
  `syarat` varchar(150) DEFAULT NULL
) ;

--
-- Dumping data for table `potongan_uang_kuliah`
--

INSERT INTO `potongan_uang_kuliah` (`id_potongan`, `id_beasiswa`, `nama_potongan`, `persen`, `syarat`) VALUES
(1, 5, 'Ranking 1', 30.00, 'Ranking 1 di sekolah'),
(2, 5, 'Ranking 2', 25.00, 'Ranking 2 di sekolah'),
(3, 5, 'Ranking 3', 20.00, 'Ranking 3 di sekolah'),
(4, 5, 'Ranking 4-10', 15.00, 'Ranking 4 sampai 10 di sekolah'),
(5, 5, 'Anak Guru/Pegawai Sekolah', 20.00, 'Orang tua berprofesi guru atau pegawai sekolah'),
(6, 1, 'Potongan 100%', 100.00, NULL),
(7, 2, 'Potongan 50%', 50.00, NULL),
(8, 2, 'Potongan 100%', 100.00, NULL),
(9, 3, 'Potongan 100%', 100.00, NULL),
(10, 4, 'Potongan 25%', 25.00, NULL),
(11, 4, 'Potongan 50%', 50.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `program_studi`
--

CREATE TABLE `program_studi` (
  `id_prodi` int(11) NOT NULL,
  `kode_prodi` varchar(10) NOT NULL,
  `nama_prodi` varchar(100) NOT NULL,
  `jenjang` varchar(5) NOT NULL,
  `kuota` int(11) DEFAULT NULL
) ;

--
-- Dumping data for table `program_studi`
--

INSERT INTO `program_studi` (`id_prodi`, `kode_prodi`, `nama_prodi`, `jenjang`, `kuota`) VALUES
(1, 'SI-S1', 'Sistem Informasi', 'S1', NULL),
(2, 'TI-S1', 'Teknik Informatika', 'S1', NULL),
(3, 'KWU-S1', 'Kewirausahaan', 'S1', NULL),
(4, 'AKT-S1', 'Akuntansi', 'S1', NULL),
(5, 'RPL-S1', 'Rekayasa Perangkat Lunak', 'S1', NULL),
(6, 'MI-D3', 'Manajemen Informatika', 'D3', NULL),
(7, 'TI-D3', 'Teknik Informatika', 'D3', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rekap_kehadiran`
--

CREATE TABLE `rekap_kehadiran` (
  `id_rekap` int(11) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `id_semester` int(11) NOT NULL,
  `total_pertemuan` int(11) NOT NULL,
  `total_hadir` int(11) NOT NULL,
  `persen_hadir` decimal(5,2) GENERATED ALWAYS AS (round(`total_hadir` * 100 / nullif(`total_pertemuan`,0),2)) STORED
) ;

--
-- Dumping data for table `rekap_kehadiran`
--

INSERT INTO `rekap_kehadiran` (`id_rekap`, `nim`, `id_semester`, `total_pertemuan`, `total_hadir`) VALUES
(8, '2601001', 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id_semester` int(11) NOT NULL,
  `tahun_akademik` varchar(9) NOT NULL,
  `jenis` varchar(6) NOT NULL
) ;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id_semester`, `tahun_akademik`, `jenis`) VALUES
(1, '2025/2026', 'ganjil'),
(3, '2025/2026', 'Genap'),
(2, '2026/2027', 'ganjil');

-- --------------------------------------------------------

--
-- Table structure for table `skema_pembayaran`
--

CREATE TABLE `skema_pembayaran` (
  `id_skema` int(11) NOT NULL,
  `jenis` varchar(10) NOT NULL,
  `jenjang` varchar(5) NOT NULL,
  `nominal_cicilan` decimal(12,0) NOT NULL,
  `diskon_persen` decimal(5,2) NOT NULL DEFAULT 0.00
) ;

--
-- Dumping data for table `skema_pembayaran`
--

INSERT INTO `skema_pembayaran` (`id_skema`, `jenis`, `jenjang`, `nominal_cicilan`, `diskon_persen`) VALUES
(1, '6x', 'S1', 1500000, 0.00),
(2, '4x', 'S1', 2150000, 0.00),
(3, '2x', 'S1', 4150000, 0.00),
(4, 'LUNAS', 'S1', 8300000, 20.00),
(5, '6x', 'D3', 1350000, 0.00),
(6, '4x', 'D3', 2000000, 0.00),
(7, '2x', 'D3', 3950000, 0.00),
(8, 'LUNAS', 'D3', 7900000, 20.00);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_peringkat_mahasiswa_terbaik`
-- (See below for the actual view)
--
CREATE TABLE `v_peringkat_mahasiswa_terbaik` (
`nim` varchar(10)
,`nama` varchar(100)
,`id_semester` int(11)
,`id_prodi` int(11)
,`ipk` decimal(3,2)
,`persen_hadir` decimal(5,2)
,`peringkat` bigint(21)
);

-- --------------------------------------------------------

--
-- Structure for view `v_peringkat_mahasiswa_terbaik`
--
DROP TABLE IF EXISTS `v_peringkat_mahasiswa_terbaik`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_peringkat_mahasiswa_terbaik`  AS SELECT `x`.`nim` AS `nim`, `x`.`nama` AS `nama`, `x`.`id_semester` AS `id_semester`, `x`.`id_prodi` AS `id_prodi`, `x`.`ipk` AS `ipk`, `x`.`persen_hadir` AS `persen_hadir`, rank() over ( partition by `x`.`id_semester`,`x`.`id_prodi` order by `x`.`ipk` desc,`x`.`persen_hadir` desc) AS `peringkat` FROM (select `m`.`nim` AS `nim`,`m`.`nama` AS `nama`,`ns`.`id_semester` AS `id_semester`,`m`.`id_prodi` AS `id_prodi`,`ns`.`ipk` AS `ipk`,`rk`.`persen_hadir` AS `persen_hadir` from (((`mahasiswa` `m` join `nilai_semester` `ns` on(`ns`.`nim` = `m`.`nim`)) join `rekap_kehadiran` `rk` on(`rk`.`nim` = `m`.`nim` and `rk`.`id_semester` = `ns`.`id_semester`)) join (select `parameter_penilaian`.`min_ipk` AS `min_ipk`,`parameter_penilaian`.`min_kehadiran_rata` AS `min_kehadiran_rata` from `parameter_penilaian` limit 1) `pp`) where `ns`.`ipk` >= `pp`.`min_ipk` and `rk`.`persen_hadir` >= `pp`.`min_kehadiran_rata`) AS `x` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id_absen`),
  ADD UNIQUE KEY `uq_absensi` (`nim`,`id_matkul`,`tanggal`),
  ADD KEY `fk_abs_mk` (`id_matkul`),
  ADD KEY `fk_abs_sem` (`id_semester`);

--
-- Indexes for table `beasiswa`
--
ALTER TABLE `beasiswa`
  ADD PRIMARY KEY (`id_beasiswa`),
  ADD UNIQUE KEY `nama_beasiswa` (`nama_beasiswa`),
  ADD KEY `fk_beasiswa_jalur` (`id_jalur`);

--
-- Indexes for table `berkas_pendaftaran`
--
ALTER TABLE `berkas_pendaftaran`
  ADD PRIMARY KEY (`id_berkas`),
  ADD KEY `fk_berkas_pend` (`id_pendaftaran`);

--
-- Indexes for table `calon_mahasiswa`
--
ALTER TABLE `calon_mahasiswa`
  ADD PRIMARY KEY (`id_calon`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`id_dosen`),
  ADD UNIQUE KEY `nidn` (`nidn`),
  ADD UNIQUE KEY `uq_satu_kaprodi` (`kaprodi_key`),
  ADD KEY `fk_dosen_prodi` (`id_prodi`);

--
-- Indexes for table `gelombang`
--
ALTER TABLE `gelombang`
  ADD PRIMARY KEY (`id_gelombang`);

--
-- Indexes for table `jadwal_seleksi`
--
ALTER TABLE `jadwal_seleksi`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD UNIQUE KEY `uq_js` (`id_pendaftaran`,`jenis`);

--
-- Indexes for table `jalur_berkas`
--
ALTER TABLE `jalur_berkas`
  ADD PRIMARY KEY (`id_jalur`,`jenis_berkas`);

--
-- Indexes for table `jalur_pendaftaran`
--
ALTER TABLE `jalur_pendaftaran`
  ADD PRIMARY KEY (`id_jalur`),
  ADD UNIQUE KEY `nama_jalur` (`nama_jalur`);

--
-- Indexes for table `kategori_organisasi`
--
ALTER TABLE `kategori_organisasi`
  ADD PRIMARY KEY (`id_kategori`),
  ADD UNIQUE KEY `nama_kategori` (`nama_kategori`);

--
-- Indexes for table `keanggotaan`
--
ALTER TABLE `keanggotaan`
  ADD PRIMARY KEY (`id_anggota`),
  ADD UNIQUE KEY `uq_anggota` (`nim`,`id_org`,`periode`),
  ADD KEY `fk_ang_org` (`id_org`);

--
-- Indexes for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD PRIMARY KEY (`id_kegiatan`),
  ADD KEY `fk_keg_org` (`id_org`);

--
-- Indexes for table `keputusan_lembaga`
--
ALTER TABLE `keputusan_lembaga`
  ADD PRIMARY KEY (`id_keputusan`),
  ADD UNIQUE KEY `uq_lembaga` (`id_pendaftaran`,`lembaga`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`),
  ADD UNIQUE KEY `id_calon` (`id_calon`),
  ADD KEY `fk_mhs_prodi` (`id_prodi`);

--
-- Indexes for table `mahasiswa_terbaik`
--
ALTER TABLE `mahasiswa_terbaik`
  ADD PRIMARY KEY (`id_terbaik`),
  ADD UNIQUE KEY `uq_mt_peringkat` (`id_semester`,`id_prodi`,`peringkat`),
  ADD UNIQUE KEY `uq_mt_mhs` (`nim`,`id_semester`),
  ADD KEY `fk_mt_prodi` (`id_prodi`);

--
-- Indexes for table `mahasiswa_terbaik_angkatan`
--
ALTER TABLE `mahasiswa_terbaik_angkatan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_angkatan_prodi` (`angkatan`,`id_prodi`,`peringkat`);

--
-- Indexes for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD PRIMARY KEY (`id_matkul`),
  ADD UNIQUE KEY `kode_mk` (`kode_mk`),
  ADD KEY `fk_mk_prodi` (`id_prodi`);

--
-- Indexes for table `nilai_matkul`
--
ALTER TABLE `nilai_matkul`
  ADD PRIMARY KEY (`nim`,`id_matkul`),
  ADD KEY `idx_nm_sem` (`nim`,`id_semester`);

--
-- Indexes for table `nilai_semester`
--
ALTER TABLE `nilai_semester`
  ADD PRIMARY KEY (`id_nilai`),
  ADD UNIQUE KEY `uq_nilai` (`nim`,`id_semester`),
  ADD KEY `fk_nilai_sem` (`id_semester`);

--
-- Indexes for table `organisasi`
--
ALTER TABLE `organisasi`
  ADD PRIMARY KEY (`id_org`),
  ADD UNIQUE KEY `nama_org` (`nama_org`),
  ADD KEY `fk_org_kategori` (`id_kategori`),
  ADD KEY `fk_org_pembina` (`id_dosen_pembina`);

--
-- Indexes for table `parameter_penilaian`
--
ALTER TABLE `parameter_penilaian`
  ADD PRIMARY KEY (`id_param`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_bayar`),
  ADD KEY `fk_bayar_pend` (`id_pendaftaran`);

--
-- Indexes for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD PRIMARY KEY (`id_pendaftaran`),
  ADD UNIQUE KEY `uq_pend_calon_prodi` (`id_calon`,`id_prodi`),
  ADD KEY `fk_pend_prodi` (`id_prodi`),
  ADD KEY `fk_pend_jalur` (`id_jalur`),
  ADD KEY `fk_pend_gelombang` (`id_gelombang`),
  ADD KEY `fk_pend_skema` (`id_skema`);

--
-- Indexes for table `pendaftaran_organisasi`
--
ALTER TABLE `pendaftaran_organisasi`
  ADD PRIMARY KEY (`id_daftar`),
  ADD UNIQUE KEY `uq_calon_org` (`id_calon`,`id_org`);

--
-- Indexes for table `penerima_beasiswa`
--
ALTER TABLE `penerima_beasiswa`
  ADD PRIMARY KEY (`id_penerima`),
  ADD UNIQUE KEY `uq_pb` (`id_calon`,`id_beasiswa`),
  ADD KEY `fk_pb_beasiswa` (`id_beasiswa`),
  ADD KEY `fk_pb_potongan` (`id_potongan`),
  ADD KEY `fk_pb_mhs` (`nim`);

--
-- Indexes for table `pengampu_matkul`
--
ALTER TABLE `pengampu_matkul`
  ADD PRIMARY KEY (`id_pengampu`),
  ADD UNIQUE KEY `uq_pengampu` (`id_dosen`,`id_matkul`,`id_semester`),
  ADD KEY `fk_peng_mk` (`id_matkul`),
  ADD KEY `fk_peng_sem` (`id_semester`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `uq_pengguna_calon` (`id_calon`);

--
-- Indexes for table `potongan_uang_kuliah`
--
ALTER TABLE `potongan_uang_kuliah`
  ADD PRIMARY KEY (`id_potongan`),
  ADD UNIQUE KEY `uq_potongan` (`id_beasiswa`,`nama_potongan`);

--
-- Indexes for table `program_studi`
--
ALTER TABLE `program_studi`
  ADD PRIMARY KEY (`id_prodi`),
  ADD UNIQUE KEY `kode_prodi` (`kode_prodi`),
  ADD UNIQUE KEY `uq_prodi_nama_jenjang` (`nama_prodi`,`jenjang`);

--
-- Indexes for table `rekap_kehadiran`
--
ALTER TABLE `rekap_kehadiran`
  ADD PRIMARY KEY (`id_rekap`),
  ADD UNIQUE KEY `uq_rekap` (`nim`,`id_semester`),
  ADD KEY `fk_rekap_sem` (`id_semester`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id_semester`),
  ADD UNIQUE KEY `uq_semester` (`tahun_akademik`,`jenis`);

--
-- Indexes for table `skema_pembayaran`
--
ALTER TABLE `skema_pembayaran`
  ADD PRIMARY KEY (`id_skema`),
  ADD UNIQUE KEY `uq_skema` (`jenis`,`jenjang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id_absen` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `beasiswa`
--
ALTER TABLE `beasiswa`
  MODIFY `id_beasiswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `berkas_pendaftaran`
--
ALTER TABLE `berkas_pendaftaran`
  MODIFY `id_berkas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `calon_mahasiswa`
--
ALTER TABLE `calon_mahasiswa`
  MODIFY `id_calon` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dosen`
--
ALTER TABLE `dosen`
  MODIFY `id_dosen` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gelombang`
--
ALTER TABLE `gelombang`
  MODIFY `id_gelombang` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jadwal_seleksi`
--
ALTER TABLE `jadwal_seleksi`
  MODIFY `id_jadwal` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jalur_pendaftaran`
--
ALTER TABLE `jalur_pendaftaran`
  MODIFY `id_jalur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `kategori_organisasi`
--
ALTER TABLE `kategori_organisasi`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `keanggotaan`
--
ALTER TABLE `keanggotaan`
  MODIFY `id_anggota` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kegiatan`
--
ALTER TABLE `kegiatan`
  MODIFY `id_kegiatan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `keputusan_lembaga`
--
ALTER TABLE `keputusan_lembaga`
  MODIFY `id_keputusan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mahasiswa_terbaik`
--
ALTER TABLE `mahasiswa_terbaik`
  MODIFY `id_terbaik` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mahasiswa_terbaik_angkatan`
--
ALTER TABLE `mahasiswa_terbaik_angkatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  MODIFY `id_matkul` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nilai_semester`
--
ALTER TABLE `nilai_semester`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `organisasi`
--
ALTER TABLE `organisasi`
  MODIFY `id_org` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `parameter_penilaian`
--
ALTER TABLE `parameter_penilaian`
  MODIFY `id_param` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_bayar` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  MODIFY `id_pendaftaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pendaftaran_organisasi`
--
ALTER TABLE `pendaftaran_organisasi`
  MODIFY `id_daftar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `penerima_beasiswa`
--
ALTER TABLE `penerima_beasiswa`
  MODIFY `id_penerima` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengampu_matkul`
--
ALTER TABLE `pengampu_matkul`
  MODIFY `id_pengampu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `potongan_uang_kuliah`
--
ALTER TABLE `potongan_uang_kuliah`
  MODIFY `id_potongan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `program_studi`
--
ALTER TABLE `program_studi`
  MODIFY `id_prodi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rekap_kehadiran`
--
ALTER TABLE `rekap_kehadiran`
  MODIFY `id_rekap` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id_semester` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skema_pembayaran`
--
ALTER TABLE `skema_pembayaran`
  MODIFY `id_skema` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `absensi`
--
ALTER TABLE `absensi`
  ADD CONSTRAINT `fk_abs_mhs` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`),
  ADD CONSTRAINT `fk_abs_mk` FOREIGN KEY (`id_matkul`) REFERENCES `mata_kuliah` (`id_matkul`),
  ADD CONSTRAINT `fk_abs_sem` FOREIGN KEY (`id_semester`) REFERENCES `semester` (`id_semester`);

--
-- Constraints for table `beasiswa`
--
ALTER TABLE `beasiswa`
  ADD CONSTRAINT `fk_beasiswa_jalur` FOREIGN KEY (`id_jalur`) REFERENCES `jalur_pendaftaran` (`id_jalur`);

--
-- Constraints for table `berkas_pendaftaran`
--
ALTER TABLE `berkas_pendaftaran`
  ADD CONSTRAINT `fk_berkas_pend` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id_pendaftaran`) ON DELETE CASCADE;

--
-- Constraints for table `dosen`
--
ALTER TABLE `dosen`
  ADD CONSTRAINT `fk_dosen_prodi` FOREIGN KEY (`id_prodi`) REFERENCES `program_studi` (`id_prodi`);

--
-- Constraints for table `jadwal_seleksi`
--
ALTER TABLE `jadwal_seleksi`
  ADD CONSTRAINT `fk_js_pend` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id_pendaftaran`) ON DELETE CASCADE;

--
-- Constraints for table `keanggotaan`
--
ALTER TABLE `keanggotaan`
  ADD CONSTRAINT `fk_ang_mhs` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`),
  ADD CONSTRAINT `fk_ang_org` FOREIGN KEY (`id_org`) REFERENCES `organisasi` (`id_org`);

--
-- Constraints for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD CONSTRAINT `fk_keg_org` FOREIGN KEY (`id_org`) REFERENCES `organisasi` (`id_org`);

--
-- Constraints for table `keputusan_lembaga`
--
ALTER TABLE `keputusan_lembaga`
  ADD CONSTRAINT `keputusan_lembaga_ibfk_1` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id_pendaftaran`) ON DELETE CASCADE;

--
-- Constraints for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD CONSTRAINT `fk_mhs_calon` FOREIGN KEY (`id_calon`) REFERENCES `calon_mahasiswa` (`id_calon`),
  ADD CONSTRAINT `fk_mhs_prodi` FOREIGN KEY (`id_prodi`) REFERENCES `program_studi` (`id_prodi`);

--
-- Constraints for table `mahasiswa_terbaik`
--
ALTER TABLE `mahasiswa_terbaik`
  ADD CONSTRAINT `fk_mt_mhs` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`),
  ADD CONSTRAINT `fk_mt_prodi` FOREIGN KEY (`id_prodi`) REFERENCES `program_studi` (`id_prodi`),
  ADD CONSTRAINT `fk_mt_sem` FOREIGN KEY (`id_semester`) REFERENCES `semester` (`id_semester`);

--
-- Constraints for table `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD CONSTRAINT `fk_mk_prodi` FOREIGN KEY (`id_prodi`) REFERENCES `program_studi` (`id_prodi`);

--
-- Constraints for table `nilai_semester`
--
ALTER TABLE `nilai_semester`
  ADD CONSTRAINT `fk_nilai_mhs` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`),
  ADD CONSTRAINT `fk_nilai_sem` FOREIGN KEY (`id_semester`) REFERENCES `semester` (`id_semester`);

--
-- Constraints for table `organisasi`
--
ALTER TABLE `organisasi`
  ADD CONSTRAINT `fk_org_kategori` FOREIGN KEY (`id_kategori`) REFERENCES `kategori_organisasi` (`id_kategori`),
  ADD CONSTRAINT `fk_org_pembina` FOREIGN KEY (`id_dosen_pembina`) REFERENCES `dosen` (`id_dosen`);

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `fk_bayar_pend` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id_pendaftaran`) ON DELETE CASCADE;

--
-- Constraints for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD CONSTRAINT `fk_pend_calon` FOREIGN KEY (`id_calon`) REFERENCES `calon_mahasiswa` (`id_calon`),
  ADD CONSTRAINT `fk_pend_gelombang` FOREIGN KEY (`id_gelombang`) REFERENCES `gelombang` (`id_gelombang`),
  ADD CONSTRAINT `fk_pend_jalur` FOREIGN KEY (`id_jalur`) REFERENCES `jalur_pendaftaran` (`id_jalur`),
  ADD CONSTRAINT `fk_pend_prodi` FOREIGN KEY (`id_prodi`) REFERENCES `program_studi` (`id_prodi`),
  ADD CONSTRAINT `fk_pend_skema` FOREIGN KEY (`id_skema`) REFERENCES `skema_pembayaran` (`id_skema`);

--
-- Constraints for table `penerima_beasiswa`
--
ALTER TABLE `penerima_beasiswa`
  ADD CONSTRAINT `fk_pb_beasiswa` FOREIGN KEY (`id_beasiswa`) REFERENCES `beasiswa` (`id_beasiswa`),
  ADD CONSTRAINT `fk_pb_calon` FOREIGN KEY (`id_calon`) REFERENCES `calon_mahasiswa` (`id_calon`),
  ADD CONSTRAINT `fk_pb_mhs` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`),
  ADD CONSTRAINT `fk_pb_potongan` FOREIGN KEY (`id_potongan`) REFERENCES `potongan_uang_kuliah` (`id_potongan`);

--
-- Constraints for table `pengampu_matkul`
--
ALTER TABLE `pengampu_matkul`
  ADD CONSTRAINT `fk_peng_dosen` FOREIGN KEY (`id_dosen`) REFERENCES `dosen` (`id_dosen`),
  ADD CONSTRAINT `fk_peng_mk` FOREIGN KEY (`id_matkul`) REFERENCES `mata_kuliah` (`id_matkul`),
  ADD CONSTRAINT `fk_peng_sem` FOREIGN KEY (`id_semester`) REFERENCES `semester` (`id_semester`);

--
-- Constraints for table `potongan_uang_kuliah`
--
ALTER TABLE `potongan_uang_kuliah`
  ADD CONSTRAINT `fk_potongan_beasiswa` FOREIGN KEY (`id_beasiswa`) REFERENCES `beasiswa` (`id_beasiswa`);

--
-- Constraints for table `rekap_kehadiran`
--
ALTER TABLE `rekap_kehadiran`
  ADD CONSTRAINT `fk_rekap_mhs` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`),
  ADD CONSTRAINT `fk_rekap_sem` FOREIGN KEY (`id_semester`) REFERENCES `semester` (`id_semester`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
