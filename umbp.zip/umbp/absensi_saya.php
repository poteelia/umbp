<?php
require 'config/koneksi.php'; require 'config/bantu.php'; require 'config/mahasiswa.php';
wajib_login(['calon']);
$idc = id_calon_akun($db);
if (!$idc) { header('Location: daftar_data.php'); exit; }
$mh = data_mahasiswa($db, $idc);

$semAll = []; $semRow = null; $skDipilih = null; $absensi = []; $detail = []; $rekap = null;
if ($mh) {
    $semAll = daftar_semester($db);
    $semRow = semester_terpilih($semAll);
    if ($semRow) {
        $nim = (string)$mh['nim']; $idProdi = (int)$mh['id_prodi']; $idSem = (int)$semRow['id_semester'];
        $angkatan = $mh['angkatan'] !== null ? (int)$mh['angkatan'] : null;
        $skDipilih = semester_ke($angkatan, (string)$semRow['tahun_akademik'], (string)$semRow['jenis']);
        $skCari = $skDipilih ?? 0;   // 0 = hanya mata kuliah yang sudah punya absensi

        $q = $db->prepare("SELECT m.id_matkul, m.kode_mk, m.nama_mk, COUNT(a.id_matkul) AS tercatat,
                COALESCE(SUM(a.status_hadir = 'hadir'), 0) AS hadir,
                COALESCE(SUM(a.status_hadir = 'izin'), 0) AS izin,
                COALESCE(SUM(a.status_hadir = 'sakit'), 0) AS sakit,
                COALESCE(SUM(a.status_hadir = 'alpa'), 0) AS alpa
            FROM mata_kuliah m
            LEFT JOIN absensi a ON a.id_matkul = m.id_matkul AND a.nim = ? AND a.id_semester = ?
            WHERE m.id_prodi = ? AND (m.semester_ke = ? OR a.id_matkul IS NOT NULL)
            GROUP BY m.id_matkul, m.kode_mk, m.nama_mk
            ORDER BY m.kode_mk");
        $q->bind_param('siii', $nim, $idSem, $idProdi, $skCari); $q->execute();
        $absensi = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();

        // status tiap pertemuan, urut tanggal
        $q = $db->prepare('SELECT id_matkul, status_hadir FROM absensi WHERE nim = ? AND id_semester = ? ORDER BY tanggal');
        $q->bind_param('si', $nim, $idSem); $q->execute();
        foreach ($q->get_result() as $r) { $detail[(int)$r['id_matkul']][] = (string)$r['status_hadir']; }
        $q->close();

        $q = $db->prepare('SELECT total_pertemuan, total_hadir, persen_hadir FROM rekap_kehadiran WHERE nim = ? AND id_semester = ?');
        $q->bind_param('si', $nim, $idSem); $q->execute();
        $rekap = $q->get_result()->fetch_assoc(); $q->close();
    }
}

$warna = ['hadir' => '#2e9e57', 'izin' => '#e0a800', 'sakit' => '#3b82c4', 'alpa' => '#c0392b'];
$huruf = ['hadir' => 'H', 'izin' => 'I', 'sakit' => 'S', 'alpa' => 'A'];

$judul = 'Absensi';
require 'partials/atas.php';
?>
<div class="card">
<h2>Absensi Mahasiswa per Mata Kuliah</h2>
<?php tampil_flash(); ?>
<?php if (!$mh): ?>
  <?= pesan_belum_mahasiswa() ?>
<?php elseif (!$semAll): ?>
  <p class="kecil">Belum ada data semester.</p>
<?php else: ?>
  <form method="get" class="inline">
    <div><label>Semester</label><select name="sem" onchange="this.form.submit()">
      <?php foreach ($semAll as $sx): ?><option value="<?= (int)$sx['id_semester'] ?>" <?= (int)$semRow['id_semester'] === (int)$sx['id_semester'] ? 'selected' : '' ?>><?= h($sx['tahun_akademik']) ?> <?= h($sx['jenis']) ?></option><?php endforeach; ?>
    </select></div>
    <div><label>Program studi</label><input value="<?= h($mh['nama_prodi']) ?> (<?= h($mh['jenjang']) ?>)" readonly tabindex="-1"></div>
  </form>
  <p class="kecil">Setiap mata kuliah memiliki <?= JUMLAH_PERTEMUAN ?> pertemuan per semester.<?= $skDipilih !== null ? ' Semester ini adalah semester perkuliahan ke-' . (int)$skDipilih . '.' : '' ?>
    Keterangan kotak: <b>H</b> hadir, <b>I</b> izin, <b>S</b> sakit, <b>A</b> alpa, kosong = belum ada pertemuan.</p>
<?php endif; ?>
</div>

<?php if ($mh && $semAll): ?>
<div class="card">
<div class="scroll"><table>
<tr><th>Kode</th><th>Mata kuliah</th><th>Hadir</th><th>Izin</th><th>Sakit</th><th>Alpa</th><th>Kehadiran</th><th>Pertemuan 1-<?= JUMLAH_PERTEMUAN ?></th></tr>
<?php foreach ($absensi as $r): $idm = (int)$r['id_matkul']; $persenMk = (int)$r['hadir'] / JUMLAH_PERTEMUAN * 100; ?>
<tr>
  <td><?= h($r['kode_mk']) ?></td><td><?= h($r['nama_mk']) ?></td>
  <td><b><?= (int)$r['hadir'] ?>/<?= JUMLAH_PERTEMUAN ?></b></td>
  <td><?= (int)$r['izin'] ?></td><td><?= (int)$r['sakit'] ?></td><td><?= (int)$r['alpa'] ?></td>
  <td><?= bar_hadir($persenMk) ?></td>
  <td style="white-space:nowrap">
  <?php for ($i = 0; $i < JUMLAH_PERTEMUAN; $i++): $st = $detail[$idm][$i] ?? null; ?>
    <span title="Pertemuan ke-<?= $i + 1 ?><?= $st ? ': ' . h($st) : '' ?>" style="display:inline-block;width:18px;height:18px;line-height:18px;text-align:center;font-size:10px;border-radius:4px;margin:1px;color:#fff;background:<?= $st ? ($warna[$st] ?? '#888') : '#e9e4e2' ?>"><?= $st ? ($huruf[$st] ?? '?') : '' ?></span>
  <?php endfor; ?>
  </td>
</tr>
<?php endforeach; ?>
<?php if (!$absensi): ?><tr><td colspan="8">Belum ada data absensi pada semester ini.</td></tr><?php endif; ?>
</table></div>
<?php if ($rekap): ?>
<p style="margin-top:12px">Total semester ini: <b><?= (int)$rekap['total_hadir'] ?>/<?= (int)$rekap['total_pertemuan'] ?></b> pertemuan hadir
  (<b><?= h($rekap['persen_hadir']) ?>%</b>).</p>
<?php endif; ?>
</div>
<?php endif; ?>
<?php require 'partials/bawah.php'; ?>