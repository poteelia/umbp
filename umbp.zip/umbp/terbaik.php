<?php
require 'config/koneksi.php'; require 'config/bantu.php';
wajib_login(['admin', 'kemahasiswaan']);

$tab = ($_GET['tab'] ?? 'semester') === 'angkatan' ? 'angkatan' : 'semester';

$semester = $db->query('SELECT * FROM semester ORDER BY id_semester')->fetch_all(MYSQLI_ASSOC);
$sem = (int)($_GET['sem'] ?? 0);
if (!$sem && $semester) $sem = (int)end($semester)['id_semester'];

$angkatanList = array_map('intval', array_column(
    $db->query('SELECT DISTINCT angkatan FROM mahasiswa WHERE angkatan IS NOT NULL ORDER BY angkatan DESC')->fetch_all(MYSQLI_ASSOC), 'angkatan'));
$ang = (int)($_GET['angkatan'] ?? 0);
if (!$ang && $angkatanList) $ang = $angkatanList[0];

$par = $db->query('SELECT * FROM parameter_penilaian LIMIT 1')->fetch_assoc() ?: null;

/*
 * Lulusan satu angkatan beserta peringkatnya per prodi.
 * Syarat: sudah lulus, IPK terakhir >= min_ipk, rata-rata kehadiran >= min_kehadiran_rata (dari parameter_penilaian).
 * Urutan: IPK tertinggi, lalu kehadiran tertinggi, lalu yang lulus lebih dulu.
 */
function kandidat_angkatan($db, int $ang, ?array $par): array {
    $q = $db->prepare("SELECT m.nim, m.nama, m.id_prodi, m.tgl_lulus, p.nama_prodi, p.jenjang,
        (SELECT n.ipk FROM nilai_semester n WHERE n.nim = m.nim ORDER BY n.id_semester DESC LIMIT 1) AS ipk,
        (SELECT AVG(r.persen_hadir) FROM rekap_kehadiran r WHERE r.nim = m.nim) AS hadir
      FROM mahasiswa m JOIN program_studi p ON p.id_prodi = m.id_prodi
      WHERE m.angkatan = ? AND m.status_akademik = 'lulus'");
    $q->bind_param('i', $ang); $q->execute();
    $rows = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();

    $minIpk = $par['min_ipk'] ?? null;
    $minHadir = $par['min_kehadiran_rata'] ?? null;
    foreach ($rows as &$r) {
        $alasan = [];
        if ($r['ipk'] === null) $alasan[] = 'belum ada IPK';
        elseif ($minIpk !== null && (float)$r['ipk'] < (float)$minIpk) $alasan[] = 'IPK di bawah ' . $minIpk;
        if ($minHadir !== null) {
            if ($r['hadir'] === null) $alasan[] = 'belum ada data kehadiran';
            elseif ((float)$r['hadir'] < (float)$minHadir) $alasan[] = 'kehadiran di bawah ' . (float)$minHadir . '%';
        }
        $r['alasan'] = implode(', ', $alasan);
        $r['layak'] = !$alasan;
    }
    unset($r);

    usort($rows, function ($a, $b) {
        return strcmp($a['nama_prodi'] . $a['jenjang'], $b['nama_prodi'] . $b['jenjang'])
            ?: ($b['layak'] <=> $a['layak'])
            ?: ((float)$b['ipk'] <=> (float)$a['ipk'])
            ?: ((float)$b['hadir'] <=> (float)$a['hadir'])
            ?: strcmp((string)$a['tgl_lulus'], (string)$b['tgl_lulus'])
            ?: strcmp((string)$a['nim'], (string)$b['nim']);
    });

    $urut = [];
    foreach ($rows as &$r) {
        if ($r['layak']) { $k = $r['id_prodi']; $urut[$k] = ($urut[$k] ?? 0) + 1; $r['peringkat'] = $urut[$k]; }
        else { $r['peringkat'] = null; }
    }
    unset($r);
    return $rows;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    $redir = 'terbaik.php?tab=semester&sem=' . $sem;
    try {
        if ($aksi === 'semester_tetapkan') {
            if (!$sem) throw new RuntimeException('Belum ada semester.');
            $db->begin_transaction();
            try {
                $s = $db->prepare('DELETE FROM mahasiswa_terbaik WHERE id_semester = ?');
                $s->bind_param('i', $sem); $s->execute();
                $s = $db->prepare('INSERT INTO mahasiswa_terbaik (nim, id_semester, id_prodi, peringkat, ipk, persen_hadir, tgl_ditetapkan)
                  SELECT nim, id_semester, id_prodi, peringkat, ipk, persen_hadir, CURDATE()
                  FROM v_peringkat_mahasiswa_terbaik WHERE id_semester = ? AND peringkat = 1');
                $s->bind_param('i', $sem); $s->execute();
                $db->commit();
            } catch (Throwable $e) { $db->rollback(); throw $e; }
            flash('ok', 'Mahasiswa terbaik per prodi ditetapkan.');
        } else {
            $a = (int)($_POST['angkatan'] ?? 0);
            $redir = 'terbaik.php?tab=angkatan&angkatan=' . $a;
            if ($aksi === 'lulus') {
                $nimP = trim($_POST['nim'] ?? ''); $tgl = trim($_POST['tgl_lulus'] ?? '');
                if (!valid_tanggal($tgl)) throw new RuntimeException('Tanggal lulus tidak valid.');
                $s = $db->prepare("UPDATE mahasiswa SET status_akademik = 'lulus', tgl_lulus = ? WHERE nim = ?");
                $s->bind_param('ss', $tgl, $nimP); $s->execute();
                flash('ok', 'Mahasiswa ditandai lulus.');
            } elseif ($aksi === 'batal_lulus') {
                $nimP = trim($_POST['nim'] ?? '');
                $db->begin_transaction();
                try {
                    $s = $db->prepare("UPDATE mahasiswa SET status_akademik = 'aktif', tgl_lulus = NULL WHERE nim = ?");
                    $s->bind_param('s', $nimP); $s->execute();
                    $s = $db->prepare('DELETE FROM mahasiswa_terbaik_angkatan WHERE nim = ?');
                    $s->bind_param('s', $nimP); $s->execute();
                    $db->commit();
                } catch (Throwable $e) { $db->rollback(); throw $e; }
                flash('ok', 'Status lulus dibatalkan.');
            } elseif ($aksi === 'angkatan_tetapkan') {
                if (!$a) throw new RuntimeException('Pilih angkatan dulu.');
                $kand = kandidat_angkatan($db, $a, $par);
                $db->begin_transaction();
                try {
                    $s = $db->prepare('DELETE FROM mahasiswa_terbaik_angkatan WHERE angkatan = ?');
                    $s->bind_param('i', $a); $s->execute();
                    $ins = $db->prepare('INSERT INTO mahasiswa_terbaik_angkatan (angkatan, id_prodi, nim, nama, peringkat, ipk, persen_hadir, tgl_ditetapkan)
                                         VALUES (?,?,?,?,1,?,?,CURDATE())');
                    $n = 0;
                    foreach ($kand as $r) {
                        if ($r['peringkat'] !== 1) continue;
                        $idp = (int)$r['id_prodi']; $nimR = (string)$r['nim']; $nm = (string)$r['nama'];
                        $ipk = round((float)$r['ipk'], 2);
                        $h = $r['hadir'] !== null ? round((float)$r['hadir'], 2) : null;
                        $ins->bind_param('iissdd', $a, $idp, $nimR, $nm, $ipk, $h); $ins->execute(); $n++;
                    }
                    if ($n < 1) throw new RuntimeException('Belum ada lulusan angkatan ini yang memenuhi syarat.');
                    $db->commit();
                } catch (Throwable $e) { $db->rollback(); throw $e; }
                flash('ok', 'Mahasiswa terbaik angkatan ' . $a . ' ditetapkan (' . $n . ' prodi).');
            }
        }
    } catch (RuntimeException $e) { flash('err', $e->getMessage()); }
    catch (mysqli_sql_exception $e) { flash('err', galat_sql($e)); }
    header('Location: ' . $redir); exit;
}

// ----- Data tab semester -----
$kandidat = []; $tetap = [];
if ($tab === 'semester') {
    $q = $db->prepare('SELECT v.nim, v.nama, v.ipk, v.persen_hadir, v.peringkat, p.nama_prodi, p.jenjang
      FROM v_peringkat_mahasiswa_terbaik v JOIN program_studi p ON p.id_prodi = v.id_prodi
      WHERE v.id_semester = ? ORDER BY p.nama_prodi, v.peringkat');
    $q->bind_param('i', $sem); $q->execute();
    $kandidat = $q->get_result()->fetch_all(MYSQLI_ASSOC);

    $q = $db->prepare('SELECT t.nim, m.nama, t.ipk, t.persen_hadir, t.peringkat, t.tgl_ditetapkan, p.nama_prodi, p.jenjang
      FROM mahasiswa_terbaik t JOIN mahasiswa m ON m.nim = t.nim JOIN program_studi p ON p.id_prodi = t.id_prodi
      WHERE t.id_semester = ? ORDER BY p.nama_prodi, t.peringkat');
    $q->bind_param('i', $sem); $q->execute();
    $tetap = $q->get_result()->fetch_all(MYSQLI_ASSOC);
}

// ----- Data tab angkatan -----
$mhsAng = []; $kandAng = []; $tetapAng = [];
if ($tab === 'angkatan' && $ang) {
    $q = $db->prepare("SELECT m.nim, m.nama, m.status_akademik, m.tgl_lulus, p.nama_prodi, p.jenjang,
        (SELECT n.ipk FROM nilai_semester n WHERE n.nim = m.nim ORDER BY n.id_semester DESC LIMIT 1) AS ipk,
        (SELECT AVG(r.persen_hadir) FROM rekap_kehadiran r WHERE r.nim = m.nim) AS hadir
      FROM mahasiswa m JOIN program_studi p ON p.id_prodi = m.id_prodi
      WHERE m.angkatan = ? ORDER BY p.nama_prodi, p.jenjang, m.nim");
    $q->bind_param('i', $ang); $q->execute();
    $mhsAng = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();

    $kandAng = kandidat_angkatan($db, $ang, $par);

    $q = $db->prepare('SELECT t.nim, t.nama, t.ipk, t.persen_hadir, t.peringkat, t.tgl_ditetapkan, p.nama_prodi, p.jenjang
      FROM mahasiswa_terbaik_angkatan t JOIN program_studi p ON p.id_prodi = t.id_prodi
      WHERE t.angkatan = ? ORDER BY p.nama_prodi, t.peringkat');
    $q->bind_param('i', $ang); $q->execute();
    $tetapAng = $q->get_result()->fetch_all(MYSQLI_ASSOC); $q->close();
}

$judul = 'Mahasiswa Terbaik';
require 'partials/atas.php';
?>
<div class="card">
<h2>Pemilihan Mahasiswa Terbaik</h2>
<?php tampil_flash(); ?>
<p>
  <a class="btn" href="terbaik.php?tab=semester" style="<?= $tab === 'semester' ? '' : 'opacity:.55' ?>">Per Semester</a>
  <a class="btn" href="terbaik.php?tab=angkatan" style="<?= $tab === 'angkatan' ? '' : 'opacity:.55' ?>">Per Angkatan (Lulusan)</a>
</p>
<?php if ($par): ?>
<p class="kecil">Syarat: IPK minimal <?= h($par['min_ipk'] ?? '-') ?>, kehadiran rata-rata minimal <?= (float)($par['min_kehadiran_rata'] ?? 0) ?>%<?= $tab === 'semester' ? ' (target ' . (float)($par['kehadiran_target'] ?? 0) . '%), dan bukan penerima KIP' : '' ?>.</p>
<?php endif; ?>
</div>

<?php if ($tab === 'semester'): ?>
<div class="card">
<form method="get" class="inline">
  <input type="hidden" name="tab" value="semester">
  <div><label>Semester</label><select name="sem" onchange="this.form.submit()">
  <?php foreach ($semester as $s): ?><option value="<?= (int)$s['id_semester'] ?>" <?= $sem == $s['id_semester'] ? 'selected' : '' ?>><?= h($s['tahun_akademik']) ?> <?= h($s['jenis']) ?></option><?php endforeach; ?>
  </select></div>
</form>
</div>

<div class="card">
<h3>Peringkat Kandidat per Prodi</h3>
<div class="scroll"><table>
<tr><th>Prodi</th><th>Peringkat</th><th>NIM</th><th>Nama</th><th>IPK</th><th>Kehadiran</th></tr>
<?php foreach ($kandidat as $r): ?>
<tr><td><?= h($r['nama_prodi']) ?> (<?= h($r['jenjang']) ?>)</td><td><?= (int)$r['peringkat'] ?></td><td><?= h($r['nim']) ?></td>
<td><?= h($r['nama']) ?></td><td><?= h($r['ipk']) ?></td><td><?= h($r['persen_hadir']) ?>%</td></tr>
<?php endforeach; ?>
<?php if (!$kandidat): ?><tr><td colspan="6">Belum ada mahasiswa yang memenuhi syarat pada semester ini.</td></tr><?php endif; ?>
</table></div>
<form method="post"><input type="hidden" name="aksi" value="semester_tetapkan"><button style="width:auto" <?= $kandidat ? '' : 'disabled' ?>>Tetapkan peringkat 1 tiap prodi</button></form>
</div>

<div class="card">
<h3>Mahasiswa Terbaik yang Telah Ditetapkan</h3>
<div class="scroll"><table>
<tr><th>Prodi</th><th>Peringkat</th><th>NIM</th><th>Nama</th><th>IPK</th><th>Kehadiran</th><th>Tanggal</th></tr>
<?php foreach ($tetap as $r): ?>
<tr><td><?= h($r['nama_prodi']) ?> (<?= h($r['jenjang']) ?>)</td><td><?= (int)$r['peringkat'] ?></td><td><?= h($r['nim']) ?></td>
<td><?= h($r['nama']) ?></td><td><?= h($r['ipk']) ?></td><td><?= h($r['persen_hadir']) ?>%</td><td><?= h($r['tgl_ditetapkan']) ?></td></tr>
<?php endforeach; ?>
<?php if (!$tetap): ?><tr><td colspan="7">Belum ada penetapan untuk semester ini.</td></tr><?php endif; ?>
</table></div></div>

<?php else: ?>
<div class="card">
<form method="get" class="inline">
  <input type="hidden" name="tab" value="angkatan">
  <div><label>Angkatan</label><select name="angkatan" onchange="this.form.submit()">
  <?php foreach ($angkatanList as $a): ?><option value="<?= $a ?>" <?= $ang == $a ? 'selected' : '' ?>><?= $a ?></option><?php endforeach; ?>
  </select></div>
</form>
<?php if (!$angkatanList): ?><p class="kecil">Belum ada mahasiswa dengan angkatan. Isi angkatan di menu Nilai dan Absensi.</p><?php endif; ?>
<p class="kecil">Mahasiswa terbaik per angkatan dipilih dari yang sudah <b>lulus</b>. Tandai lulus dulu di tabel pertama, lalu tetapkan di tabel kedua.</p>
</div>

<?php if ($ang): ?>
<div class="card">
<h3>Mahasiswa Angkatan <?= (int)$ang ?></h3>
<div class="scroll"><table>
<tr><th>NIM</th><th>Nama</th><th>Prodi</th><th>IPK terakhir</th><th>Kehadiran</th><th>Status</th><th>Aksi</th></tr>
<?php foreach ($mhsAng as $r): ?>
<tr>
  <td><?= h($r['nim']) ?></td><td><?= h($r['nama']) ?></td><td><?= h($r['nama_prodi']) ?> (<?= h($r['jenjang']) ?>)</td>
  <td><?= $r['ipk'] !== null ? h($r['ipk']) : '-' ?></td>
  <td><?= $r['hadir'] !== null ? round((float)$r['hadir'], 1) . '%' : '-' ?></td>
  <td><?= lencana($r['status_akademik']) ?><?= $r['tgl_lulus'] ? '<br><small>' . h($r['tgl_lulus']) . '</small>' : '' ?></td>
  <td>
  <?php if ($r['status_akademik'] === 'lulus'): ?>
    <form method="post" onsubmit="return confirm('Batalkan status lulus?')">
      <input type="hidden" name="aksi" value="batal_lulus"><input type="hidden" name="angkatan" value="<?= (int)$ang ?>"><input type="hidden" name="nim" value="<?= h($r['nim']) ?>">
      <button class="btn-hapus">Batalkan lulus</button>
    </form>
  <?php else: ?>
    <form method="post" class="inline">
      <input type="hidden" name="aksi" value="lulus"><input type="hidden" name="angkatan" value="<?= (int)$ang ?>"><input type="hidden" name="nim" value="<?= h($r['nim']) ?>">
      <input type="date" name="tgl_lulus" value="<?= date('Y-m-d') ?>" required>
      <button>Tandai lulus</button>
    </form>
  <?php endif; ?>
  </td>
</tr>
<?php endforeach; ?>
<?php if (!$mhsAng): ?><tr><td colspan="7">Tidak ada mahasiswa pada angkatan ini.</td></tr><?php endif; ?>
</table></div></div>

<div class="card">
<h3>Peringkat Lulusan Angkatan <?= (int)$ang ?> per Prodi</h3>
<div class="scroll"><table>
<tr><th>Prodi</th><th>Peringkat</th><th>NIM</th><th>Nama</th><th>IPK akhir</th><th>Kehadiran</th><th>Keterangan</th></tr>
<?php foreach ($kandAng as $r): ?>
<tr>
  <td><?= h($r['nama_prodi']) ?> (<?= h($r['jenjang']) ?>)</td>
  <td><?= $r['peringkat'] !== null ? (int)$r['peringkat'] : '-' ?></td>
  <td><?= h($r['nim']) ?></td><td><?= h($r['nama']) ?></td>
  <td><?= $r['ipk'] !== null ? h($r['ipk']) : '-' ?></td>
  <td><?= $r['hadir'] !== null ? round((float)$r['hadir'], 1) . '%' : '-' ?></td>
  <td><?= $r['layak'] ? '<span class="badge b-ok">memenuhi syarat</span>' : '<span class="badge b-no">' . h($r['alasan']) . '</span>' ?></td>
</tr>
<?php endforeach; ?>
<?php if (!$kandAng): ?><tr><td colspan="7">Belum ada lulusan pada angkatan ini.</td></tr><?php endif; ?>
</table></div>
<form method="post">
  <input type="hidden" name="aksi" value="angkatan_tetapkan"><input type="hidden" name="angkatan" value="<?= (int)$ang ?>">
  <button style="width:auto" <?= $kandAng ? '' : 'disabled' ?>>Tetapkan terbaik angkatan <?= (int)$ang ?> (peringkat 1 tiap prodi)</button>
</form>
</div>

<div class="card">
<h3>Mahasiswa Terbaik Angkatan <?= (int)$ang ?> yang Telah Ditetapkan</h3>
<div class="scroll"><table>
<tr><th>Prodi</th><th>NIM</th><th>Nama</th><th>IPK</th><th>Kehadiran</th><th>Tanggal</th></tr>
<?php foreach ($tetapAng as $r): ?>
<tr><td><?= h($r['nama_prodi']) ?> (<?= h($r['jenjang']) ?>)</td><td><?= h($r['nim']) ?></td><td><?= h($r['nama']) ?></td>
<td><?= h($r['ipk']) ?></td><td><?= $r['persen_hadir'] !== null ? h($r['persen_hadir']) . '%' : '-' ?></td><td><?= h($r['tgl_ditetapkan']) ?></td></tr>
<?php endforeach; ?>
<?php if (!$tetapAng): ?><tr><td colspan="6">Belum ada penetapan untuk angkatan ini.</td></tr><?php endif; ?>
</table></div></div>
<?php endif; ?>
<?php endif; ?>
<?php require 'partials/bawah.php'; ?>