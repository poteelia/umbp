<?php
require 'config/koneksi.php'; require 'config/bantu.php';
wajib_login(['admin', 'panitia']);

// Hapus file unggahan dari disk (hanya yang berada di folder uploads)
function hapus_file($rel) {
    $dir = realpath(__DIR__ . '/uploads');
    $p = $rel ? realpath(__DIR__ . '/' . $rel) : false;
    if ($dir && $p && strpos($p, $dir . DIRECTORY_SEPARATOR) === 0 && is_file($p)) { unlink($p); }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? 'status';
    $id = (int)($_POST['id'] ?? 0);
    try {
        if ($aksi === 'status') {
            if (!in_array($_POST['status'] ?? '', ['diproses', 'lulus', 'ditolak'], true)) throw new RuntimeException('Status tidak valid.');
            $pj = info_jalur($db, $id);
            if ($pj && $pj['alur'] === 'khusus' && $_POST['status'] === 'lulus') {
                throw new RuntimeException('Jalur khusus diluluskan otomatis setelah semua tahap seleksi lanjutan selesai (lihat menu Seleksi Lanjutan).');
            }
            $st = $db->prepare('UPDATE pendaftaran SET status = ? WHERE id_pendaftaran = ?');
            $st->bind_param('si', $_POST['status'], $id);
            $st->execute();
            flash('ok', 'Status diperbarui.');

        } elseif ($aksi === 'acc') {
            $hasil = acc_administrasi($db, $id);
            if ($hasil['gelombang']) {
                flash('ok', 'Administrasi disetujui. Masuk ' . $hasil['gelombang'] . ', ujian ' . tgl_id($hasil['ujian']) . '.');
            } else {
                flash('ok', 'Administrasi disetujui. Jadwal wawancara dibuat otomatis.');
            }

        } elseif ($aksi === 'tolak_adm') {
            $st = $db->prepare("UPDATE pendaftaran SET status_administrasi = 'ditolak' WHERE id_pendaftaran = ?");
            $st->bind_param('i', $id); $st->execute();
            flash('ok', 'Administrasi ditolak, calon bisa memperbaiki dan mengajukan ulang.');

        } elseif ($aksi === 'hapus') {
            $q = $db->prepare('SELECT id_calon FROM pendaftaran WHERE id_pendaftaran = ?');
            $q->bind_param('i', $id); $q->execute();
            $row = $q->get_result()->fetch_assoc();
            if (!$row) throw new RuntimeException('Data tidak ditemukan.');
            $idc = (int)$row['id_calon'];

            // File unggahan semua pendaftaran calon ini (dihapus dari disk setelah database berhasil)
            $files = [];
            $fq = $db->query("SELECT b.file_path AS p FROM berkas_pendaftaran b
                  JOIN pendaftaran x ON x.id_pendaftaran = b.id_pendaftaran WHERE x.id_calon = $idc
                UNION ALL
                SELECT y.bukti_path FROM pembayaran y
                  JOIN pendaftaran x ON x.id_pendaftaran = y.id_pendaftaran
                  WHERE x.id_calon = $idc AND y.bukti_path IS NOT NULL");
            foreach ($fq as $f) { $files[] = $f['p']; }

            $nims = [];
            foreach ($db->query("SELECT nim FROM mahasiswa WHERE id_calon = $idc") as $m) { $nims[] = $m['nim']; }

            $db->begin_transaction();
            $db->query("DELETE FROM penerima_beasiswa WHERE id_calon = $idc");
            foreach ($nims as $nim) {
                foreach (['mahasiswa_terbaik', 'mahasiswa_terbaik_angkatan', 'nilai_matkul', 'rekap_kehadiran', 'absensi', 'nilai_semester', 'keanggotaan'] as $t) {
                    $s = $db->prepare("DELETE FROM $t WHERE nim = ?");
                    $s->bind_param('s', $nim); $s->execute();
                }
                $s = $db->prepare('DELETE FROM mahasiswa WHERE nim = ?');
                $s->bind_param('s', $nim); $s->execute();
            }
            $db->query("DELETE FROM pendaftaran_organisasi WHERE id_calon = $idc");   // pengajuan organisasi
            $db->query("UPDATE pengguna SET id_calon = NULL WHERE id_calon = $idc");   // lepas tautan akun calon
            $db->query("DELETE FROM pendaftaran WHERE id_calon = $idc");   // berkas, pembayaran, jadwal ikut terhapus (CASCADE)
            $db->query("DELETE FROM calon_mahasiswa WHERE id_calon = $idc");
            $db->commit();
            foreach ($files as $f) { hapus_file($f); }
            flash('ok', 'Calon dan seluruh datanya dihapus.');
        }
    } catch (RuntimeException $e) { flash('err', $e->getMessage()); }
    catch (mysqli_sql_exception $e) { $db->rollback(); flash('err', galat_sql($e)); }
    header('Location: pendaftaran.php'); exit;
}

$rows = $db->query("
  SELECT p.id_pendaftaran, c.nama, c.asal_sekolah, ps.nama_prodi, ps.jenjang,
         j.nama_jalur, g.nama_gelombang, sp.jenis AS skema, p.tgl_daftar, p.status, p.status_administrasi,
         EXISTS(SELECT 1 FROM mahasiswa m WHERE m.id_calon = p.id_calon) AS sudah_mhs
  FROM pendaftaran p
  JOIN calon_mahasiswa c    ON c.id_calon = p.id_calon
  JOIN program_studi ps     ON ps.id_prodi = p.id_prodi
  JOIN jalur_pendaftaran j  ON j.id_jalur = p.id_jalur
  LEFT JOIN gelombang g     ON g.id_gelombang = p.id_gelombang
  LEFT JOIN skema_pembayaran sp ON sp.id_skema = p.id_skema
  ORDER BY p.id_pendaftaran DESC");

$judul = 'Pendaftaran';
require 'partials/atas.php';
?>
<div class="card">
<h2>Data Pendaftaran Mahasiswa Baru</h2>
<?php tampil_flash(); ?>
<a class="btn" href="pendaftaran_tambah.php">+ Daftar Calon Mahasiswa</a>
<div class="scroll"><table>
<tr><th>No</th><th>Nama</th><th>Prodi</th><th>Jalur</th><th>Gelombang</th>
<th>Skema</th><th>Tanggal</th><th>Administrasi</th><th>Status</th><th>Aksi</th></tr>
<?php $no = 1; foreach ($rows as $r):
    $pesan = $r['sudah_mhs']
        ? 'Calon ' . $r['nama'] . ' sudah tercatat sebagai mahasiswa. Menghapus akan ikut menghapus data mahasiswa, nilai, absensi, dan keanggotaan organisasinya. Lanjutkan?'
        : 'Hapus calon ' . $r['nama'] . '? Berkas, pembayaran, dan jadwalnya ikut terhapus.';
?>
<tr>
<td><?= $no++ ?></td>
<td><?= h($r['nama']) ?><?= $r['sudah_mhs'] ? ' <span class="badge b-ok">mahasiswa</span>' : '' ?><br><small><?= h($r['asal_sekolah']) ?></small></td>
<td><?= h($r['nama_prodi']) ?> (<?= h($r['jenjang']) ?>)</td>
<td><?= h($r['nama_jalur']) ?></td>
<td><?= h($r['nama_gelombang'] ?? '-') ?></td>
<td><?= h($r['skema'] ?? '-') ?></td>
<td><?= h($r['tgl_daftar']) ?></td>
<td><?= lencana($r['status_administrasi']) ?>
<?php if (in_array($r['status_administrasi'], ['menunggu', 'ditolak'], true)): ?>
  <form method="post" style="display:inline"><input type="hidden" name="aksi" value="acc"><input type="hidden" name="id" value="<?= (int)$r['id_pendaftaran'] ?>"><button>ACC</button></form>
<?php endif; ?>
<?php if ($r['status_administrasi'] === 'menunggu'): ?>
  <form method="post" style="display:inline"><input type="hidden" name="aksi" value="tolak_adm"><input type="hidden" name="id" value="<?= (int)$r['id_pendaftaran'] ?>"><button class="btn-hapus">Tolak</button></form>
<?php endif; ?>
</td>
<td><form method="post">
  <input type="hidden" name="aksi" value="status">
  <input type="hidden" name="id" value="<?= (int)$r['id_pendaftaran'] ?>">
  <select name="status">
  <?php foreach (['diproses', 'lulus', 'ditolak'] as $s): ?>
    <option <?= $r['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
  <?php endforeach; ?>
  </select> <button>Simpan</button></form></td>
<td class="aksi">
  <a href="pendaftaran_detail.php?id=<?= (int)$r['id_pendaftaran'] ?>">Detail</a>
  <a href="pendaftaran_edit.php?id=<?= (int)$r['id_pendaftaran'] ?>">Edit</a>
  <form method="post" onsubmit="return confirm(<?= h(json_encode($pesan)) ?>)">
    <input type="hidden" name="aksi" value="hapus">
    <input type="hidden" name="id" value="<?= (int)$r['id_pendaftaran'] ?>">
    <button class="btn-hapus">Hapus</button></form></td>
</tr>
<?php endforeach; ?>
<?php if ($no === 1): ?><tr><td colspan="10">Belum ada pendaftar.</td></tr><?php endif; ?>
</table></div></div>
<?php require 'partials/bawah.php'; ?>