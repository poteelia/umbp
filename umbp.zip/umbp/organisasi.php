<?php
require 'config/koneksi.php'; require 'config/bantu.php';
wajib_login(['admin', 'kemahasiswaan']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $aksi = $_POST['aksi'] ?? '';
        if ($aksi === 'tambah') {
            $pembina = $_POST['id_dosen_pembina'] !== '' ? (int)$_POST['id_dosen_pembina'] : null;
            $sing = trim($_POST['singkatan']) !== '' ? trim($_POST['singkatan']) : null;
            $kat = (int)$_POST['id_kategori'];
            $s = $db->prepare('INSERT INTO organisasi (id_kategori, id_dosen_pembina, nama_org, singkatan, deskripsi) VALUES (?,?,?,?,?)');
            $s->bind_param('iisss', $kat, $pembina, $_POST['nama_org'], $sing, $_POST['deskripsi']);
            $s->execute();
            flash('ok', 'Organisasi ditambahkan.');
        } elseif ($aksi === 'toggle') {
            $s = $db->prepare('UPDATE organisasi SET status_aktif = NOT status_aktif WHERE id_org = ?');
            $s->bind_param('i', $_POST['id_org']);
            $s->execute();
            flash('ok', 'Status organisasi diperbarui.');
        }
    } catch (mysqli_sql_exception $e) { flash('err', galat_sql($e)); }
    header('Location: organisasi.php'); exit;
}

$kategori = $db->query('SELECT * FROM kategori_organisasi ORDER BY id_kategori')->fetch_all(MYSQLI_ASSOC);
$dosen    = $db->query('SELECT id_dosen, nama FROM dosen ORDER BY nama')->fetch_all(MYSQLI_ASSOC);
$rows = $db->query("SELECT o.id_org, o.nama_org, o.singkatan, o.status_aktif, k.nama_kategori, d.nama AS pembina,
    (SELECT COUNT(*) FROM keanggotaan a WHERE a.id_org = o.id_org AND a.status = 'aktif') AS jml
  FROM organisasi o
  JOIN kategori_organisasi k ON k.id_kategori = o.id_kategori
  LEFT JOIN dosen d ON d.id_dosen = o.id_dosen_pembina
  ORDER BY o.nama_org")->fetch_all(MYSQLI_ASSOC);

$judul = 'Organisasi';
require 'partials/atas.php';
?>
<div class="card">
<h2>Organisasi Kemahasiswaan</h2>
<?php tampil_flash(); ?>
<form method="post" class="inline">
  <input type="hidden" name="aksi" value="tambah">
  <div><label>Nama organisasi</label><input name="nama_org" required></div>
  <div><label>Singkatan</label><input name="singkatan" maxlength="20"></div>
  <div><label>Kategori</label><select name="id_kategori">
    <?php foreach ($kategori as $k): ?><option value="<?= (int)$k['id_kategori'] ?>"><?= h($k['nama_kategori']) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Dosen pembina</label><select name="id_dosen_pembina">
    <option value="">- belum ada -</option>
    <?php foreach ($dosen as $d): ?><option value="<?= (int)$d['id_dosen'] ?>"><?= h($d['nama']) ?></option><?php endforeach; ?>
  </select></div>
  <div><label>Deskripsi</label><input name="deskripsi"></div>
  <button>Tambah</button>
</form>
<div class="scroll"><table>
<tr><th>No</th><th>Organisasi</th><th>Kategori</th><th>Pembina</th><th>Anggota aktif</th><th>Status</th><th>Aksi</th></tr>
<?php $no = 1; foreach ($rows as $r): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= h($r['nama_org']) ?><?= $r['singkatan'] ? ' <small>(' . h($r['singkatan']) . ')</small>' : '' ?></td>
<td><?= h($r['nama_kategori']) ?></td>
<td><?= h($r['pembina'] ?? '-') ?></td>
<td><?= (int)$r['jml'] ?></td>
<td><?= lencana($r['status_aktif'] ? 'aktif' : 'nonaktif') ?></td>
<td><a href="organisasi_detail.php?id=<?= (int)$r['id_org'] ?>">Detail</a>
  <form method="post" style="display:inline"><input type="hidden" name="aksi" value="toggle">
  <input type="hidden" name="id_org" value="<?= (int)$r['id_org'] ?>"><button style="width:auto;margin:0;padding:4px 10px">Ubah status</button></form></td>
</tr>
<?php endforeach; ?>
</table></div></div>
<?php require 'partials/bawah.php'; ?>